import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const androidDir = path.join(root, 'android');
const appDir = path.join(androidDir, 'app');
const manifestPath = path.join(appDir, 'src', 'main', 'AndroidManifest.xml');
const buildGradlePath = path.join(appDir, 'build.gradle');
const resDir = path.join(appDir, 'src', 'main', 'res');
const logoSource = path.join(root, 'public', 'assets', 'aistudio', 'AddText_11-15-05.40.35_1363302e.png');

if (!fs.existsSync(manifestPath) || !fs.existsSync(buildGradlePath)) {
  console.error('Android project not found. Run "npx cap add android" first.');
  process.exit(1);
}

// 1. Inject required hardware & runtime permissions into AndroidManifest.xml
let manifest = fs.readFileSync(manifestPath, 'utf8');
const requiredEntries = [
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
  '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.compass" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.accelerometer" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.gyroscope" android:required="false" />',
];

const missingEntries = requiredEntries.filter((entry) => !manifest.includes(entry));
if (missingEntries.length > 0) {
  manifest = manifest.replace(
    '</manifest>',
    `    ${missingEntries.join('\n    ')}\n</manifest>`
  );
  fs.writeFileSync(manifestPath, manifest, 'utf8');
  console.log(`Added ${missingEntries.length} permission/feature entries to AndroidManifest.xml`);
}

// 2. Configure release signingConfigs & dynamic versionCode in app/build.gradle
let gradle = fs.readFileSync(buildGradlePath, 'utf8');
const versionCode = Number(process.env.ANDROID_VERSION_CODE || '1') || 1;
gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
gradle = gradle.replace(/versionName\s+"[^"]*"/, 'versionName "1.0"');

if (!gradle.includes('signingConfigs')) {
  const signingBlock = `    signingConfigs {
        release {
            def ksPath = System.getenv("ANDROID_KEYSTORE_PATH")
            if (ksPath != null && file(ksPath).exists()) {
                storeFile file(ksPath)
                storePassword System.getenv("ANDROID_KEYSTORE_PASSWORD")
                keyAlias System.getenv("ANDROID_KEY_ALIAS")
                keyPassword System.getenv("ANDROID_KEY_PASSWORD")
            }
        }
    }
    buildTypes {`;

  gradle = gradle.replace(/buildTypes\s*\{/, signingBlock);
  gradle = gradle.replace(
    /release\s*\{([\s\S]*?)minifyEnabled\s+(true|false)/,
    `release {$1minifyEnabled $2\n            signingConfig signingConfigs.release`
  );
  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
  console.log(`Configured release signingConfig and versionCode=${versionCode} in app/build.gradle`);
}

// 3. Replace default Capacitor launcher icons with Bidik's attached logo
if (fs.existsSync(logoSource)) {
  const mipmapSizes = [
    { folder: 'mipmap-mdpi', launcher: 48, foreground: 108 },
    { folder: 'mipmap-hdpi', launcher: 72, foreground: 162 },
    { folder: 'mipmap-xhdpi', launcher: 96, foreground: 216 },
    { folder: 'mipmap-xxhdpi', launcher: 144, foreground: 324 },
    { folder: 'mipmap-xxxhdpi', launcher: 192, foreground: 432 },
  ];

  let hasConvert = false;
  try {
    execFileSync('convert', ['-version'], { stdio: 'ignore' });
    hasConvert = true;
  } catch {
    hasConvert = false;
  }

  for (const spec of mipmapSizes) {
    const dir = path.join(resDir, spec.folder);
    fs.mkdirSync(dir, { recursive: true });
    const launcherPath = path.join(dir, 'ic_launcher.png');
    const roundPath = path.join(dir, 'ic_launcher_round.png');
    const fgPath = path.join(dir, 'ic_launcher_foreground.png');

    if (hasConvert) {
      execFileSync('convert', [
        logoSource,
        '-resize',
        `${spec.launcher}x${spec.launcher}`,
        launcherPath,
      ]);
      fs.copyFileSync(launcherPath, roundPath);

      const innerFg = Math.round(spec.foreground * 0.68);
      execFileSync('convert', [
        logoSource,
        '-resize',
        `${innerFg}x${innerFg}`,
        '-background',
        'none',
        '-gravity',
        'center',
        '-extent',
        `${spec.foreground}x${spec.foreground}`,
        fgPath,
      ]);
    } else {
      const fallback192 = path.join(root, 'public', 'pwa-192x192.png');
      const src = fs.existsSync(fallback192) ? fallback192 : logoSource;
      fs.copyFileSync(src, launcherPath);
      fs.copyFileSync(src, roundPath);
      fs.copyFileSync(src, fgPath);
    }
  }

  const valuesDir = path.join(resDir, 'values');
  fs.mkdirSync(valuesDir, { recursive: true });
  const bgXml = path.join(valuesDir, 'ic_launcher_background.xml');
  fs.writeFileSync(
    bgXml,
    `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#07090E</color>\n</resources>\n`,
    'utf8'
  );
  console.log('Updated Android mipmap launcher icons with Bidik logo');
}
