import React, { useEffect, useState } from 'react';
import { Check, LocateFixed, MapPin, X } from 'lucide-react';
import { GeoLocationState, LocationPreference } from '../types/instrument';
import {
  computeQiblaBearingAndDistance,
  getCardinalDirection,
  INDONESIAN_CITY_PRESETS,
} from '../utils/orientationMath';

interface SettingsModalProps {
  geo: GeoLocationState;
  locationPref: LocationPreference;
  onUpdateLocationPref: (next: LocationPreference) => void;
  onRequestLocation: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  geo,
  locationPref,
  onUpdateLocationPref,
  onRequestLocation,
  onClose,
}) => {
  const [latInput, setLatInput] = useState(String(locationPref.manualLatitude));
  const [lonInput, setLonInput] = useState(String(locationPref.manualLongitude));
  const [labelInput, setLabelInput] = useState(locationPref.manualLabel);
  const [formError, setFormError] = useState<string | null>(null);
  const [savedFeedback, setSavedFeedback] = useState(false);

  useEffect(() => {
    setLatInput(String(locationPref.manualLatitude));
    setLonInput(String(locationPref.manualLongitude));
    setLabelInput(locationPref.manualLabel);
  }, [locationPref.manualLatitude, locationPref.manualLongitude, locationPref.manualLabel]);

  const handleSelectMode = (mode: 'gps' | 'manual') => {
    onUpdateLocationPref({ ...locationPref, mode });
    if (mode === 'gps' && geo.status === 'idle') {
      onRequestLocation();
    }
  };

  const handlePresetPick = (cityId: string) => {
    const preset = INDONESIAN_CITY_PRESETS.find((c) => c.id === cityId);
    if (!preset) return;
    setLatInput(String(preset.latitude));
    setLonInput(String(preset.longitude));
    setLabelInput(preset.name);
    setFormError(null);
    onUpdateLocationPref({
      mode: 'manual',
      manualLatitude: preset.latitude,
      manualLongitude: preset.longitude,
      manualLabel: preset.name,
    });
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 1800);
  };

  const handleSaveManual = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedLat = parseFloat(latInput.replace(',', '.'));
    const parsedLon = parseFloat(lonInput.replace(',', '.'));

    if (!Number.isFinite(parsedLat) || parsedLat < -90 || parsedLat > 90) {
      setFormError('Lintang (Latitude) harus berupa angka antara -90 dan 90.');
      return;
    }
    if (!Number.isFinite(parsedLon) || parsedLon < -180 || parsedLon > 180) {
      setFormError('Bujur (Longitude) harus berupa angka antara -180 dan 180.');
      return;
    }

    setFormError(null);
    onUpdateLocationPref({
      mode: 'manual',
      manualLatitude: parsedLat,
      manualLongitude: parsedLon,
      manualLabel: labelInput.trim() || 'Lokasi Manual',
    });
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 1800);
  };

  const activeCoords =
    locationPref.mode === 'gps' && geo.status === 'active' && geo.latitude !== null && geo.longitude !== null
      ? { lat: geo.latitude, lon: geo.longitude, label: 'GPS Perangkat' }
      : {
          lat: locationPref.manualLatitude,
          lon: locationPref.manualLongitude,
          label: locationPref.manualLabel || 'Lokasi Manual',
        };

  const qiblaPreview = computeQiblaBearingAndDistance(activeCoords.lat, activeCoords.lon);
  const qiblaDir = getCardinalDirection(qiblaPreview.azimuth, 'id');

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 p-0 sm:p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-md max-h-[88dvh] flex flex-col rounded-t-3xl sm:rounded-2xl border border-slate-800 bg-[#0B0E17] text-slate-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between gap-4 shrink-0">
          <h2 id="settings-modal-title" className="text-base font-semibold text-white">
            Pengaturan
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] -mr-2 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            aria-label="Tutup pengaturan"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6 pb-safe">
          {/* 1. Input Lokasi dengan GPS dan Manual */}
          <section className="space-y-3.5">
            <div>
              <h3 className="text-sm font-semibold text-white">1. Pengaturan Lokasi</h3>
              <p className="mt-0.5 text-xs text-slate-400">
                Digunakan untuk menghitung arah Kiblat, jarak Ka&apos;bah, dan koordinat bidikan.
              </p>
            </div>

            {/* Segmented Mode Selector: GPS vs Manual */}
            <div
              className="grid grid-cols-2 gap-1 rounded-xl border border-slate-800 bg-[#07090E] p-1"
              role="group"
              aria-label="Sumber lokasi pengamat"
            >
              <button
                type="button"
                onClick={() => handleSelectMode('gps')}
                className={`min-h-[42px] inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  locationPref.mode === 'gps'
                    ? 'bg-cyan-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <LocateFixed className="w-3.5 h-3.5" aria-hidden="true" />
                <span>GPS Otomatis</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectMode('manual')}
                className={`min-h-[42px] inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  locationPref.mode === 'manual'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Input Manual</span>
              </button>
            </div>

            {locationPref.mode === 'gps' ? (
              <div className="rounded-xl border border-slate-800 bg-[#07090E] p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-medium text-slate-300">Status GPS Perangkat</span>
                  <button
                    type="button"
                    onClick={onRequestLocation}
                    className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg bg-cyan-500 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 cursor-pointer"
                  >
                    <LocateFixed className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{geo.status === 'loading' ? 'Mencari GPS...' : 'Perbarui GPS'}</span>
                  </button>
                </div>

                {geo.status === 'active' && geo.latitude !== null && geo.longitude !== null ? (
                  <div className="font-mono text-xs text-slate-200 tabular-nums space-y-1">
                    <div>
                      Lintang: <span className="text-cyan-400">{geo.latitude.toFixed(6)}°</span>
                    </div>
                    <div>
                      Bujur: <span className="text-cyan-400">{geo.longitude.toFixed(6)}°</span>
                    </div>
                    {geo.accuracyMeters !== null && (
                      <div className="text-slate-400">
                        Akurasi ±{Math.round(geo.accuracyMeters)} m
                        {geo.altitudeMeters !== null && ` · Elevasi ${Math.round(geo.altitudeMeters)} m dpl`}
                      </div>
                    )}
                  </div>
                ) : geo.errorMessage ? (
                  <p className="text-xs text-rose-400">{geo.errorMessage}</p>
                ) : (
                  <p className="text-xs text-slate-400">
                    Ketuk <strong>Perbarui GPS</strong> untuk membaca koordinat lokasi Anda saat ini. Sementara menunggu GPS, koordinat cadangan ({locationPref.manualLabel}) digunakan.
                  </p>
                )}
              </div>
            ) : (
              <form
                onSubmit={handleSaveManual}
                className="rounded-xl border border-slate-800 bg-[#07090E] p-4 space-y-3"
              >
                <div>
                  <label htmlFor="settings-city-preset" className="block text-xs text-slate-400 mb-1">
                    Isi Cepat Kota Acuan
                  </label>
                  <select
                    id="settings-city-preset"
                    value=""
                    onChange={(e) => {
                      if (e.target.value) handlePresetPick(e.target.value);
                    }}
                    className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#0B0E17] px-3 py-2 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="">Pilih kota untuk mengisi koordinat...</option>
                    {INDONESIAN_CITY_PRESETS.map((city) => (
                      <option key={city.id} value={city.id}>
                        {city.name} ({city.latitude.toFixed(4)}°, {city.longitude.toFixed(4)}°)
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label htmlFor="manual-lat" className="block text-xs text-slate-300 mb-1">
                      Lintang (Latitude)
                    </label>
                    <input
                      id="manual-lat"
                      type="text"
                      inputMode="decimal"
                      value={latInput}
                      onChange={(e) => setLatInput(e.target.value)}
                      placeholder="-7.1186"
                      className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#0B0E17] px-3 py-2 font-mono text-xs text-white tabular-nums focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label htmlFor="manual-lon" className="block text-xs text-slate-300 mb-1">
                      Bujur (Longitude)
                    </label>
                    <input
                      id="manual-lon"
                      type="text"
                      inputMode="decimal"
                      value={lonInput}
                      onChange={(e) => setLonInput(e.target.value)}
                      placeholder="113.6628"
                      className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#0B0E17] px-3 py-2 font-mono text-xs text-white tabular-nums focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="manual-label" className="block text-xs text-slate-300 mb-1">
                    Nama Lokasi
                  </label>
                  <input
                    id="manual-label"
                    type="text"
                    value={labelInput}
                    onChange={(e) => setLabelInput(e.target.value)}
                    placeholder="Contoh: Prenduan, Sumenep"
                    className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#0B0E17] px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                {formError && <p className="text-xs text-rose-400">{formError}</p>}

                <button
                  type="submit"
                  className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-amber-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors cursor-pointer"
                >
                  <Check className="w-4 h-4" aria-hidden="true" />
                  <span>{savedFeedback ? 'Lokasi Tersimpan' : 'Terapkan Lokasi Manual'}</span>
                </button>
              </form>
            )}

            {/* Live Active Coordinate & Qibla Result Preview */}
            <div className="rounded-xl border border-slate-800/80 bg-[#07090E]/70 px-3.5 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-400 truncate">Aktif: {activeCoords.label}</span>
              <span className="font-mono text-emerald-400 tabular-nums shrink-0">
                Kiblat {qiblaPreview.azimuth.toFixed(1)}° {qiblaDir.abbr}
              </span>
            </div>
          </section>

          {/* 2. Tentang Aplikasi */}
          <section className="space-y-3 border-t border-slate-800 pt-5">
            <h3 className="text-sm font-semibold text-white">2. Tentang Aplikasi</h3>

            <div className="rounded-xl border border-slate-800 bg-[#07090E] p-4 space-y-3">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800/80">
                <img
                  src="/assets/aistudio/AddText_11-15-05.40.35_1363302e.png"
                  alt="Logo Bidik"
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover shrink-0"
                />
                <div>
                  <div className="text-sm font-bold text-white">Bidik</div>
                  <div className="text-xs text-slate-400">
                    Kamera Pengukur Altitude, Azimuth &amp; Arah Kiblat
                  </div>
                </div>
              </div>

              <dl className="divide-y divide-slate-800/80 text-xs">
                <div className="py-2 flex items-center justify-between gap-4">
                  <dt className="text-slate-400">Nama</dt>
                  <dd className="font-medium text-slate-100 text-right">Ahmad Azizi</dd>
                </div>
                <div className="py-2 flex items-center justify-between gap-4">
                  <dt className="text-slate-400">Alamat</dt>
                  <dd className="font-medium text-slate-100 text-right">
                    Al-Muqri, Prenduan, Sumenep
                  </dd>
                </div>
                <div className="pt-2 flex items-center justify-between gap-4">
                  <dt className="text-slate-400">Versi</dt>
                  <dd className="font-mono font-medium text-cyan-400 tabular-nums text-right">
                    1.0
                  </dd>
                </div>
              </dl>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
