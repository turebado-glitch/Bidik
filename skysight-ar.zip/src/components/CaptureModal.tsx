import React, { useState } from 'react';
import { Check, Download, X } from 'lucide-react';
import { CompassLanguage } from '../types/instrument';
import { getCardinalDirection } from '../utils/orientationMath';

interface CaptureModalProps {
  azimuth: number;
  altitude: number;
  roll: number;
  snapshotDataUrl?: string;
  lang: CompassLanguage;
  onSave: (label: string, note: string) => void;
  onCancel: () => void;
}

export const CaptureModal: React.FC<CaptureModalProps> = ({
  azimuth,
  altitude,
  roll,
  snapshotDataUrl,
  lang,
  onSave,
  onCancel,
}) => {
  const [label, setLabel] = useState('');
  const [note, setNote] = useState('');

  const cardinal = getCardinalDirection(azimuth, lang);
  const altSign = altitude >= 0 ? '+' : '';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(label.trim() || `Objek ${azimuth.toFixed(0)}°`, note.trim());
  };

  const handleDownloadSnapshot = () => {
    if (!snapshotDataUrl) return;
    const link = document.createElement('a');
    link.href = snapshotDataUrl;
    link.download = `altaz-${azimuth.toFixed(0)}deg-${altitude.toFixed(0)}deg.jpg`;
    link.click();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 p-0 sm:p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="capture-modal-title"
    >
      <form
        onSubmit={handleSubmit}
        className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-slate-800 bg-[#0B0E17] p-5 text-slate-100"
      >
        <div className="flex items-center justify-between gap-4">
          <h3 id="capture-modal-title" className="text-base font-semibold text-white">
            Simpan Pengukuran Objek
          </h3>
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[44px] min-w-[44px] -mr-2 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            aria-label="Batalkan simpan"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {snapshotDataUrl && (
          <div className="mt-3 relative overflow-hidden rounded-xl border border-slate-800 bg-black">
            <img
              src={snapshotDataUrl}
              alt="Pratinjau bidikan objek"
              className="w-full aspect-video object-cover"
              referrerPolicy="no-referrer"
            />
            <button
              type="button"
              onClick={handleDownloadSnapshot}
              className="absolute bottom-2 right-2 min-h-[36px] inline-flex items-center gap-1.5 rounded-lg bg-[#07090E]/85 border border-slate-700 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
              <span>Unduh Foto</span>
            </button>
          </div>
        )}

        <div className="mt-3 grid grid-cols-3 gap-2 rounded-xl border border-slate-800 bg-[#07090E] p-3">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400">Altitude</div>
            <div className="font-mono text-base font-semibold text-cyan-400 tabular-nums">
              {altSign}
              {altitude.toFixed(1)}°
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400">Azimuth</div>
            <div className="font-mono text-base font-semibold text-amber-400 tabular-nums">
              {azimuth.toFixed(1)}° {cardinal.abbr}
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400">Roll</div>
            <div className="font-mono text-base font-semibold text-slate-200 tabular-nums">
              {roll.toFixed(1)}°
            </div>
          </div>
        </div>

        <div className="mt-4 space-y-3">
          <div>
            <label htmlFor="sighting-label" className="block text-xs font-medium text-slate-300">
              Nama Benda / Target
            </label>
            <input
              id="sighting-label"
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="Contoh: Menara BTS, Bulan, Puncak Gunung"
              autoFocus
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07090E] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>
          <div>
            <label htmlFor="sighting-note" className="block text-xs font-medium text-slate-300">
              Catatan (Opsional)
            </label>
            <input
              id="sighting-note"
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Contoh: Jarak ~500m, cuaca cerah"
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07090E] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-5 flex items-center gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-4 py-2.5 text-sm font-medium text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-500 px-4 py-2.5 text-sm font-semibold text-slate-950 hover:bg-cyan-400 transition-colors cursor-pointer"
          >
            <Check className="w-4 h-4" aria-hidden="true" />
            <span>Simpan Catatan</span>
          </button>
        </div>
      </form>
    </div>
  );
};
