export type CompassLanguage = 'id' | 'en';

export type AimMode = 'camera' | 'simulation';

export interface OrientationReading {
  /** Compass azimuth in degrees [0, 360) clockwise from North */
  azimuth: number;
  /** Elevation / altitude angle in degrees [-90, +90] above horizon */
  altitude: number;
  /** Horizon roll angle in degrees [-180, 180) */
  roll: number;
  /** Raw sensor alpha [0, 360) */
  rawAlpha: number | null;
  /** Raw sensor beta [-180, 180) */
  rawBeta: number | null;
  /** Raw sensor gamma [-90, 90) */
  rawGamma: number | null;
  /** True if backed by absolute magnetometer/earth frame */
  isAbsolute: boolean;
  timestamp: number;
}

export interface CalibrationConfig {
  /** Manual azimuth offset + magnetic declination in degrees */
  azimuthOffset: number;
  /** Manual altitude zeroing offset in degrees */
  altitudeOffset: number;
  /** Low-pass smoothing factor [0 = raw, 0.9 = heavy damping] */
  smoothing: number;
  /** Estimated vertical camera field of view in degrees */
  verticalFov: number;
  /** Cardinal label language */
  compassLang: CompassLanguage;
  /** Toggle artificial horizon and pitch ladder */
  showPitchLadder: boolean;
  /** Toggle top azimuth compass tape */
  showCompassTape: boolean;
  /** Toggle DMS (degrees-minutes-seconds) secondary readout */
  showDms: boolean;
}

export interface GeoLocationState {
  status: 'idle' | 'loading' | 'active' | 'error';
  latitude: number | null;
  longitude: number | null;
  altitudeMeters: number | null;
  accuracyMeters: number | null;
  errorMessage: string | null;
}

export interface SightingRecord {
  id: string;
  label: string;
  note: string;
  azimuth: number;
  altitude: number;
  roll: number;
  latitude: number | null;
  longitude: number | null;
  timestamp: number;
  source: 'sensor' | 'simulation';
  snapshotDataUrl?: string;
}

export interface QiblaInfo {
  enabled: boolean;
  azimuth: number;
  distanceKm: number;
  sourceLabel: string;
  isGps: boolean;
}

export interface LocationPreference {
  mode: 'gps' | 'manual';
  manualLatitude: number;
  manualLongitude: number;
  manualLabel: string;
}


