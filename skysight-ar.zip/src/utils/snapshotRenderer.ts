import { CompassLanguage } from '../types/instrument';
import { getCardinalDirection } from './orientationMath';

export interface SnapshotInput {
  videoElement: HTMLVideoElement | null;
  simCanvasElement: HTMLCanvasElement | null;
  azimuth: number;
  altitude: number;
  roll: number;
  latitude: number | null;
  longitude: number | null;
  lang: CompassLanguage;
  label?: string;
}

/**
 * Composites the live video frame (or simulation canvas) with an optical reticle
 * and precision telemetry stamp into a downloadable JPEG data URL.
 */
export function renderAnnotatedSnapshot(input: SnapshotInput): string | undefined {
  const {
    videoElement,
    simCanvasElement,
    azimuth,
    altitude,
    roll,
    latitude,
    longitude,
    lang,
    label,
  } = input;

  const hasVideo =
    videoElement &&
    videoElement.readyState >= 2 &&
    videoElement.videoWidth > 0 &&
    videoElement.videoHeight > 0;

  const targetW = 1280;
  const targetH = 720;

  const canvas = document.createElement('canvas');
  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext('2d');
  if (!ctx) return undefined;

  ctx.fillStyle = '#07090E';
  ctx.fillRect(0, 0, targetW, targetH);

  if (hasVideo && videoElement) {
    const vRatio = videoElement.videoWidth / videoElement.videoHeight;
    const cRatio = targetW / targetH;
    let dw = targetW;
    let dh = targetH;
    let dx = 0;
    let dy = 0;
    if (vRatio > cRatio) {
      dw = targetH * vRatio;
      dx = (targetW - dw) / 2;
    } else {
      dh = targetW / vRatio;
      dy = (targetH - dh) / 2;
    }
    ctx.drawImage(videoElement, dx, dy, dw, dh);
  } else if (simCanvasElement && simCanvasElement.width > 0) {
    ctx.drawImage(simCanvasElement, 0, 0, targetW, targetH);
  }

  // Draw calibrated center reticle
  const cx = targetW / 2;
  const cy = targetH / 2;

  ctx.save();
  ctx.strokeStyle = 'rgba(6, 182, 212, 0.9)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, 42, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(cx - 72, cy);
  ctx.lineTo(cx - 18, cy);
  ctx.moveTo(cx + 18, cy);
  ctx.lineTo(cx + 72, cy);
  ctx.moveTo(cx, cy - 72);
  ctx.lineTo(cx, cy - 18);
  ctx.moveTo(cx, cy + 18);
  ctx.lineTo(cx, cy + 72);
  ctx.stroke();

  ctx.fillStyle = '#F59E0B';
  ctx.beginPath();
  ctx.arc(cx, cy, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Bottom telemetry bar scrim
  const barH = 92;
  const grad = ctx.createLinearGradient(0, targetH - barH - 24, 0, targetH);
  grad.addColorStop(0, 'rgba(7, 9, 14, 0)');
  grad.addColorStop(0.35, 'rgba(7, 9, 14, 0.85)');
  grad.addColorStop(1, 'rgba(7, 9, 14, 0.95)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, targetH - barH - 24, targetW, barH + 24);

  const cardinal = getCardinalDirection(azimuth, lang);
  const altSign = altitude >= 0 ? '+' : '';

  ctx.fillStyle = '#94A3B8';
  ctx.font = '600 14px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('ALTITUDE (ELEVASI)', 36, targetH - 54);
  ctx.fillText('AZIMUTH (ARAH)', 310, targetH - 54);

  ctx.fillStyle = '#F8FAFC';
  ctx.font = '700 34px "JetBrains Mono", monospace';
  ctx.fillText(`${altSign}${altitude.toFixed(1)}°`, 36, targetH - 18);
  ctx.fillText(`${azimuth.toFixed(1)}° ${cardinal.abbr}`, 310, targetH - 18);

  // Right metadata stamp
  ctx.textAlign = 'right';
  ctx.fillStyle = '#E2E8F0';
  ctx.font = '600 16px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(label?.trim() || 'Pengukuran Bidik', targetW - 36, targetH - 48);

  ctx.fillStyle = '#94A3B8';
  ctx.font = '400 13px "JetBrains Mono", monospace';
  const timeStr = new Date().toLocaleString('id-ID', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  const gpsStr =
    latitude !== null && longitude !== null
      ? ` · ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`
      : '';
  ctx.fillText(`Roll ${roll.toFixed(1)}° · ${timeStr}${gpsStr}`, targetW - 36, targetH - 20);

  return canvas.toDataURL('image/jpeg', 0.86);
}
