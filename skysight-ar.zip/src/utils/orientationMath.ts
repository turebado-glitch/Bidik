import { CompassLanguage } from '../types/instrument';

const DEG_TO_RAD = Math.PI / 180;
const RAD_TO_DEG = 180 / Math.PI;

export interface EulerAngles {
  alpha: number;
  beta: number;
  gamma: number;
}

export interface AltAzResult {
  azimuth: number;
  altitude: number;
  roll: number;
}

/**
 * Normalizes an angle to [0, 360) degrees.
 */
export function normalizeDeg360(deg: number): number {
  const mod = deg % 360;
  return mod < 0 ? mod + 360 : mod;
}

/**
 * Normalizes an angle to [-180, 180) degrees.
 */
export function normalizeDeg180(deg: number): number {
  const mod = normalizeDeg360(deg);
  return mod >= 180 ? mod - 360 : mod;
}

/**
 * Computes gimbal-lock-free rear camera Azimuth, Altitude, and Horizon Roll
 * from W3C DeviceOrientation Euler angles (Z-X'-Y'' intrinsic rotation).
 *
 * Device frame: +X right, +Y up, +Z out of screen toward viewer.
 * Rear camera optical boresight is -Z_device = (0, 0, -1).
 */
export function computeCameraAltAz(
  alphaDeg: number,
  betaDeg: number,
  gammaDeg: number,
  screenAngleDeg = 0
): AltAzResult {
  const a = alphaDeg * DEG_TO_RAD;
  const b = betaDeg * DEG_TO_RAD;
  const g = gammaDeg * DEG_TO_RAD;

  const cosA = Math.cos(a);
  const sinA = Math.sin(a);
  const cosB = Math.cos(b);
  const sinB = Math.sin(b);
  const cosG = Math.cos(g);
  const sinG = Math.sin(g);

  // Rotation matrix columns R = Rz(a) * Rx(b) * Ry(g)
  // Column 0 (Device +X in Earth ENU)
  const xE = cosA * cosG - sinA * sinB * sinG;
  const xN = sinA * cosG + cosA * sinB * sinG;
  const xU = -cosB * sinG;

  // Column 1 (Device +Y in Earth ENU)
  const yE = -sinA * cosB;
  const yN = cosA * cosB;
  const yU = sinB;

  // Negative Column 2 (Device -Z rear camera look vector in Earth ENU)
  const lookE = -cosA * sinG - sinA * sinB * cosG;
  const lookN = -sinA * sinG + cosA * sinB * cosG;
  const lookU = -cosB * cosG;

  // Clamp lookU to [-1, 1] for numerical stability in asin
  const clampedU = Math.max(-1, Math.min(1, lookU));
  const altitude = Math.asin(clampedU) * RAD_TO_DEG;

  // When pointing nearly straight up/down (zenith/nadir singularity),
  // fall back to screen-up or screen-right horizontal projection for azimuth
  const horizMag = Math.hypot(lookE, lookN);
  let azimuth: number;
  if (horizMag > 0.04) {
    azimuth = normalizeDeg360(Math.atan2(lookE, lookN) * RAD_TO_DEG);
  } else {
    // Near zenith/nadir: use device +Y projection on horizontal plane
    const sRad = screenAngleDeg * DEG_TO_RAD;
    const upE = yE * Math.cos(sRad) - xE * Math.sin(sRad);
    const upN = yN * Math.cos(sRad) - xN * Math.sin(sRad);
    azimuth = normalizeDeg360(Math.atan2(upE, upN) * RAD_TO_DEG);
  }

  // Screen Up and Screen Right vectors in ENU accounting for screen rotation angle
  const sRad = screenAngleDeg * DEG_TO_RAD;
  const cosS = Math.cos(sRad);
  const sinS = Math.sin(sRad);

  // Screen right = x * cos(s) + y * sin(s) Wait: when screen rotates 90deg CCW (Android landscape-left),
  // screen +X (right) aligns with device -Y, screen +Y (up) aligns with device +X.
  const screenRightU = xU * cosS - yU * sinS;
  const screenUpU = xU * sinS + yU * cosS;

  // Horizon roll: angle of Earth Up projected onto screen plane
  const roll = Math.atan2(screenRightU, screenUpU) * RAD_TO_DEG;

  return {
    azimuth,
    altitude,
    roll,
  };
}

/**
 * Circular exponential moving average for angles in [0, 360).
 */
export function smoothAngleDeg(prevDeg: number, nextDeg: number, smoothing: number): number {
  const alpha = Math.max(0.05, 1 - smoothing);
  const delta = normalizeDeg180(nextDeg - prevDeg);
  return normalizeDeg360(prevDeg + alpha * delta);
}

/**
 * Linear exponential moving average.
 */
export function smoothLinear(prev: number, next: number, smoothing: number): number {
  const alpha = Math.max(0.05, 1 - smoothing);
  return prev + alpha * (next - prev);
}

const CARDINALS_ID = [
  { abbr: 'U', name: 'Utara' },
  { abbr: 'UTL', name: 'Utara Timur Laut' },
  { abbr: 'TL', name: 'Timur Laut' },
  { abbr: 'TTL', name: 'Timur Timur Laut' },
  { abbr: 'T', name: 'Timur' },
  { abbr: 'TM', name: 'Timur Menenggara' },
  { abbr: 'TG', name: 'Tenggara' },
  { abbr: 'STG', name: 'Selatan Tenggara' },
  { abbr: 'S', name: 'Selatan' },
  { abbr: 'SBD', name: 'Selatan Barat Daya' },
  { abbr: 'BD', name: 'Barat Daya' },
  { abbr: 'BBD', name: 'Barat Barat Daya' },
  { abbr: 'B', name: 'Barat' },
  { abbr: 'BBL', name: 'Barat Barat Laut' },
  { abbr: 'BL', name: 'Barat Laut' },
  { abbr: 'UBL', name: 'Utara Barat Laut' },
];

const CARDINALS_EN = [
  { abbr: 'N', name: 'North' },
  { abbr: 'NNE', name: 'North-Northeast' },
  { abbr: 'NE', name: 'Northeast' },
  { abbr: 'ENE', name: 'East-Northeast' },
  { abbr: 'E', name: 'East' },
  { abbr: 'ESE', name: 'East-Southeast' },
  { abbr: 'SE', name: 'Southeast' },
  { abbr: 'SSE', name: 'South-Southeast' },
  { abbr: 'S', name: 'South' },
  { abbr: 'SSW', name: 'South-Southwest' },
  { abbr: 'SW', name: 'Southwest' },
  { abbr: 'WSW', name: 'West-Southwest' },
  { abbr: 'W', name: 'West' },
  { abbr: 'WNW', name: 'West-Northwest' },
  { abbr: 'NW', name: 'Northwest' },
  { abbr: 'NNW', name: 'North-Northwest' },
];

export function getCardinalDirection(
  azimuthDeg: number,
  lang: CompassLanguage = 'id'
): { abbr: string; name: string } {
  const norm = normalizeDeg360(azimuthDeg);
  const index = Math.round(norm / 22.5) % 16;
  return lang === 'id' ? CARDINALS_ID[index] : CARDINALS_EN[index];
}

export function get8PointCardinalAbbr(deg: number, lang: CompassLanguage = 'id'): string | null {
  const norm = Math.round(normalizeDeg360(deg));
  const mapId: Record<number, string> = {
    0: 'U',
    45: 'TL',
    90: 'T',
    135: 'TG',
    180: 'S',
    225: 'BD',
    270: 'B',
    315: 'BL',
  };
  const mapEn: Record<number, string> = {
    0: 'N',
    45: 'NE',
    90: 'E',
    135: 'SE',
    180: 'S',
    225: 'SW',
    270: 'W',
    315: 'NW',
  };
  return lang === 'id' ? (mapId[norm] ?? null) : (mapEn[norm] ?? null);
}

/**
 * Formats decimal degrees to Degrees° Minutes' Seconds".
 */
export function formatDms(deg: number, signed = false): string {
  const sign = deg < 0 ? '-' : signed ? '+' : '';
  const abs = Math.abs(deg);
  const d = Math.floor(abs);
  const minFloat = (abs - d) * 60;
  const m = Math.floor(minFloat);
  const s = Math.round((minFloat - m) * 60);
  if (s === 60) {
    return `${sign}${d}° ${String(m + 1).padStart(2, '0')}' 00"`;
  }
  return `${sign}${d}° ${String(m).padStart(2, '0')}' ${String(s).padStart(2, '0')}"`;
}

/**
 * Coarse geomagnetic dipole declination estimate (degrees East positive)
 * for quick True North approximation when GPS is available.
 */
export function estimateMagneticDeclinationDeg(lat: number, lon: number): number {
  // Approximate magnetic north pole ~ (86.5°N, 164°E) -> tilted dipole model
  const poleLat = 80.7 * DEG_TO_RAD;
  const poleLon = -72.7 * DEG_TO_RAD;
  const latR = lat * DEG_TO_RAD;
  const lonR = lon * DEG_TO_RAD;
  const dLon = poleLon - lonR;
  const y = Math.sin(dLon) * Math.cos(poleLat);
  const x =
    Math.cos(latR) * Math.sin(poleLat) -
    Math.sin(latR) * Math.cos(poleLat) * Math.cos(dLon);
  return Number((Math.atan2(y, x) * RAD_TO_DEG).toFixed(1));
}

export const KAABA_COORDS = {
  latitude: 21.422487,
  longitude: 39.826206,
} as const;

export interface CityLocationPreset {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
}

export const INDONESIAN_CITY_PRESETS: CityLocationPreset[] = [
  { id: 'sumenep', name: 'Prenduan, Sumenep', latitude: -7.1186, longitude: 113.6628 },
  { id: 'jakarta', name: 'Jakarta', latitude: -6.2088, longitude: 106.8456 },
  { id: 'bandung', name: 'Bandung', latitude: -6.9175, longitude: 107.6191 },
  { id: 'yogyakarta', name: 'Yogyakarta', latitude: -7.7956, longitude: 110.3695 },
  { id: 'surabaya', name: 'Surabaya', latitude: -7.2575, longitude: 112.7521 },
  { id: 'medan', name: 'Medan', latitude: 3.5952, longitude: 98.6722 },
  { id: 'makassar', name: 'Makassar', latitude: -5.1477, longitude: 119.4327 },
  { id: 'aceh', name: 'Banda Aceh', latitude: 5.5483, longitude: 95.3238 },
  { id: 'jayapura', name: 'Jayapura', latitude: -2.5916, longitude: 140.6690 },
];

/**
 * Computes initial great-circle Qibla bearing (degrees clockwise from True North)
 * and Haversine distance in km from observer (lat, lon) to the Kaaba in Mecca.
 */
export function computeQiblaBearingAndDistance(
  latDeg: number,
  lonDeg: number
): { azimuth: number; distanceKm: number } {
  const lat1 = latDeg * DEG_TO_RAD;
  const lon1 = lonDeg * DEG_TO_RAD;
  const lat2 = KAABA_COORDS.latitude * DEG_TO_RAD;
  const lon2 = KAABA_COORDS.longitude * DEG_TO_RAD;

  const dLon = lon2 - lon1;
  const dLat = lat2 - lat1;

  const y = Math.sin(dLon);
  const x = Math.cos(lat1) * Math.tan(lat2) - Math.sin(lat1) * Math.cos(dLon);
  const azimuth = normalizeDeg360(Math.atan2(y, x) * RAD_TO_DEG);

  // Haversine great-circle distance
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanceKm = 6371 * c;

  return { azimuth, distanceKm };
}

