import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Camera,
  Compass,
  Crosshair,
  History,
  Lock,
  Navigation,
  Settings,
  SlidersHorizontal,
  Smartphone,
  Unlock,
  X,
} from 'lucide-react';
import { AndroidNativeGuide } from './components/AndroidNativeGuide';
import { CalibrationPanel } from './components/CalibrationPanel';
import { CaptureModal } from './components/CaptureModal';
import { OpticalHudCanvas } from './components/OpticalHudCanvas';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallButton';
import { SettingsModal } from './components/SettingsModal';
import { SightingsLogPanel } from './components/SightingsLogPanel';
import { useCameraStream } from './hooks/useCameraStream';
import { useGeoLocation } from './hooks/useGeoLocation';
import { useOrientationSensor } from './hooks/useOrientationSensor';
import {
  AimMode,
  CalibrationConfig,
  LocationPreference,
  QiblaInfo,
  SightingRecord,
} from './types/instrument';
import {
  computeQiblaBearingAndDistance,
  INDONESIAN_CITY_PRESETS,
  normalizeDeg360,
} from './utils/orientationMath';
import { renderAnnotatedSnapshot } from './utils/snapshotRenderer';

const STORAGE_CONFIG_KEY = 'altaz_lens_config_v1';
const STORAGE_RECORDS_KEY = 'altaz_lens_records_v1';
const STORAGE_LOCATION_KEY = 'bidik_location_pref_v1';

const DEFAULT_LOCATION: LocationPreference = {
  mode: 'gps',
  manualLatitude: -7.1186,
  manualLongitude: 113.6628,
  manualLabel: 'Prenduan, Sumenep',
};

const DEFAULT_CONFIG: CalibrationConfig = {
  azimuthOffset: 0,
  altitudeOffset: 0,
  smoothing: 0.55,
  verticalFov: 60,
  compassLang: 'id',
  showPitchLadder: true,
  showCompassTape: true,
  showDms: true,
};

type ConsoleTab = 'logs' | 'calibration' | 'android';

export default function App() {
  const [aimMode, setAimMode] = useState<AimMode>('camera');
  const [config, setConfig] = useState<CalibrationConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_CONFIG_KEY);
      return saved ? { ...DEFAULT_CONFIG, ...JSON.parse(saved) } : DEFAULT_CONFIG;
    } catch {
      return DEFAULT_CONFIG;
    }
  });

  const [records, setRecords] = useState<SightingRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_RECORDS_KEY);
      return saved ? (JSON.parse(saved) as SightingRecord[]) : [];
    } catch {
      return [];
    }
  });

  // Simulation pan angles (also used when no gyro sensor is present)
  const [simAngles, setSimAngles] = useState({
    azimuth: 78,
    altitude: 34,
    roll: 0,
  });

  const [isFrozen, setIsFrozen] = useState(false);
  const [frozenAngles, setFrozenAngles] = useState<{
    azimuth: number;
    altitude: number;
    roll: number;
  } | null>(null);

  const [qiblaEnabled, setQiblaEnabled] = useState(false);
  const [selectedCityId, setSelectedCityId] = useState('sumenep');
  const [locationPref, setLocationPref] = useState<LocationPreference>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_LOCATION_KEY);
      return saved ? { ...DEFAULT_LOCATION, ...JSON.parse(saved) } : DEFAULT_LOCATION;
    } catch {
      return DEFAULT_LOCATION;
    }
  });
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [activeTab, setActiveTab] = useState<ConsoleTab>('logs');
  const [mobileSheetOpen, setMobileSheetOpen] = useState(false);
  const [pendingCapture, setPendingCapture] = useState<{
    azimuth: number;
    altitude: number;
    roll: number;
    snapshotDataUrl?: string;
  } | null>(null);
  const [previewRecord, setPreviewRecord] = useState<SightingRecord | null>(null);

  const [customBackdrop, setCustomBackdrop] = useState<HTMLImageElement | null>(null);
  const simCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const camera = useCameraStream();
  const sensor = useOrientationSensor(config.smoothing, aimMode === 'camera');
  const { geo, requestLocation } = useGeoLocation();

  // Persist calibration config & location preference
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(config));
    } catch {
      // Ignore storage quota errors
    }
  }, [config]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_LOCATION_KEY, JSON.stringify(locationPref));
    } catch {
      // Ignore storage quota errors
    }
  }, [locationPref]);

  // Persist sighting records (trim oldest thumbnails if localStorage quota exceeded)
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_RECORDS_KEY, JSON.stringify(records));
    } catch {
      try {
        const trimmed = records.map((r, idx) =>
          idx < 8 ? r : { ...r, snapshotDataUrl: undefined }
        );
        localStorage.setItem(STORAGE_RECORDS_KEY, JSON.stringify(trimmed));
      } catch {
        // Ignore storage failure
      }
    }
  }, [records]);

  // Attempt automatic camera start on mount when on touch/mobile or user-friendly default;
  // on desktop without camera, user gets immediate Simulation option or 1-tap camera button.
  useEffect(() => {
    void camera.startCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Compute active calibrated angles
  const useLiveSensor = aimMode === 'camera' && sensor.hasLiveSensor;
  const rawAzimuth = useLiveSensor ? sensor.reading.azimuth : simAngles.azimuth;
  const rawAltitude = useLiveSensor ? sensor.reading.altitude : simAngles.altitude;
  const rawRoll = useLiveSensor ? sensor.reading.roll : simAngles.roll;

  const calibratedAzimuth = normalizeDeg360(rawAzimuth + config.azimuthOffset);
  const calibratedAltitude = Math.max(
    -90,
    Math.min(90, rawAltitude + config.altitudeOffset)
  );
  const calibratedRoll = rawRoll;

  const displayAzimuth =
    isFrozen && frozenAngles ? frozenAngles.azimuth : calibratedAzimuth;
  const displayAltitude =
    isFrozen && frozenAngles ? frozenAngles.altitude : calibratedAltitude;
  const displayRoll = isFrozen && frozenAngles ? frozenAngles.roll : calibratedRoll;

  const qiblaCoords =
    locationPref.mode === 'gps' &&
    geo.status === 'active' &&
    geo.latitude !== null &&
    geo.longitude !== null
      ? { lat: geo.latitude, lon: geo.longitude, label: 'GPS Aktif', isGps: true }
      : {
          lat: locationPref.manualLatitude,
          lon: locationPref.manualLongitude,
          label: locationPref.manualLabel || 'Lokasi Manual',
          isGps: false,
        };
  const qiblaCalc = computeQiblaBearingAndDistance(qiblaCoords.lat, qiblaCoords.lon);
  const qiblaInfo: QiblaInfo = {
    enabled: qiblaEnabled,
    azimuth: qiblaCalc.azimuth,
    distanceKm: qiblaCalc.distanceKm,
    sourceLabel: qiblaCoords.label,
    isGps: qiblaCoords.isGps,
  };

  const handleSelectCityPreset = useCallback((cityId: string) => {
    setSelectedCityId(cityId);
    const city = INDONESIAN_CITY_PRESETS.find((c) => c.id === cityId);
    if (city) {
      setLocationPref({
        mode: 'manual',
        manualLatitude: city.latitude,
        manualLongitude: city.longitude,
        manualLabel: city.name,
      });
    }
  }, []);

  const handleToggleQibla = useCallback(() => {
    setQiblaEnabled((prev) => {
      const next = !prev;
      if (next && locationPref.mode === 'gps' && geo.status === 'idle') {
        requestLocation();
      }
      return next;
    });
  }, [geo.status, locationPref.mode, requestLocation]);

  const handleUpdateConfig = useCallback((patch: Partial<CalibrationConfig>) => {
    setConfig((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleZeroAltitude = useCallback(() => {
    // Sets altitudeOffset so current physical pitch reads 0.0°
    const offset = Math.max(-15, Math.min(15, -rawAltitude));
    setConfig((prev) => ({ ...prev, altitudeOffset: Number(offset.toFixed(1)) }));
  }, [rawAltitude]);

  const handleResetOffsets = useCallback(() => {
    setConfig(DEFAULT_CONFIG);
  }, []);

  const handleToggleFreeze = useCallback(() => {
    if (!isFrozen) {
      setFrozenAngles({
        azimuth: calibratedAzimuth,
        altitude: calibratedAltitude,
        roll: calibratedRoll,
      });
      setIsFrozen(true);
    } else {
      setIsFrozen(false);
      setFrozenAngles(null);
    }
  }, [calibratedAltitude, calibratedAzimuth, calibratedRoll, isFrozen]);

  const handleSwitchMode = useCallback(
    (nextMode: AimMode) => {
      setAimMode(nextMode);
      setIsFrozen(false);
      setFrozenAngles(null);
      if (nextMode === 'camera') {
        void camera.startCamera();
        if (sensor.permissionState === 'prompt') {
          void sensor.requestSensorPermission();
        }
      } else {
        camera.stopCamera();
      }
    },
    [camera, sensor]
  );

  const handleAdjustSimulation = useCallback((deltaAz: number, deltaAlt: number) => {
    setSimAngles((prev) => ({
      ...prev,
      azimuth: normalizeDeg360(prev.azimuth + deltaAz),
      altitude: Math.max(-89.9, Math.min(89.9, prev.altitude + deltaAlt)),
    }));
  }, []);

  const activeLat =
    locationPref.mode === 'gps' ? geo.latitude : locationPref.manualLatitude;
  const activeLon =
    locationPref.mode === 'gps' ? geo.longitude : locationPref.manualLongitude;

  const handleCaptureClick = useCallback(() => {
    const snapshotDataUrl = renderAnnotatedSnapshot({
      videoElement: aimMode === 'camera' && camera.status === 'active' ? camera.videoRef.current : null,
      simCanvasElement: simCanvasRef.current,
      azimuth: displayAzimuth,
      altitude: displayAltitude,
      roll: displayRoll,
      latitude: activeLat,
      longitude: activeLon,
      lang: config.compassLang,
    });

    setPendingCapture({
      azimuth: displayAzimuth,
      altitude: displayAltitude,
      roll: displayRoll,
      snapshotDataUrl,
    });
  }, [
    activeLat,
    activeLon,
    aimMode,
    camera.status,
    camera.videoRef,
    config.compassLang,
    displayAltitude,
    displayAzimuth,
    displayRoll,
  ]);

  const handleSaveCapture = useCallback(
    (label: string, note: string) => {
      if (!pendingCapture) return;
      const newRecord: SightingRecord = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        label,
        note,
        azimuth: pendingCapture.azimuth,
        altitude: pendingCapture.altitude,
        roll: pendingCapture.roll,
        latitude: activeLat,
        longitude: activeLon,
        timestamp: Date.now(),
        source: useLiveSensor ? 'sensor' : 'simulation',
        snapshotDataUrl: pendingCapture.snapshotDataUrl,
      };
      setRecords((prev) => [newRecord, ...prev]);
      setPendingCapture(null);
      setActiveTab('logs');
    },
    [activeLat, activeLon, pendingCapture, useLiveSensor]
  );

  const handleUploadBackdrop = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') return;
      const img = new Image();
      img.onload = () => setCustomBackdrop(img);
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  }, []);

  const handleClearBackdrop = useCallback(() => {
    setCustomBackdrop(null);
  }, []);

  const openMobileSheet = (tab: ConsoleTab) => {
    setActiveTab(tab);
    setMobileSheetOpen(true);
  };

  return (
    <div className="h-dvh w-full bg-[#07090E] text-slate-100 flex flex-col lg:grid lg:grid-cols-[1fr_390px] overflow-hidden">
      {/* Main Optical Viewfinder Stage */}
      <main className="relative flex-1 h-full overflow-hidden">
        {/* Top Compact Instrument Ribbon (keeps mobile sticky chrome compact) */}
        <header className="absolute inset-x-0 top-0 z-30 pt-safe">
          <div className="h-13 px-3 sm:px-5 flex items-center justify-between gap-3 bg-gradient-to-b from-[#07090E]/90 via-[#07090E]/60 to-transparent">
            <div className="flex items-center gap-2.5 min-w-0">
              <img
                src="/assets/aistudio/AddText_11-15-05.40.35_1363302e.png"
                alt="Logo Bidik"
                referrerPolicy="no-referrer"
                className="w-6 h-6 rounded-full object-cover shrink-0"
              />
              <span className="text-sm sm:text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0">
                Bidik
              </span>
              <span className="hidden sm:inline text-slate-500" aria-hidden="true">
                ·
              </span>
              <span className="hidden sm:inline text-xs text-slate-300 truncate">
                {aimMode === 'camera'
                  ? useLiveSensor
                    ? 'Kamera · Sensor Aktif'
                    : 'Kamera · Drag Simulasi'
                  : 'Mode Simulasi Langit'}
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {/* Segmented Mode Switcher */}
              <div
                className="flex items-center rounded-lg border border-slate-800 bg-[#0B0E17]/90 p-0.5"
                role="group"
                aria-label="Pilih mode penglihatan"
              >
                <button
                  type="button"
                  onClick={() => handleSwitchMode('camera')}
                  className={`min-h-[34px] inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    aimMode === 'camera'
                      ? 'bg-cyan-500 text-slate-950 font-semibold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Kamera</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleSwitchMode('simulation')}
                  className={`min-h-[34px] inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    aimMode === 'simulation'
                      ? 'bg-amber-500 text-slate-950 font-semibold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <Compass className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Simulasi</span>
                </button>
              </div>

              <PWAInstallButton />

              <button
                type="button"
                onClick={() => setSettingsOpen(true)}
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/90 px-2.5 text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                aria-label="Buka pengaturan aplikasi"
                title="Pengaturan"
              >
                <Settings className="w-4 h-4 text-slate-300" aria-hidden="true" />
                <span className="hidden md:inline">Pengaturan</span>
              </button>
            </div>
          </div>
        </header>

        {/* Optical Viewfinder & HUD Overlay */}
        <OpticalHudCanvas
          aimMode={aimMode}
          videoRef={camera.videoRef}
          simCanvasRef={simCanvasRef}
          cameraStatus={camera.status}
          cameraError={camera.errorMessage}
          sensorPermission={sensor.permissionState}
          hasLiveSensor={sensor.hasLiveSensor}
          azimuth={displayAzimuth}
          altitude={displayAltitude}
          roll={displayRoll}
          isFrozen={isFrozen}
          config={config}
          zoom={camera.zoom}
          customBackdrop={customBackdrop}
          qibla={qiblaInfo}
          onStartCamera={() => void camera.startCamera()}
          onRequestSensor={() => void sensor.requestSensorPermission()}
          onRequestLocation={() => {
            setLocationPref((prev) => ({ ...prev, mode: 'gps' }));
            requestLocation();
          }}
          onSwitchToSimulation={() => handleSwitchMode('simulation')}
          onAdjustSimulation={handleAdjustSimulation}
          onApplyZoom={(z) => void camera.applyZoom(z)}
        />

        {/* Bottom Thumb-Zone Action Bar */}
        <div className="absolute inset-x-0 bottom-0 z-30 pb-safe">
          <div className="h-20 px-3 sm:px-4 flex items-center justify-between sm:justify-center gap-2 sm:gap-4 bg-gradient-to-t from-[#07090E] via-[#07090E]/85 to-transparent">
            {/* Hold / Lock Angle */}
            <button
              type="button"
              onClick={handleToggleFreeze}
              className={`min-h-[46px] inline-flex items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                isFrozen
                  ? 'border-amber-500 bg-amber-500/20 text-amber-300'
                  : 'border-slate-700/90 bg-[#0B0E17]/90 text-slate-200 hover:bg-slate-800'
              }`}
            >
              {isFrozen ? (
                <Unlock className="w-4 h-4" aria-hidden="true" />
              ) : (
                <Lock className="w-4 h-4" aria-hidden="true" />
              )}
              <span>{isFrozen ? 'Lepas' : 'Tahan'}</span>
            </button>

            {/* Qibla Finder Toggle */}
            <button
              type="button"
              onClick={handleToggleQibla}
              aria-pressed={qiblaEnabled}
              className={`min-h-[46px] inline-flex items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                qiblaEnabled
                  ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300'
                  : 'border-slate-700/90 bg-[#0B0E17]/90 text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Navigation className="w-4 h-4" aria-hidden="true" />
              <span>Kiblat</span>
            </button>

            {/* Primary Capture / Bidik Shutter */}
            <button
              type="button"
              onClick={handleCaptureClick}
              className="min-h-[50px] inline-flex items-center justify-center gap-1.5 rounded-2xl bg-cyan-500 px-4 sm:px-6 py-3 text-xs sm:text-sm font-bold text-slate-950 hover:bg-cyan-400 active:scale-[0.98] transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Crosshair className="w-4 h-4" aria-hidden="true" />
              <span className="sm:hidden">Bidik</span>
              <span className="hidden sm:inline">Bidik & Simpan</span>
            </button>

            {/* Mobile Sheet Triggers (Hidden on Desktop where Side Console is visible) */}
            <div className="flex items-center gap-1.5 lg:hidden shrink-0">
              <button
                type="button"
                onClick={() => openMobileSheet('logs')}
                className="min-h-[44px] min-w-[44px] relative inline-flex items-center justify-center rounded-xl border border-slate-700/90 bg-[#0B0E17]/90 text-slate-200 hover:bg-slate-800 cursor-pointer"
                aria-label="Buka riwayat bidikan"
              >
                <History className="w-4 h-4" />
                {records.length > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-cyan-500 font-mono text-[10px] font-bold text-slate-950 flex items-center justify-center tabular-nums">
                    {records.length}
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => openMobileSheet('calibration')}
                className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl border border-slate-700/90 bg-[#0B0E17]/90 text-slate-200 hover:bg-slate-800 cursor-pointer"
                aria-label="Buka kalibrasi dan panduan Android"
              >
                <SlidersHorizontal className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Desktop Precision Side Console */}
      <aside className="hidden lg:flex flex-col h-full border-l border-slate-800 bg-[#0B0E17]">
        <div className="p-3 border-b border-slate-800">
          <div className="grid grid-cols-3 gap-1 rounded-xl bg-[#07090E] p-1 border border-slate-800/80">
            <button
              type="button"
              onClick={() => setActiveTab('logs')}
              className={`min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'logs'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <History className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Riwayat ({records.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('calibration')}
              className={`min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'calibration'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Kalibrasi</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('android')}
              className={`min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'android'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Android</span>
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {activeTab === 'logs' && (
            <SightingsLogPanel
              records={records}
              lang={config.compassLang}
              onDelete={(id) => setRecords((prev) => prev.filter((r) => r.id !== id))}
              onClearAll={() => setRecords([])}
              onSelectPreview={(rec) => setPreviewRecord(rec)}
            />
          )}
          {activeTab === 'calibration' && (
            <CalibrationPanel
              aimMode={aimMode}
              config={config}
              reading={sensor.reading}
              geo={geo}
              devices={camera.devices}
              selectedDeviceId={camera.selectedDeviceId}
              hasLiveSensor={sensor.hasLiveSensor}
              selectedCityId={selectedCityId}
              onSelectCity={handleSelectCityPreset}
              onUpdateConfig={handleUpdateConfig}
              onZeroAltitude={handleZeroAltitude}
              onResetOffsets={handleResetOffsets}
              onRequestLocation={requestLocation}
              onToggleFacing={camera.toggleFacingMode}
              onSelectDevice={camera.selectDevice}
              onUploadBackdrop={handleUploadBackdrop}
              onClearBackdrop={handleClearBackdrop}
              hasCustomBackdrop={!!customBackdrop}
            />
          )}
          {activeTab === 'android' && <AndroidNativeGuide />}
        </div>
      </aside>

      {/* Mobile Bottom Sheet Drawer */}
      {mobileSheetOpen && (
        <div
          className="fixed inset-0 z-50 lg:hidden flex items-end bg-black/70 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-h-[82dvh] flex flex-col rounded-t-3xl border-t border-slate-800 bg-[#0B0E17]">
            <div className="pt-2.5 pb-2 px-4 flex items-center justify-between border-b border-slate-800">
              <div className="grid grid-cols-3 gap-1 rounded-xl bg-[#07090E] p-1 border border-slate-800 flex-1 mr-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('logs')}
                  className={`min-h-[38px] rounded-lg px-2 text-xs font-medium whitespace-nowrap cursor-pointer ${
                    activeTab === 'logs' ? 'bg-slate-800 text-white' : 'text-slate-400'
                  }`}
                >
                  Riwayat ({records.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('calibration')}
                  className={`min-h-[38px] rounded-lg px-2 text-xs font-medium whitespace-nowrap cursor-pointer ${
                    activeTab === 'calibration' ? 'bg-slate-800 text-white' : 'text-slate-400'
                  }`}
                >
                  Kalibrasi
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('android')}
                  className={`min-h-[38px] rounded-lg px-2 text-xs font-medium whitespace-nowrap cursor-pointer ${
                    activeTab === 'android' ? 'bg-slate-800 text-white' : 'text-slate-400'
                  }`}
                >
                  Android
                </button>
              </div>
              <button
                type="button"
                onClick={() => setMobileSheetOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                aria-label="Tutup panel"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 pb-safe">
              {activeTab === 'logs' && (
                <SightingsLogPanel
                  records={records}
                  lang={config.compassLang}
                  onDelete={(id) => setRecords((prev) => prev.filter((r) => r.id !== id))}
                  onClearAll={() => setRecords([])}
                  onSelectPreview={(rec) => setPreviewRecord(rec)}
                />
              )}
              {activeTab === 'calibration' && (
                <CalibrationPanel
                  aimMode={aimMode}
                  config={config}
                  reading={sensor.reading}
                  geo={geo}
                  devices={camera.devices}
                  selectedDeviceId={camera.selectedDeviceId}
                  hasLiveSensor={sensor.hasLiveSensor}
                  selectedCityId={selectedCityId}
                  onSelectCity={handleSelectCityPreset}
                  onUpdateConfig={handleUpdateConfig}
                  onZeroAltitude={handleZeroAltitude}
                  onResetOffsets={handleResetOffsets}
                  onRequestLocation={requestLocation}
                  onToggleFacing={camera.toggleFacingMode}
                  onSelectDevice={camera.selectDevice}
                  onUploadBackdrop={handleUploadBackdrop}
                  onClearBackdrop={handleClearBackdrop}
                  hasCustomBackdrop={!!customBackdrop}
                />
              )}
              {activeTab === 'android' && <AndroidNativeGuide />}
            </div>
          </div>
        </div>
      )}

      {/* Capture / Save Modal */}
      {pendingCapture && (
        <CaptureModal
          azimuth={pendingCapture.azimuth}
          altitude={pendingCapture.altitude}
          roll={pendingCapture.roll}
          snapshotDataUrl={pendingCapture.snapshotDataUrl}
          lang={config.compassLang}
          onSave={handleSaveCapture}
          onCancel={() => setPendingCapture(null)}
        />
      )}

      {/* Saved Photo Preview Lightbox */}
      {previewRecord?.snapshotDataUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => setPreviewRecord(null)}
        >
          <div
            className="w-full max-w-2xl rounded-2xl border border-slate-800 bg-[#0B0E17] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-white truncate">
                  {previewRecord.label}
                </h4>
                <p className="font-mono text-xs text-slate-400 tabular-nums">
                  Alt {previewRecord.altitude >= 0 ? '+' : ''}
                  {previewRecord.altitude.toFixed(1)}° · Az {previewRecord.azimuth.toFixed(1)}°
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewRecord(null)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white cursor-pointer"
                aria-label="Tutup pratinjau"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <img
              src={previewRecord.snapshotDataUrl}
              alt={previewRecord.label}
              className="w-full max-h-[75dvh] object-contain bg-black"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      )}

      {settingsOpen && (
        <SettingsModal
          geo={geo}
          locationPref={locationPref}
          onUpdateLocationPref={setLocationPref}
          onRequestLocation={requestLocation}
          onClose={() => setSettingsOpen(false)}
        />
      )}

      <OfflineIndicator />
    </div>
  );
}
