import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const androidDir = path.join(root, 'android');
const appDir = path.join(androidDir, 'app');
const mainDir = path.join(appDir, 'src', 'main');
const manifestPath = path.join(mainDir, 'AndroidManifest.xml');
const buildGradlePath = path.join(appDir, 'build.gradle');
const resDir = path.join(mainDir, 'res');
const logoSource = path.join(root, 'public', 'assets', 'aistudio', 'AddText_11-16-08.30.35_6d5add7e.png');

if (!fs.existsSync(manifestPath) || !fs.existsSync(buildGradlePath)) {
  console.error('Android project not found. Run "npx cap add android" first.');
  process.exit(1);
}

// 1. Inject required hardware & runtime permissions into AndroidManifest.xml
let manifest = fs.readFileSync(manifestPath, 'utf8');
const requiredEntries = [
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
  '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.compass" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.accelerometer" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.gyroscope" android:required="false" />',
];

const missingEntries = requiredEntries.filter((entry) => !manifest.includes(entry));
if (missingEntries.length > 0) {
  manifest = manifest.replace(
    '</manifest>',
    `    ${missingEntries.join('\n    ')}\n</manifest>`
  );
  fs.writeFileSync(manifestPath, manifest, 'utf8');
  console.log(`Added ${missingEntries.length} permission/feature entries to AndroidManifest.xml`);
}

// 2. Configure release signingConfigs & dynamic versionCode in app/build.gradle
let gradle = fs.readFileSync(buildGradlePath, 'utf8');
const versionCode = Number(process.env.ANDROID_VERSION_CODE || '1') || 1;
gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
gradle = gradle.replace(/versionName\s+"[^"]*"/, 'versionName "1.0"');

if (!gradle.includes('signingConfigs')) {
  const signingBlock = `    signingConfigs {
        release {
            def ksPath = System.getenv("ANDROID_KEYSTORE_PATH")
            if (ksPath != null && file(ksPath).exists()) {
                storeFile file(ksPath)
                storePassword System.getenv("ANDROID_KEYSTORE_PASSWORD")
                keyAlias System.getenv("ANDROID_KEY_ALIAS")
                keyPassword System.getenv("ANDROID_KEY_PASSWORD")
            }
        }
    }
    buildTypes {`;

  gradle = gradle.replace(/buildTypes\s*\{/, signingBlock);
  gradle = gradle.replace(
    /release\s*\{([\s\S]*?)minifyEnabled\s+(true|false)/,
    `release {$1minifyEnabled $2\n            signingConfig signingConfigs.release`
  );
  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
  console.log(`Configured release signingConfig and versionCode=${versionCode} in app/build.gradle`);
}

// 3. Replace default Capacitor launcher icons & 120dp native splash logo with Bidik's attached logo
let hasConvert = false;
try {
  execFileSync('convert', ['-version'], { stdio: 'ignore' });
  hasConvert = true;
} catch {
  hasConvert = false;
}

if (fs.existsSync(logoSource)) {
  const prePaddedFg = path.join(root, 'public', 'android-icon-foreground.png');
  const preSplashXxhdpi = path.join(root, 'public', 'android-splash-logo.png');
  const fallback192 = path.join(root, 'public', 'pwa-192x192.png');

  const mipmapSizes = [
    { folder: 'mipmap-mdpi', launcher: 48, foreground: 108 },
    { folder: 'mipmap-hdpi', launcher: 72, foreground: 162 },
    { folder: 'mipmap-xhdpi', launcher: 96, foreground: 216 },
    { folder: 'mipmap-xxhdpi', launcher: 144, foreground: 324 },
    { folder: 'mipmap-xxxhdpi', launcher: 192, foreground: 432 },
  ];

  for (const spec of mipmapSizes) {
    const dir = path.join(resDir, spec.folder);
    fs.mkdirSync(dir, { recursive: true });
    const launcherPath = path.join(dir, 'ic_launcher.png');
    const roundPath = path.join(dir, 'ic_launcher_round.png');
    const fgPath = path.join(dir, 'ic_launcher_foreground.png');

    if (hasConvert) {
      execFileSync('convert', [
        logoSource,
        '-resize',
        `${spec.launcher}x${spec.launcher}`,
        launcherPath,
      ]);
      fs.copyFileSync(launcherPath, roundPath);

      const innerFg = Math.round(spec.foreground * 0.66);
      execFileSync('convert', [
        logoSource,
        '-trim',
        '+repage',
        '-resize',
        `${innerFg}x${innerFg}`,
        '-background',
        'none',
        '-gravity',
        'center',
        '-extent',
        `${spec.foreground}x${spec.foreground}`,
        fgPath,
      ]);
    } else {
      const legacySrc = fs.existsSync(fallback192) ? fallback192 : logoSource;
      const fgSrc = fs.existsSync(prePaddedFg) ? prePaddedFg : legacySrc;
      fs.copyFileSync(legacySrc, launcherPath);
      fs.copyFileSync(legacySrc, roundPath);
      fs.copyFileSync(fgSrc, fgPath);
    }
  }

  // Place pre-composed 288dp (864px xxhdpi) Bidik logo + BIDIK text splash drawable
  const xxhdpiDir = path.join(resDir, 'drawable-xxhdpi');
  fs.mkdirSync(xxhdpiDir, { recursive: true });
  const splashSrc = fs.existsSync(preSplashXxhdpi) ? preSplashXxhdpi : logoSource;
  fs.copyFileSync(splashSrc, path.join(xxhdpiDir, 'bidik_splash_logo.png'));

  const drawableDir = path.join(resDir, 'drawable');
  fs.mkdirSync(drawableDir, { recursive: true });

  fs.writeFileSync(
    path.join(drawableDir, 'splash_bidik.xml'),
    `<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@color/bidik_splash_bg" />
    <item>
        <bitmap
            android:gravity="center"
            android:src="@drawable/bidik_splash_logo" />
    </item>
</layer-list>
`,
    'utf8'
  );
  console.log('Updated Android mipmap icons and Bidik + BIDIK text splash drawable');
}

// 4. Enforce dark fullscreen theme & seamless Bidik blue launcher background in styles.xml & colors
const valuesDir = path.join(resDir, 'values');
fs.mkdirSync(valuesDir, { recursive: true });

fs.writeFileSync(
  path.join(valuesDir, 'ic_launcher_background.xml'),
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#0057D3</color>
    <color name="bidik_splash_bg">#FFFFFF</color>
</resources>
`,
  'utf8'
);

const stylesPath = path.join(valuesDir, 'styles.xml');
fs.writeFileSync(
  stylesPath,
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.NoActionBar">
        <item name="colorPrimary">#07090E</item>
        <item name="colorPrimaryDark">#07090E</item>
        <item name="colorAccent">#06B6D4</item>
        <item name="android:windowBackground">#07090E</item>
    </style>

    <style name="AppTheme.NoActionBar" parent="Theme.AppCompat.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
        <item name="android:windowBackground">#07090E</item>
        <item name="android:windowFullscreen">true</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:windowLightNavigationBar">false</item>
        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>
    </style>

    <style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">
        <item name="android:background">@drawable/splash_bidik</item>
        <item name="windowSplashScreenBackground">#FFFFFF</item>
        <item name="windowSplashScreenAnimatedIcon">@drawable/bidik_splash_logo</item>
        <item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>
    </style>
</resources>
`,
  'utf8'
);
console.log('Configured dark fullscreen styles.xml with white Bidik 100dp launch splash');

// 5. Patch MainActivity.java to enable immersive edge-to-edge fullscreen & native BidikStorage bridge
const mainActivityPath = path.join(mainDir, 'java', 'com', 'ahmadazizi', 'bidik', 'MainActivity.java');
if (fs.existsSync(mainActivityPath)) {
  fs.writeFileSync(
    mainActivityPath,
    `package com.ahmadazizi.bidik;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.hardware.GeomagneticField;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyFullscreenMode();
        if (this.bridge != null && this.bridge.getWebView() != null) {
            this.bridge.getWebView().addJavascriptInterface(new BidikStorage(this), "BidikStorage");
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyFullscreenMode();
        }
    }

    private void applyFullscreenMode() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (controller != null) {
            controller.setAppearanceLightStatusBars(false);
            controller.setAppearanceLightNavigationBars(false);
            controller.hide(WindowInsetsCompat.Type.systemBars());
            controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            );
        }
    }

    public static class BidikStorage {
        private final Context context;

        public BidikStorage(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public String saveJpegToGallery(String base64Data, String filename) {
            try {
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                String safeName = (filename == null || filename.isEmpty())
                    ? ("bidik-" + System.currentTimeMillis() + ".jpg")
                    : filename;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = context.getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    values.put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/Bidik"
                    );
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);

                    Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) {
                        return "ERROR:MediaStore uri null";
                    }
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out == null) {
                            return "ERROR:OutputStream null";
                        }
                        out.write(bytes);
                        out.flush();
                    }
                    values.clear();
                    values.put(MediaStore.Images.Media.IS_PENDING, 0);
                    resolver.update(uri, values, null, null);
                    return "OK:" + uri.toString();
                } else {
                    File picturesDir = new File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                        "Bidik"
                    );
                    if (!picturesDir.exists() && !picturesDir.mkdirs()) {
                        return "ERROR:mkdirs failed";
                    }
                    File outFile = new File(picturesDir, safeName);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                        fos.flush();
                    }
                    MediaScannerConnection.scanFile(
                        context,
                        new String[] { outFile.getAbsolutePath() },
                        new String[] { "image/jpeg" },
                        null
                    );
                    return "OK:" + outFile.getAbsolutePath();
                }
            } catch (Exception e) {
                return "ERROR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String saveTextFile(String content, String filename, String mimeType) {
            try {
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                String safeName = (filename == null || filename.isEmpty())
                    ? ("bidik-" + System.currentTimeMillis() + ".csv")
                    : filename;
                String safeMime = (mimeType == null || mimeType.isEmpty()) ? "text/csv" : mimeType;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = context.getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, safeMime);
                    values.put(
                        MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Bidik"
                    );
                    values.put(MediaStore.Downloads.IS_PENDING, 1);

                    Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) {
                        return "ERROR:MediaStore uri null";
                    }
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out == null) {
                            return "ERROR:OutputStream null";
                        }
                        out.write(bytes);
                        out.flush();
                    }
                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    resolver.update(uri, values, null, null);
                    return "OK:" + uri.toString();
                } else {
                    File dlDir = new File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        "Bidik"
                    );
                    if (!dlDir.exists() && !dlDir.mkdirs()) {
                        return "ERROR:mkdirs failed";
                    }
                    File outFile = new File(dlDir, safeName);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                        fos.flush();
                    }
                    MediaScannerConnection.scanFile(
                        context,
                        new String[] { outFile.getAbsolutePath() },
                        new String[] { safeMime },
                        null
                    );
                    return "OK:" + outFile.getAbsolutePath();
                }
            } catch (Exception e) {
                return "ERROR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public double getGeomagneticDeclination(double lat, double lon, double altMeters) {
            GeomagneticField field = new GeomagneticField(
                (float) lat,
                (float) lon,
                (float) altMeters,
                System.currentTimeMillis()
            );
            return field.getDeclination();
        }

        @JavascriptInterface
        public String fetchWmmCoefficients() {
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://www.ncei.noaa.gov/sites/default/files/2024-12/WMM2025COF.zip");
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(12000);
                conn.setRequestMethod("GET");
                if (conn.getResponseCode() != 200) {
                    return "ERROR:HTTP " + conn.getResponseCode();
                }
                try (InputStream is = conn.getInputStream();
                     ZipInputStream zis = new ZipInputStream(is)) {
                    ZipEntry entry;
                    while ((entry = zis.getNextEntry()) != null) {
                        if (entry.getName().toUpperCase().endsWith(".COF")) {
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            byte[] buffer = new byte[4096];
                            int len;
                            while ((len = zis.read(buffer)) > 0) {
                                baos.write(buffer, 0, len);
                            }
                            return baos.toString(StandardCharsets.UTF_8.name());
                        }
                    }
                }
                return "ERROR:WMM.COF not found in archive";
            } catch (Exception e) {
                return "ERROR:" + e.getMessage();
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }
    }
}
`,
    'utf8'
  );
  console.log('Updated MainActivity.java for immersive fullscreen & native BidikStorage');
}
