import { CompassLanguage } from '../types/instrument';
import { get8PointCardinalAbbr, normalizeDeg180, normalizeDeg360 } from './orientationMath';

interface SimLandmark {
  name: string;
  azimuth: number;
  altitude: number;
  kind: 'sun' | 'moon' | 'tower' | 'peak' | 'satellite';
}

const LANDMARKS: SimLandmark[] = [
  { name: 'Matahari', azimuth: 78, altitude: 34, kind: 'sun' },
  { name: 'Bulan', azimuth: 215, altitude: 48, kind: 'moon' },
  { name: 'Menara Pemancar', azimuth: 142, altitude: 11, kind: 'tower' },
  { name: 'Puncak Gunung', azimuth: 295, altitude: 7.5, kind: 'peak' },
  { name: 'Stasiun ISS', azimuth: 28, altitude: 61, kind: 'satellite' },
];

/**
 * Draws an interactive 3D-projected sky dome & horizon panorama onto a 2D canvas
 * centered on (viewAzimuth, viewAltitude) with horizon roll and vertical FOV.
 */
export function renderSimulationDome(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  viewAzimuth: number,
  viewAltitude: number,
  rollDeg: number,
  verticalFovDeg: number,
  lang: CompassLanguage,
  customBackdropImage?: HTMLImageElement | null
) {
  ctx.clearRect(0, 0, width, height);

  if (customBackdropImage && customBackdropImage.complete && customBackdropImage.naturalWidth > 0) {
    // Cover fit custom uploaded photo
    const imgRatio = customBackdropImage.naturalWidth / customBackdropImage.naturalHeight;
    const canvasRatio = width / height;
    let drawW = width;
    let drawH = height;
    let drawX = 0;
    let drawY = 0;
    if (imgRatio > canvasRatio) {
      drawW = height * imgRatio;
      drawX = (width - drawW) / 2;
    } else {
      drawH = width / imgRatio;
      drawY = (height - drawH) / 2;
    }
    ctx.drawImage(customBackdropImage, drawX, drawY, drawW, drawH);
    ctx.fillStyle = 'rgba(7, 9, 14, 0.25)';
    ctx.fillRect(0, 0, width, height);
    return;
  }

  const pxPerDeg = height / Math.max(25, verticalFovDeg);
  const cx = width / 2;
  const cy = height / 2;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate((-rollDeg * Math.PI) / 180);

  // Horizon vertical offset relative to center
  const horizonOffsetY = viewAltitude * pxPerDeg;
  const span = Math.max(width, height) * 1.6;

  // Sky gradient above horizon
  const skyGrad = ctx.createLinearGradient(0, horizonOffsetY - 90 * pxPerDeg, 0, horizonOffsetY);
  skyGrad.addColorStop(0, '#040711');
  skyGrad.addColorStop(0.55, '#0B162C');
  skyGrad.addColorStop(1, '#1A3452');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(-span, -span, span * 2, span + horizonOffsetY);

  // Ground gradient below horizon
  const groundGrad = ctx.createLinearGradient(0, horizonOffsetY, 0, horizonOffsetY + 90 * pxPerDeg);
  groundGrad.addColorStop(0, '#18222C');
  groundGrad.addColorStop(0.4, '#0F151C');
  groundGrad.addColorStop(1, '#07090E');
  ctx.fillStyle = groundGrad;
  ctx.fillRect(-span, horizonOffsetY, span * 2, span);

  // Draw altitude parallels every 15°
  ctx.lineWidth = 1;
  ctx.font = '500 11px "JetBrains Mono", monospace';
  ctx.textAlign = 'left';

  for (let alt = -75; alt <= 75; alt += 15) {
    const y = (viewAltitude - alt) * pxPerDeg;
    if (Math.abs(y) > span) continue;
    ctx.strokeStyle = alt === 0 ? 'rgba(6, 182, 212, 0.45)' : 'rgba(148, 163, 184, 0.14)';
    ctx.beginPath();
    ctx.moveTo(-span, y);
    ctx.lineTo(span, y);
    ctx.stroke();
  }

  // Draw azimuth meridians every 15°
  const horizFov = (width / height) * verticalFovDeg;
  const startAz = Math.floor((viewAzimuth - horizFov) / 15) * 15;
  const endAz = Math.ceil((viewAzimuth + horizFov) / 15) * 15;

  for (let az = startAz; az <= endAz; az += 15) {
    const dAz = normalizeDeg180(az - viewAzimuth);
    const cosAlt = Math.max(0.22, Math.cos((viewAltitude * Math.PI) / 180));
    const x = dAz * cosAlt * pxPerDeg;
    if (Math.abs(x) > span) continue;

    const normAz = normalizeDeg360(az);
    const isCardinal = normAz % 45 === 0;
    ctx.strokeStyle = isCardinal ? 'rgba(6, 182, 212, 0.25)' : 'rgba(148, 163, 184, 0.1)';
    ctx.beginPath();
    ctx.moveTo(x, -span);
    ctx.lineTo(x, span);
    ctx.stroke();

    const abbr = get8PointCardinalAbbr(normAz, lang);
    if (abbr) {
      ctx.fillStyle = 'rgba(241, 245, 249, 0.65)';
      ctx.textAlign = 'center';
      ctx.fillText(`${abbr} ${normAz}°`, x, horizonOffsetY + 18);
    }
  }

  // Subtle mountain ridge silhouette along the horizon
  ctx.fillStyle = 'rgba(12, 19, 28, 0.85)';
  ctx.beginPath();
  ctx.moveTo(-span, horizonOffsetY + 2);
  for (let px = -span; px <= span; px += 14) {
    const worldAz = viewAzimuth + px / pxPerDeg;
    const rad = (worldAz * Math.PI) / 180;
    const ridgeH =
      (Math.sin(rad * 3) * 1.6 +
        Math.cos(rad * 7 + 1.2) * 1.1 +
        Math.sin(rad * 13) * 0.45 +
        2.5) *
      pxPerDeg;
    ctx.lineTo(px, horizonOffsetY - Math.max(0, ridgeH * 0.45));
  }
  ctx.lineTo(span, horizonOffsetY + 24);
  ctx.lineTo(-span, horizonOffsetY + 24);
  ctx.closePath();
  ctx.fill();

  // Render simulated landmarks in sky/horizon
  for (const lm of LANDMARKS) {
    const dAz = normalizeDeg180(lm.azimuth - viewAzimuth);
    const cosAlt = Math.max(0.25, Math.cos((lm.altitude * Math.PI) / 180));
    const x = dAz * cosAlt * pxPerDeg;
    const y = (viewAltitude - lm.altitude) * pxPerDeg;

    if (Math.abs(x) > width * 0.85 || Math.abs(y) > height * 0.85) continue;

    if (lm.kind === 'sun') {
      const glow = ctx.createRadialGradient(x, y, 4, x, y, 42);
      glow.addColorStop(0, 'rgba(251, 191, 36, 0.95)');
      glow.addColorStop(0.35, 'rgba(245, 158, 11, 0.35)');
      glow.addColorStop(1, 'rgba(245, 158, 11, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(x, y, 42, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#FEF08A';
      ctx.beginPath();
      ctx.arc(x, y, 11, 0, Math.PI * 2);
      ctx.fill();
    } else if (lm.kind === 'moon') {
      ctx.fillStyle = 'rgba(226, 232, 240, 0.92)';
      ctx.beginPath();
      ctx.arc(x, y, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0B162C';
      ctx.beginPath();
      ctx.arc(x + 4, y - 2, 8.5, 0, Math.PI * 2);
      ctx.fill();
    } else if (lm.kind === 'tower') {
      ctx.strokeStyle = '#94A3B8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x - 8, horizonOffsetY);
      ctx.lineTo(x, y);
      ctx.lineTo(x + 8, horizonOffsetY);
      ctx.stroke();
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(x, y, 3.5, 0, Math.PI * 2);
      ctx.fill();
    } else if (lm.kind === 'peak') {
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.moveTo(x - 42, horizonOffsetY);
      ctx.lineTo(x, y);
      ctx.lineTo(x + 48, horizonOffsetY);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x - 12, y);
      ctx.lineTo(x + 12, y);
      ctx.stroke();
    }

    ctx.fillStyle = 'rgba(241, 245, 249, 0.85)';
    ctx.font = '500 11px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(lm.name, x, y - 16);
  }

  ctx.restore();
}
