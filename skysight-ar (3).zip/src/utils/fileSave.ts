export interface SaveFileResult {
  ok: boolean;
  message: string;
}

interface BidikStorageBridge {
  saveJpegToGallery?: (base64Data: string, filename: string) => string;
  saveTextFile?: (content: string, filename: string, mimeType: string) => string;
}

function getNativeStorage(): BidikStorageBridge | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as unknown as { BidikStorage?: BidikStorageBridge }).BidikStorage;
}

function dataUrlToBlob(dataUrl: string): Blob {
  const [header, base64 = ''] = dataUrl.split(',');
  const mimeMatch = /data:([^;]+)/.exec(header);
  const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Blob([bytes], { type: mime });
}

function triggerDomDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.rel = 'noopener';
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    a.remove();
    URL.revokeObjectURL(url);
  }, 1500);
}

/**
 * Saves an annotated JPEG photo reliably on both Android APK (via native MediaStore
 * Gallery bridge) and Desktop/Mobile web browsers (via Blob download + Share fallback).
 */
export async function savePhotoToDevice(
  dataUrl: string,
  filename: string
): Promise<SaveFileResult> {
  if (!dataUrl) {
    return { ok: false, message: 'Foto tidak tersedia untuk diunduh.' };
  }

  const safeName = filename.endsWith('.jpg') || filename.endsWith('.jpeg')
    ? filename
    : `${filename}.jpg`;

  // 1. Native Android APK MediaStore bridge (Pictures/Bidik)
  const nativeStorage = getNativeStorage();
  if (nativeStorage?.saveJpegToGallery) {
    try {
      const base64Payload = dataUrl.includes(',') ? dataUrl.split(',')[1] : dataUrl;
      const result = nativeStorage.saveJpegToGallery(base64Payload, safeName);
      if (result && result.startsWith('OK:')) {
        return {
          ok: true,
          message: 'Foto tersimpan ke Galeri (Pictures/Bidik).',
        };
      }
      if (result && result.startsWith('ERROR:')) {
        return {
          ok: false,
          message: `Gagal menyimpan foto: ${result.slice(6)}`,
        };
      }
    } catch (err) {
      return {
        ok: false,
        message: err instanceof Error ? err.message : 'Gagal mengakses penyimpanan Android.',
      };
    }
  }

  // 2. Web / PWA fallback using Blob + mounted anchor click (or Web Share on mobile if needed)
  try {
    const blob = dataUrlToBlob(dataUrl);
    triggerDomDownload(blob, safeName);
    return {
      ok: true,
      message: 'Foto berhasil diunduh.',
    };
  } catch {
    try {
      const blob = dataUrlToBlob(dataUrl);
      const file = new File([blob], safeName, { type: 'image/jpeg' });
      if (navigator.share && navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: safeName });
        return { ok: true, message: 'Foto dibagikan untuk disimpan.' };
      }
    } catch {
      // Ignore share cancellation
    }
    return {
      ok: false,
      message: 'Browser menolak unduhan otomatis.',
    };
  }
}

/**
 * Saves CSV text reliably on Android APK (Downloads/Bidik) and web browsers.
 */
export function saveCsvToDevice(csvText: string, filename: string): SaveFileResult {
  const safeName = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  const nativeStorage = getNativeStorage();

  if (nativeStorage?.saveTextFile) {
    try {
      const result = nativeStorage.saveTextFile(csvText, safeName, 'text/csv');
      if (result && result.startsWith('OK:')) {
        return {
          ok: true,
          message: 'File CSV tersimpan di folder Download/Bidik.',
        };
      }
      if (result && result.startsWith('ERROR:')) {
        return {
          ok: false,
          message: `Gagal mengekspor CSV: ${result.slice(6)}`,
        };
      }
    } catch (err) {
      return {
        ok: false,
        message: err instanceof Error ? err.message : 'Gagal menyimpan file CSV.',
      };
    }
  }

  try {
    const blob = new Blob([csvText], { type: 'text/csv;charset=utf-8;' });
    triggerDomDownload(blob, safeName);
    return { ok: true, message: 'File CSV berhasil diunduh.' };
  } catch {
    return { ok: false, message: 'Gagal mengunduh file CSV.' };
  }
}
