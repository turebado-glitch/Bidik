/**
 * World Magnetic Model (WMM-2025, valid 2025.0–2030.0)
 * Genuine NOAA / NCEI / BGS spherical harmonic Gauss coefficients (degree & order 12).
 * Runs 100% offline in the field; supports optional online refresh from NOAA or native Android cache.
 */

export interface WmmCoefficientRow {
  n: number;
  m: number;
  g: number;
  h: number;
  dg: number;
  dh: number;
}

export interface WmmStoredBundle {
  model: string;
  epoch: number;
  updatedAt: number;
  source: 'embedded' | 'noaa-online' | 'android-native';
  coefficients: WmmCoefficientRow[];
}

export interface WmmResult {
  declinationDeg: number;
  inclinationDeg: number;
  horizontalIntensityNt: number;
  totalIntensityNt: number;
  decimalYear: number;
  model: string;
  source: 'embedded' | 'noaa-online' | 'android-native';
}

const WMM_STORAGE_KEY = 'bidik_wmm2025_bundle_v1';
const DEG_TO_RAD = Math.PI / 180;
const RAD_TO_DEG = 180 / Math.PI;

// Genuine NOAA WMM2025.COF (Epoch 2025.0, released 11/13/2024, valid 2025.0–2030.0)
export const WMM2025_COEFFICIENTS: WmmCoefficientRow[] = [
  { n: 1, m: 0, g: -29351.8, h: 0.0, dg: 12.0, dh: 0.0 },
  { n: 1, m: 1, g: -1410.8, h: 4545.4, dg: 9.7, dh: -21.5 },
  { n: 2, m: 0, g: -2556.6, h: 0.0, dg: -11.6, dh: 0.0 },
  { n: 2, m: 1, g: 2951.1, h: -3133.6, dg: -5.2, dh: -27.7 },
  { n: 2, m: 2, g: 1649.3, h: -815.1, dg: -8.0, dh: -12.1 },
  { n: 3, m: 0, g: 1361.0, h: 0.0, dg: -1.3, dh: 0.0 },
  { n: 3, m: 1, g: -2404.1, h: -56.6, dg: -4.2, dh: 4.0 },
  { n: 3, m: 2, g: 1243.8, h: 237.5, dg: 0.4, dh: -0.3 },
  { n: 3, m: 3, g: 453.6, h: -549.5, dg: -15.6, dh: -4.1 },
  { n: 4, m: 0, g: 895.0, h: 0.0, dg: -1.6, dh: 0.0 },
  { n: 4, m: 1, g: 799.5, h: 278.6, dg: -2.4, dh: -1.1 },
  { n: 4, m: 2, g: 55.7, h: -133.9, dg: -6.0, dh: 4.1 },
  { n: 4, m: 3, g: -281.1, h: 212.0, dg: 5.6, dh: 1.6 },
  { n: 4, m: 4, g: 12.1, h: -375.6, dg: -7.0, dh: -4.4 },
  { n: 5, m: 0, g: -233.2, h: 0.0, dg: 0.6, dh: 0.0 },
  { n: 5, m: 1, g: 368.9, h: 45.4, dg: 1.4, dh: -0.5 },
  { n: 5, m: 2, g: 187.2, h: 220.2, dg: 0.0, dh: 2.2 },
  { n: 5, m: 3, g: -138.7, h: -122.9, dg: 0.6, dh: 0.4 },
  { n: 5, m: 4, g: -142.0, h: 43.0, dg: 2.2, dh: 1.7 },
  { n: 5, m: 5, g: 20.9, h: 106.1, dg: 0.9, dh: 1.9 },
  { n: 6, m: 0, g: 64.4, h: 0.0, dg: -0.2, dh: 0.0 },
  { n: 6, m: 1, g: 63.8, h: -18.4, dg: -0.4, dh: 0.3 },
  { n: 6, m: 2, g: 76.9, h: 16.8, dg: 0.9, dh: -1.6 },
  { n: 6, m: 3, g: -115.7, h: 48.8, dg: 1.2, dh: -0.4 },
  { n: 6, m: 4, g: -40.9, h: -59.8, dg: -0.9, dh: 0.9 },
  { n: 6, m: 5, g: 14.9, h: 10.9, dg: 0.3, dh: 0.7 },
  { n: 6, m: 6, g: -60.7, h: 72.7, dg: 0.9, dh: 0.9 },
  { n: 7, m: 0, g: 79.5, h: 0.0, dg: 0.0, dh: 0.0 },
  { n: 7, m: 1, g: -77.0, h: -48.9, dg: -0.1, dh: 0.6 },
  { n: 7, m: 2, g: -8.8, h: -14.4, dg: -0.1, dh: 0.5 },
  { n: 7, m: 3, g: 59.3, h: -1.0, dg: 0.5, dh: -0.8 },
  { n: 7, m: 4, g: 15.8, h: 23.4, dg: -0.1, dh: 0.0 },
  { n: 7, m: 5, g: 2.5, h: -7.4, dg: -0.8, dh: -1.0 },
  { n: 7, m: 6, g: -11.1, h: -25.1, dg: -0.8, dh: 0.6 },
  { n: 7, m: 7, g: 14.2, h: -2.3, dg: 0.8, dh: -0.2 },
  { n: 8, m: 0, g: 23.2, h: 0.0, dg: -0.1, dh: 0.0 },
  { n: 8, m: 1, g: 10.8, h: 7.1, dg: 0.2, dh: -0.2 },
  { n: 8, m: 2, g: -17.5, h: -12.6, dg: 0.0, dh: 0.5 },
  { n: 8, m: 3, g: 2.0, h: 11.4, dg: 0.5, dh: -0.4 },
  { n: 8, m: 4, g: -21.7, h: -9.7, dg: -0.1, dh: 0.4 },
  { n: 8, m: 5, g: 16.9, h: 12.7, dg: 0.3, dh: -0.5 },
  { n: 8, m: 6, g: 15.0, h: 0.7, dg: 0.2, dh: -0.6 },
  { n: 8, m: 7, g: -16.8, h: -5.2, dg: 0.0, dh: 0.3 },
  { n: 8, m: 8, g: 0.9, h: 3.9, dg: 0.2, dh: 0.2 },
  { n: 9, m: 0, g: 4.6, h: 0.0, dg: 0.0, dh: 0.0 },
  { n: 9, m: 1, g: 7.8, h: -24.8, dg: -0.1, dh: -0.3 },
  { n: 9, m: 2, g: 3.0, h: 12.2, dg: 0.1, dh: 0.3 },
  { n: 9, m: 3, g: -0.2, h: 8.3, dg: 0.3, dh: -0.3 },
  { n: 9, m: 4, g: -2.5, h: -3.3, dg: -0.3, dh: 0.3 },
  { n: 9, m: 5, g: -13.1, h: -5.2, dg: 0.0, dh: 0.2 },
  { n: 9, m: 6, g: 2.4, h: 7.2, dg: 0.3, dh: -0.1 },
  { n: 9, m: 7, g: 8.6, h: -0.6, dg: -0.1, dh: -0.2 },
  { n: 9, m: 8, g: -8.7, h: 0.8, dg: 0.1, dh: 0.4 },
  { n: 9, m: 9, g: -12.9, h: 10.0, dg: -0.1, dh: 0.1 },
  { n: 10, m: 0, g: -1.3, h: 0.0, dg: 0.1, dh: 0.0 },
  { n: 10, m: 1, g: -6.4, h: 3.3, dg: 0.0, dh: 0.0 },
  { n: 10, m: 2, g: 0.2, h: 0.0, dg: 0.1, dh: 0.0 },
  { n: 10, m: 3, g: 2.0, h: 2.4, dg: 0.1, dh: -0.2 },
  { n: 10, m: 4, g: -1.0, h: 5.3, dg: 0.0, dh: 0.1 },
  { n: 10, m: 5, g: -0.6, h: -9.1, dg: -0.3, dh: -0.1 },
  { n: 10, m: 6, g: -0.9, h: 0.4, dg: 0.0, dh: 0.1 },
  { n: 10, m: 7, g: 1.5, h: -4.2, dg: -0.1, dh: 0.0 },
  { n: 10, m: 8, g: 0.9, h: -3.8, dg: -0.1, dh: -0.1 },
  { n: 10, m: 9, g: -2.7, h: 0.9, dg: 0.0, dh: 0.2 },
  { n: 10, m: 10, g: -3.9, h: -9.1, dg: 0.0, dh: 0.0 },
  { n: 11, m: 0, g: 2.9, h: 0.0, dg: 0.0, dh: 0.0 },
  { n: 11, m: 1, g: -1.5, h: 0.0, dg: 0.0, dh: 0.0 },
  { n: 11, m: 2, g: -2.5, h: 2.9, dg: 0.0, dh: 0.1 },
  { n: 11, m: 3, g: 2.4, h: -0.6, dg: 0.0, dh: 0.0 },
  { n: 11, m: 4, g: -0.6, h: 0.2, dg: 0.0, dh: 0.1 },
  { n: 11, m: 5, g: -0.1, h: 0.5, dg: -0.1, dh: 0.0 },
  { n: 11, m: 6, g: -0.6, h: -0.3, dg: 0.0, dh: 0.0 },
  { n: 11, m: 7, g: -0.1, h: -1.2, dg: 0.0, dh: 0.1 },
  { n: 11, m: 8, g: 1.1, h: -1.7, dg: -0.1, dh: 0.0 },
  { n: 11, m: 9, g: -1.0, h: -2.9, dg: -0.1, dh: 0.0 },
  { n: 11, m: 10, g: -0.2, h: -1.8, dg: -0.1, dh: 0.0 },
  { n: 11, m: 11, g: 2.6, h: -2.3, dg: -0.1, dh: 0.0 },
  { n: 12, m: 0, g: -2.0, h: 0.0, dg: 0.0, dh: 0.0 },
  { n: 12, m: 1, g: -0.2, h: -1.3, dg: 0.0, dh: 0.0 },
  { n: 12, m: 2, g: 0.3, h: 0.7, dg: 0.0, dh: 0.0 },
  { n: 12, m: 3, g: 1.2, h: 1.0, dg: 0.0, dh: -0.1 },
  { n: 12, m: 4, g: -1.3, h: -1.4, dg: 0.0, dh: 0.1 },
  { n: 12, m: 5, g: 0.6, h: 0.0, dg: 0.0, dh: 0.0 },
  { n: 12, m: 6, g: 0.6, h: 0.6, dg: 0.1, dh: 0.0 },
  { n: 12, m: 7, g: 0.5, h: -0.1, dg: 0.0, dh: 0.0 },
  { n: 12, m: 8, g: -0.1, h: 0.8, dg: 0.0, dh: 0.0 },
  { n: 12, m: 9, g: -0.4, h: 0.1, dg: 0.0, dh: 0.0 },
  { n: 12, m: 10, g: -0.2, h: -1.0, dg: -0.1, dh: 0.0 },
  { n: 12, m: 11, g: -1.3, h: 0.1, dg: 0.0, dh: 0.0 },
  { n: 12, m: 12, g: -0.7, h: 0.2, dg: -0.1, dh: -0.1 },
];

export const DEFAULT_WMM_BUNDLE: WmmStoredBundle = {
  model: 'WMM-2025',
  epoch: 2025.0,
  updatedAt: 0,
  source: 'embedded',
  coefficients: WMM2025_COEFFICIENTS,
};

export function getDecimalYear(date = new Date()): number {
  const year = date.getUTCFullYear();
  const start = Date.UTC(year, 0, 1);
  const end = Date.UTC(year + 1, 0, 1);
  return year + (date.getTime() - start) / (end - start);
}

export function loadStoredWmmBundle(): WmmStoredBundle {
  if (typeof localStorage === 'undefined') return DEFAULT_WMM_BUNDLE;
  try {
    const raw = localStorage.getItem(WMM_STORAGE_KEY);
    if (!raw) return DEFAULT_WMM_BUNDLE;
    const parsed = JSON.parse(raw) as WmmStoredBundle;
    if (
      parsed &&
      Array.isArray(parsed.coefficients) &&
      parsed.coefficients.length >= 90 &&
      typeof parsed.epoch === 'number'
    ) {
      return parsed;
    }
    return DEFAULT_WMM_BUNDLE;
  } catch {
    return DEFAULT_WMM_BUNDLE;
  }
}

export function saveWmmBundle(bundle: WmmStoredBundle): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(WMM_STORAGE_KEY, JSON.stringify(bundle));
  } catch {
    // Ignore storage quota issues
  }
}

/**
 * Parses official NOAA WMM.COF text content into a WmmStoredBundle.
 */
export function parseWmmCofText(
  cofText: string,
  source: 'noaa-online' | 'android-native' = 'noaa-online'
): WmmStoredBundle | null {
  const lines = cofText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !l.startsWith('99999'));

  if (lines.length < 90) return null;

  const headerParts = lines[0].split(/\s+/);
  const epoch = parseFloat(headerParts[0]);
  const model = headerParts[1] || 'WMM-2025';
  if (!Number.isFinite(epoch)) return null;

  const coefficients: WmmCoefficientRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const parts = lines[i].split(/\s+/);
    if (parts.length < 6) continue;
    const n = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    const g = parseFloat(parts[2]);
    const h = parseFloat(parts[3]);
    const dg = parseFloat(parts[4]);
    const dh = parseFloat(parts[5]);
    if (
      Number.isInteger(n) &&
      Number.isInteger(m) &&
      Number.isFinite(g) &&
      Number.isFinite(h) &&
      Number.isFinite(dg) &&
      Number.isFinite(dh)
    ) {
      coefficients.push({ n, m, g, h, dg, dh });
    }
  }

  if (coefficients.length < 90) return null;
  return {
    model,
    epoch,
    updatedAt: Date.now(),
    source,
    coefficients,
  };
}

/**
 * Computes geomagnetic field declination (degrees East positive) using the WMM-2025
 * spherical harmonic expansion on the WGS-84 ellipsoid.
 */
export function computeWmmMagneticField(
  latDeg: number,
  lonDeg: number,
  altKm = 0,
  decimalYear = getDecimalYear(),
  bundle: WmmStoredBundle = loadStoredWmmBundle()
): WmmResult {
  const maxN = 12;
  const dt = Math.max(0, Math.min(10, decimalYear - bundle.epoch));

  // Build Gauss coefficient lookup arrays g[n][m], h[n][m]
  const g: number[][] = Array.from({ length: maxN + 1 }, () => new Array(maxN + 1).fill(0));
  const h: number[][] = Array.from({ length: maxN + 1 }, () => new Array(maxN + 1).fill(0));
  for (const row of bundle.coefficients) {
    if (row.n <= maxN && row.m <= row.n) {
      g[row.n][row.m] = row.g + dt * row.dg;
      h[row.n][row.m] = row.h + dt * row.dh;
    }
  }

  // WGS-84 ellipsoid constants & WMM geomagnetic reference radius
  const a = 6378.137;
  const b = 6356.7523142;
  const f = 1 / 298.257223563;
  const e2 = f * (2 - f);
  const re = 6371.2;

  const latClamped = Math.max(-89.9999, Math.min(89.9999, latDeg));
  const latRad = latClamped * DEG_TO_RAD;
  const lonRad = lonDeg * DEG_TO_RAD;

  const sinLat = Math.sin(latRad);
  const cosLat = Math.cos(latRad);

  const rc = a / Math.sqrt(1 - e2 * sinLat * sinLat);
  const xp = (rc + altKm) * cosLat;
  const zp = (rc * (b * b) / (a * a) + altKm) * sinLat;

  const r = Math.hypot(xp, zp);
  const sinPhi = zp / r; // geocentric latitude sin
  const cosPhi = xp / r; // geocentric latitude cos
  const phiGeo = Math.asin(Math.max(-1, Math.min(1, sinPhi)));

  // Difference between geodetic and geocentric latitude
  const psi = latRad - phiGeo;

  // Schmidt quasi-normalized associated Legendre functions & derivatives
  const S: number[][] = Array.from({ length: maxN + 1 }, () => new Array(maxN + 1).fill(0));
  const Psch: number[][] = Array.from({ length: maxN + 1 }, () => new Array(maxN + 1).fill(0));
  const dPsch: number[][] = Array.from({ length: maxN + 1 }, () => new Array(maxN + 1).fill(0));

  S[0][0] = 1.0;
  Psch[0][0] = 1.0;
  dPsch[0][0] = 0.0;

  for (let n = 1; n <= maxN; n++) {
    for (let m = 0; m <= n; m++) {
      if (n === m) {
        Psch[n][n] = cosPhi * Psch[n - 1][n - 1];
        dPsch[n][n] = cosPhi * dPsch[n - 1][n - 1] + sinPhi * Psch[n - 1][n - 1];
      } else if (n === 1 && m === 0) {
        Psch[1][0] = sinPhi * Psch[0][0];
        dPsch[1][0] = sinPhi * dPsch[0][0] - cosPhi * Psch[0][0];
      } else {
        const k = ((n - 1) * (n - 1) - m * m) / ((2 * n - 1) * (2 * n - 3));
        const p2 = n - 2 >= m ? Psch[n - 2][m] : 0;
        const dp2 = n - 2 >= m ? dPsch[n - 2][m] : 0;
        Psch[n][m] = sinPhi * Psch[n - 1][m] - k * p2;
        dPsch[n][m] = sinPhi * dPsch[n - 1][m] - cosPhi * Psch[n - 1][m] - k * dp2;
      }
    }
  }

  // Standard NOAA Schmidt normalization ratios S[n][m]
  for (let n = 1; n <= maxN; n++) {
    S[n][0] = S[n - 1][0] * ((2 * n - 1) / n);
    for (let m = 1; m <= n; m++) {
      const delta = m === 1 ? 1 : 0;
      S[n][m] = S[n][m - 1] * Math.sqrt(((n - m + 1) * (delta + 1)) / (n + m));
    }
  }

  let bxPrime = 0;
  let byPrime = 0;
  let bzPrime = 0;

  const cosM: number[] = new Array(maxN + 1);
  const sinM: number[] = new Array(maxN + 1);
  for (let m = 0; m <= maxN; m++) {
    cosM[m] = Math.cos(m * lonRad);
    sinM[m] = Math.sin(m * lonRad);
  }

  const ratio = re / r;
  let ratioPow = ratio * ratio; // (re/r)^2; multiplies by ratio inside n loop -> (re/r)^(n+2)

  for (let n = 1; n <= maxN; n++) {
    ratioPow *= ratio;
    let sumX = 0;
    let sumY = 0;
    let sumZ = 0;

    for (let m = 0; m <= n; m++) {
      const gSch = g[n][m] * S[n][m];
      const hSch = h[n][m] * S[n][m];
      const temp1 = gSch * cosM[m] + hSch * sinM[m];
      const temp2 = gSch * sinM[m] - hSch * cosM[m];

      sumX += temp1 * dPsch[n][m];
      sumY += m * temp2 * Psch[n][m];
      sumZ += temp1 * Psch[n][m];
    }

    bxPrime += ratioPow * sumX;
    byPrime += ratioPow * sumY;
    bzPrime -= (n + 1) * ratioPow * sumZ;
  }

  byPrime = cosPhi > 1e-8 ? byPrime / cosPhi : 0;

  // Rotate from geocentric spherical to geodetic ellipsoid frame
  const cosPsi = Math.cos(psi);
  const sinPsi = Math.sin(psi);
  const x = bxPrime * cosPsi + bzPrime * sinPsi;
  const y = byPrime;
  const z = bzPrime * cosPsi - bxPrime * sinPsi;

  const hIntensity = Math.hypot(x, y);
  const fIntensity = Math.hypot(hIntensity, z);
  const declinationDeg = Number((Math.atan2(y, x) * RAD_TO_DEG).toFixed(2));
  const inclinationDeg = Number((Math.atan2(z, hIntensity) * RAD_TO_DEG).toFixed(2));

  return {
    declinationDeg,
    inclinationDeg,
    horizontalIntensityNt: hIntensity,
    totalIntensityNt: fIntensity,
    decimalYear,
    model: bundle.model,
    source: bundle.source,
  };
}

export interface DeclinationUpdateOutcome {
  success: boolean;
  bundle: WmmStoredBundle;
  declinationDeg: number;
  message: string;
}

/**
 * Updates & persists offline geomagnetic declination data.
 * - Uses native Android HTTP fetch via BidikStorage when running as APK (no CORS limit)
 * - Falls back gracefully on web browsers and always keeps verified WMM-2025 offline data ready
 */
export async function updateOfflineDeclinationData(
  latDeg: number,
  lonDeg: number,
  altKm = 0
): Promise<DeclinationUpdateOutcome> {
  let activeBundle = loadStoredWmmBundle();
  let fetchedOnline = false;

  // 1. Try native Android bridge if running in Capacitor APK
  const win = window as unknown as {
    BidikStorage?: {
      fetchWmmCoefficients?: () => string;
      getGeomagneticDeclination?: (lat: number, lon: number, altMeters: number) => number;
    };
  };

  if (win.BidikStorage?.fetchWmmCoefficients) {
    try {
      const cofText = win.BidikStorage.fetchWmmCoefficients();
      if (cofText && !cofText.startsWith('ERROR:')) {
        const parsed = parseWmmCofText(cofText, 'noaa-online');
        if (parsed) {
          activeBundle = parsed;
          fetchedOnline = true;
        }
      }
    } catch {
      // Fall back to embedded/native calculation
    }
  }

  // 2. If native HTTP download didn't run, check Android built-in GeomagneticField or browser online state
  if (!fetchedOnline && win.BidikStorage?.getGeomagneticDeclination) {
    // Native Android GeomagneticField validates offline model availability
    try {
      const nativeDecl = win.BidikStorage.getGeomagneticDeclination(latDeg, lonDeg, altKm * 1000);
      if (Number.isFinite(nativeDecl)) {
        activeBundle = {
          ...DEFAULT_WMM_BUNDLE,
          updatedAt: Date.now(),
          source: 'android-native',
        };
      }
    } catch {
      // Ignore native bridge error
    }
  }

  if (!fetchedOnline && activeBundle.source !== 'android-native') {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      const offlineRes = computeWmmMagneticField(latDeg, lonDeg, altKm, getDecimalYear(), activeBundle);
      return {
        success: false,
        bundle: activeBundle,
        declinationDeg: offlineRes.declinationDeg,
        message: 'Tidak ada internet. Memakai data WMM-2025 offline tersimpan.',
      };
    }

    // Store refreshed local WMM-2025 snapshot timestamp for offline field use
    activeBundle = {
      ...DEFAULT_WMM_BUNDLE,
      updatedAt: Date.now(),
      source: 'embedded',
    };
  }

  saveWmmBundle(activeBundle);
  const res = computeWmmMagneticField(latDeg, lonDeg, altKm, getDecimalYear(), activeBundle);

  return {
    success: true,
    bundle: activeBundle,
    declinationDeg: res.declinationDeg,
    message: fetchedOnline
      ? `Data NOAA ${activeBundle.model} berhasil diunduh & disimpan untuk mode offline.`
      : `Data ${activeBundle.model} tersimpan di perangkat (siap pakai 100% offline di lapangan).`,
  };
}
