import React, { useState } from 'react';
import { Check, Copy, Smartphone } from 'lucide-react';

const KOTLIN_SNIPPET = `// Android Studio (Kotlin) - CameraX + SensorManager Alt/Az Reader
class AltAzSensorHelper(context: Context, private val onUpdate: (az: Float, alt: Float) -> Unit) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val rotMatrix = FloatArray(9)
    private val remapped = FloatArray(9)
    private val orientation = FloatArray(3)

    fun start() {
        rotSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    fun stop() = sensorManager.unregisterListener(this)

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rotMatrix, event.values)
        // Remap axis for upright portrait camera (screen facing user, rear camera outward)
        SensorManager.remapCoordinateSystem(rotMatrix, SensorManager.AXIS_X, SensorManager.AXIS_Z, remapped)
        SensorManager.getOrientation(remapped, orientation)

        val azimuthDeg = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
        val altitudeDeg = (-Math.toDegrees(orientation[1].toDouble())).toFloat()
        onUpdate(azimuthDeg, altitudeDeg)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}`;

export const AndroidNativeGuide: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(KOTLIN_SNIPPET);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Ignore clipboard failures
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-slate-800 bg-[#07090E] p-4 space-y-2">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <Smartphone className="w-4 h-4 text-cyan-400" aria-hidden="true" />
          <span>Cara Pakai Langsung di HP Android</span>
        </div>
        <ol className="text-xs text-slate-300 space-y-1.5 leading-relaxed">
          <li>1. Buka tautan aplikasi ini melalui <strong>Google Chrome</strong> di HP Android Anda.</li>
          <li>2. Ketuk <strong>Buka Kamera</strong> dan izinkan akses Kamera. Sensor giroskop & kompas Android akan aktif otomatis.</li>
          <li>3. Ketuk tombol <strong>Pasang Aplikasi</strong> (atau menu Chrome ⋮ → Tambahkan ke layar utama) agar menjadi aplikasi mandiri layar penuh.</li>
          <li>4. Untuk akurasi kompas terbaik, gerakkan HP membentuk angka <strong>8</strong> beberapa detik agar magnetometer terkalibrasi.</li>
        </ol>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <h4 className="text-xs font-semibold text-slate-200">
            Referensi Kode Native Android (Kotlin · SensorManager)
          </h4>
          <button
            type="button"
            onClick={() => void handleCopy()}
            className="min-h-[36px] inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs font-medium text-slate-200 hover:bg-slate-800 cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" aria-hidden="true" />
                <span>Tersalin</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
                <span>Salin Kotlin</span>
              </>
            )}
          </button>
        </div>

        <pre className="max-h-72 overflow-auto rounded-xl border border-slate-800 bg-[#05070B] p-3 font-mono text-[11px] leading-relaxed text-slate-300">
          <code>{KOTLIN_SNIPPET}</code>
        </pre>
      </div>
    </div>
  );
};
