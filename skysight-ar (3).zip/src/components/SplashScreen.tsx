import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onFinish?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [phase, setPhase] = useState<'enter' | 'exit' | 'done'>('enter');

  useEffect(() => {
    const exitTimer = window.setTimeout(() => {
      setPhase('exit');
    }, 1200);

    const doneTimer = window.setTimeout(() => {
      setPhase('done');
      onFinish?.();
    }, 1600);

    return () => {
      window.clearTimeout(exitTimer);
      window.clearTimeout(doneTimer);
    };
  }, [onFinish]);

  if (phase === 'done') return null;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-white transition-all duration-400 ease-out ${
        phase === 'exit'
          ? 'opacity-0 scale-[1.03] pointer-events-none'
          : 'opacity-100 scale-100'
      }`}
    >
      {/* Gambar animasi pembuka dengan ukuran bulat logo 100dp (100px) */}
      <div className="splash-logo-enter flex items-center justify-center">
        <img
          src="/splash-bidik-logo.png"
          alt="Logo Bidik"
          referrerPolicy="no-referrer"
          className="w-[100px] h-auto object-contain"
        />
      </div>
    </div>
  );
};
