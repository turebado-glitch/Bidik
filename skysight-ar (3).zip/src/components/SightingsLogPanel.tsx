import React, { useState } from 'react';
import { Download, FileSpreadsheet, Trash2 } from 'lucide-react';
import { CompassLanguage, SightingRecord } from '../types/instrument';
import { saveCsvToDevice, savePhotoToDevice } from '../utils/fileSave';
import { getCardinalDirection } from '../utils/orientationMath';
import { formatSnapshotDateTime } from '../utils/snapshotRenderer';

interface SightingsLogPanelProps {
  records: SightingRecord[];
  lang: CompassLanguage;
  onDelete: (id: string) => void;
  onClearAll: () => void;
  onSelectPreview?: (record: SightingRecord) => void;
}

export const SightingsLogPanel: React.FC<SightingsLogPanelProps> = ({
  records,
  lang,
  onDelete,
  onClearAll,
  onSelectPreview,
}) => {
  const [notice, setNotice] = useState<{ ok: boolean; message: string } | null>(null);

  const showNotice = (res: { ok: boolean; message: string }) => {
    setNotice(res);
    setTimeout(() => {
      setNotice((prev) => (prev === res ? null : prev));
    }, 3500);
  };

  const handleExportCsv = () => {
    if (records.length === 0) return;
    const header =
      'ID,Tanggal,Jam,Nama Benda,Altitude (deg),Azimuth (deg),Arah,Roll (deg),Latitude,Longitude,Sumber,Catatan';
    const rows = records.map((r) => {
      const cardinal = getCardinalDirection(r.azimuth, lang);
      const { dateStr, timeStr } = formatSnapshotDateTime(r.timestamp);
      const escape = (val: string) => `"${val.replace(/"/g, '""')}"`;
      return [
        r.id,
        dateStr,
        timeStr,
        escape(r.label),
        r.altitude.toFixed(2),
        r.azimuth.toFixed(2),
        cardinal.abbr,
        r.roll.toFixed(2),
        r.latitude ?? '',
        r.longitude ?? '',
        r.source,
        escape(r.note),
      ].join(',');
    });
    const csv = [header, ...rows].join('\n');
    const res = saveCsvToDevice(
      csv,
      `bidik-catatan-${new Date().toISOString().slice(0, 10)}.csv`
    );
    showNotice(res);
  };

  const handleDownloadPhoto = async (rec: SightingRecord) => {
    if (!rec.snapshotDataUrl) return;
    const { timeStr } = formatSnapshotDateTime(rec.timestamp);
    const slug = rec.label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'bidik';
    const filename = `${slug}-${rec.azimuth.toFixed(0)}deg-${timeStr.replace(/:/g, '')}.jpg`;
    const res = await savePhotoToDevice(rec.snapshotDataUrl, filename);
    showNotice(res);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-white">Riwayat Bidikan</h3>
          <p className="text-xs text-slate-400 tabular-nums">
            {records.length} objek tersimpan secara lokal
          </p>
        </div>
        {records.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportCsv}
              className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
              <span>Ekspor CSV</span>
            </button>
            <button
              type="button"
              onClick={onClearAll}
              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400 hover:text-rose-400 hover:border-rose-500/40 cursor-pointer"
              aria-label="Hapus semua riwayat"
              title="Hapus semua riwayat"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {notice && (
        <div
          className={`rounded-xl border px-3 py-2 text-xs font-medium ${
            notice.ok
              ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
              : 'border-rose-500/40 bg-rose-500/10 text-rose-300'
          }`}
        >
          {notice.message}
        </div>
      )}

      {records.length === 0 ? (
        <div className="rounded-xl border border-slate-800 bg-[#07090E] p-6 text-center">
          <p className="text-sm font-medium text-slate-300">Belum ada catatan bidikan</p>
          <p className="mt-1 text-xs text-slate-500 leading-relaxed">
            Arahkan crosshair ke suatu benda lalu tekan tombol Bidik di bagian bawah untuk menyimpan sudut altitude dan azimuth.
          </p>
        </div>
      ) : (
        <ul className="divide-y divide-slate-800/80 rounded-xl border border-slate-800 bg-[#07090E] overflow-hidden">
          {records.map((rec) => {
            const cardinal = getCardinalDirection(rec.azimuth, lang);
            const altSign = rec.altitude >= 0 ? '+' : '';
            const { timeStr } = formatSnapshotDateTime(rec.timestamp);

            return (
              <li key={rec.id} className="p-3.5 flex items-start gap-3">
                {rec.snapshotDataUrl ? (
                  <button
                    type="button"
                    onClick={() => onSelectPreview?.(rec)}
                    className="w-16 h-12 rounded-lg overflow-hidden border border-slate-700 shrink-0 bg-black cursor-pointer"
                    aria-label={`Lihat foto ${rec.label}`}
                  >
                    <img
                      src={rec.snapshotDataUrl}
                      alt={rec.label}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </button>
                ) : null}

                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-sm font-medium text-white truncate">{rec.label}</span>
                    <span className="font-mono text-[11px] text-slate-400 tabular-nums shrink-0">
                      Jam {timeStr}
                    </span>
                  </div>

                  <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 font-mono text-xs tabular-nums">
                    <span className="text-cyan-400 font-semibold">
                      Alt {altSign}
                      {rec.altitude.toFixed(1)}°
                    </span>
                    <span className="text-slate-600" aria-hidden="true">
                      ·
                    </span>
                    <span className="text-amber-400 font-semibold">
                      Az {rec.azimuth.toFixed(1)}° {cardinal.abbr}
                    </span>
                    <span className="text-slate-600" aria-hidden="true">
                      ·
                    </span>
                    <span className="text-slate-400">
                      {rec.source === 'sensor' ? 'Sensor' : 'Simulasi'}
                    </span>
                  </div>

                  {rec.note && (
                    <p className="mt-1 text-xs text-slate-400 truncate">{rec.note}</p>
                  )}

                  {rec.latitude !== null && rec.longitude !== null && (
                    <p className="mt-0.5 font-mono text-[11px] text-slate-500 tabular-nums">
                      GPS {rec.latitude.toFixed(5)}, {rec.longitude.toFixed(5)}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {rec.snapshotDataUrl && (
                    <button
                      type="button"
                      onClick={() => void handleDownloadPhoto(rec)}
                      className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-300 hover:text-cyan-400 hover:bg-slate-800/80 cursor-pointer"
                      aria-label={`Unduh foto ${rec.label}`}
                      title="Unduh Foto"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => onDelete(rec.id)}
                    className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800/80 cursor-pointer"
                    aria-label={`Hapus ${rec.label}`}
                    title="Hapus"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};
