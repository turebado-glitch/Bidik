import React, { useState } from 'react';
import { Download, Smartphone, WifiOff, X } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => void install()}
        className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg bg-cyan-500 px-2.5 sm:px-3 py-2 text-xs font-semibold text-slate-950 hover:bg-cyan-400 active:scale-[0.98] transition-all whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Download className="w-3.5 h-3.5" aria-hidden="true" />
        <span className="sm:hidden">Pasang</span>
        <span className="hidden sm:inline">Pasang Aplikasi</span>
      </button>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setShowGuide(true)}
        className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/90 px-2.5 sm:px-3 py-2 text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Smartphone className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
        <span className="sm:hidden">Pasang</span>
        <span className="hidden sm:inline">Pasang HP</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-guide-title"
        >
          <div className="w-full max-w-sm rounded-2xl border border-slate-800 bg-[#0B0E17] p-6 text-slate-100">
            <div className="flex items-start justify-between gap-4">
              <h3 id="pwa-guide-title" className="text-base font-semibold text-white">
                {isIOS ? 'Pasang di iPhone / iPad' : 'Pasang di Android'}
              </h3>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="min-h-[44px] min-w-[44px] -mt-2 -mr-2 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                aria-label="Tutup panduan instalasi"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <ol className="mt-3 space-y-2 text-sm text-slate-300 leading-relaxed">
                <li>1. Ketuk tombol <strong>Bagikan (Share)</strong> pada bilah Safari.</li>
                <li>2. Gulir ke bawah lalu pilih <strong>Tambahkan ke Layar Utama</strong>.</li>
                <li>3. Ketuk <strong>Tambah</strong> untuk menjalankan sebagai aplikasi layar penuh.</li>
              </ol>
            ) : (
              <ol className="mt-3 space-y-2 text-sm text-slate-300 leading-relaxed">
                <li>1. Buka halaman ini di <strong>Google Chrome Android</strong>.</li>
                <li>2. Ketuk ikon menu <strong>⋮</strong> di pojok kanan atas Chrome.</li>
                <li>3. Pilih <strong>Tambahkan ke layar utama</strong> atau <strong>Instal aplikasi</strong>.</li>
              </ol>
            )}

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-5 w-full min-h-[44px] rounded-xl bg-slate-800 py-2.5 text-sm font-medium text-slate-100 hover:bg-slate-700 transition-colors cursor-pointer"
            >
              Mengerti
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="fixed bottom-24 left-4 z-40 flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-950/90 px-3 py-2 text-xs font-medium text-amber-200">
      <WifiOff className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
      <span>Mode Offline · Sensor kamera & kompas tetap aktif</span>
    </div>
  );
};
