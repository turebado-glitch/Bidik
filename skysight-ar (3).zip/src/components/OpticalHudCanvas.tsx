import React, { useEffect, useRef, useState } from 'react';
import { Camera, Compass, Lock, RefreshCw } from 'lucide-react';
import { AimMode, CalibrationConfig, QiblaInfo } from '../types/instrument';
import { CameraStatus, ZoomCapabilities } from '../hooks/useCameraStream';
import { SensorPermissionState } from '../hooks/useOrientationSensor';
import {
  formatDms,
  get8PointCardinalAbbr,
  getCardinalDirection,
  normalizeDeg180,
  normalizeDeg360,
} from '../utils/orientationMath';
import { renderSimulationDome } from '../utils/simulationSky';

interface OpticalHudCanvasProps {
  aimMode: AimMode;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  simCanvasRef: React.RefObject<HTMLCanvasElement | null>;
  cameraStatus: CameraStatus;
  cameraError: string | null;
  sensorPermission: SensorPermissionState;
  hasLiveSensor: boolean;
  azimuth: number;
  altitude: number;
  roll: number;
  isFrozen: boolean;
  config: CalibrationConfig;
  zoom: ZoomCapabilities;
  customBackdrop: HTMLImageElement | null;
  qibla: QiblaInfo;
  onStartCamera: () => void;
  onRequestSensor: () => void;
  onRequestLocation: () => void;
  onSwitchToSimulation: () => void;
  onAdjustSimulation: (deltaAz: number, deltaAlt: number) => void;
  onApplyZoom: (z: number) => void;
}

export const OpticalHudCanvas: React.FC<OpticalHudCanvasProps> = ({
  aimMode,
  videoRef,
  simCanvasRef,
  cameraStatus,
  cameraError,
  sensorPermission,
  hasLiveSensor,
  azimuth,
  altitude,
  roll,
  isFrozen,
  config,
  zoom,
  customBackdrop,
  qibla,
  onStartCamera,
  onRequestSensor,
  onRequestLocation,
  onSwitchToSimulation,
  onAdjustSimulation,
  onApplyZoom,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [viewportSize, setViewportSize] = useState({ width: 800, height: 600 });
  const dragStateRef = useRef<{ active: boolean; lastX: number; lastY: number }>({
    active: false,
    lastX: 0,
    lastY: 0,
  });

  // Track viewport container dimensions for responsive pitch-ladder & simulation canvas
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const updateSize = () => {
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        setViewportSize({ width: rect.width, height: rect.height });
      }
    };

    updateSize();
    const observer = new ResizeObserver(updateSize);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Render simulation sky dome whenever in simulation mode or camera inactive
  const showSimulationDome = aimMode === 'simulation' || cameraStatus !== 'active';

  useEffect(() => {
    if (!showSimulationDome) return;
    const canvas = simCanvasRef.current;
    if (!canvas) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.floor(viewportSize.width));
    const h = Math.max(1, Math.floor(viewportSize.height));

    if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
      canvas.width = w * dpr;
      canvas.height = h * dpr;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    ctx.scale(dpr, dpr);
    renderSimulationDome(
      ctx,
      w,
      h,
      azimuth,
      altitude,
      roll,
      config.verticalFov,
      config.compassLang,
      customBackdrop
    );
    ctx.restore();
  }, [
    showSimulationDome,
    simCanvasRef,
    viewportSize.width,
    viewportSize.height,
    azimuth,
    altitude,
    roll,
    config.verticalFov,
    config.compassLang,
    customBackdrop,
  ]);

  // Pointer drag to pan sky dome in simulation mode (or when desktop has no gyro sensor)
  const canDragPan = aimMode === 'simulation' || !hasLiveSensor;

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!canDragPan) return;
    dragStateRef.current = { active: true, lastX: e.clientX, lastY: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragStateRef.current.active || !canDragPan) return;
    const dx = e.clientX - dragStateRef.current.lastX;
    const dy = e.clientY - dragStateRef.current.lastY;
    dragStateRef.current.lastX = e.clientX;
    dragStateRef.current.lastY = e.clientY;

    const degPerPx = config.verticalFov / Math.max(300, viewportSize.height);
    // Dragging left pans right (increases azimuth); dragging down tilts up (increases altitude)
    onAdjustSimulation(-dx * degPerPx * 1.15, dy * degPerPx * 1.15);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragStateRef.current.active) {
      dragStateRef.current.active = false;
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    }
  };

  const cardinal = getCardinalDirection(azimuth, config.compassLang);
  const pxPerDeg = viewportSize.height / Math.max(25, config.verticalFov);

  // Build visible pitch ladder rungs in 10-degree steps
  const pitchRungs: number[] = [];
  for (let deg = -80; deg <= 80; deg += 10) {
    if (Math.abs(deg - altitude) <= config.verticalFov * 0.72) {
      pitchRungs.push(deg);
    }
  }

  // Build compass tape ticks around current azimuth (+/- 45 deg window)
  const compassTicks: number[] = [];
  const startTick = Math.floor((azimuth - 48) / 5) * 5;
  const endTick = Math.ceil((azimuth + 48) / 5) * 5;
  for (let deg = startTick; deg <= endTick; deg += 5) {
    compassTicks.push(deg);
  }

  const altSign = altitude >= 0 ? '+' : '';
  const qiblaDeltaAz = normalizeDeg180(qibla.azimuth - azimuth);
  const qiblaAligned = qibla.enabled && Math.abs(qiblaDeltaAz) <= 2.5;
  const qiblaCardinal = getCardinalDirection(qibla.azimuth, config.compassLang);
  const qiblaTapePct = 50 + (qiblaDeltaAz / 90) * 100;
  const qiblaHorizOffsetX = qiblaDeltaAz * pxPerDeg;
  const qiblaHorizonOffsetY = altitude * pxPerDeg;

  return (
    <div
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      className={`relative w-full h-full overflow-hidden bg-[#07090E] select-none touch-none ${
        canDragPan ? 'cursor-crosshair' : 'cursor-crosshair'
      }`}
    >
      {/* Live Camera Video Stream */}
      <video
        ref={videoRef}
        playsInline
        muted
        autoPlay
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-200 ${
          aimMode === 'camera' && cameraStatus === 'active' ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      />

      {/* Interactive Sky-Horizon Simulation Canvas (when in simulation mode or camera off) */}
      {showSimulationDome && (
        <canvas
          ref={simCanvasRef}
          className="absolute inset-0 w-full h-full block"
        />
      )}

      {/* Subtle readability scrim top & bottom */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-[#07090E]/80 via-[#07090E]/35 to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[#07090E]/90 via-[#07090E]/50 to-transparent" />

      {/* Top Azimuth Compass Tape */}
      {config.showCompassTape && (
        <div
          className="pointer-events-none absolute inset-x-0 top-12 sm:top-14 flex flex-col items-center z-10"
          aria-hidden="true"
        >
          <div className="relative w-full max-w-md h-10 overflow-hidden">
            {compassTicks.map((rawDeg) => {
              const offsetDeg = rawDeg - azimuth;
              const xPct = 50 + (offsetDeg / 90) * 100;
              if (xPct < -5 || xPct > 105) return null;

              const norm = normalizeDeg360(rawDeg);
              const isMajor = norm % 15 === 0;
              const cardinalAbbr = get8PointCardinalAbbr(norm, config.compassLang);

              return (
                <div
                  key={rawDeg}
                  style={{ left: `${xPct}%` }}
                  className="absolute top-0 -translate-x-1/2 flex flex-col items-center"
                >
                  <div
                    className={`w-px ${
                      cardinalAbbr
                        ? 'h-3 bg-amber-400'
                        : isMajor
                        ? 'h-2.5 bg-slate-300/80'
                        : 'h-1.5 bg-slate-500/70'
                    }`}
                  />
                  {cardinalAbbr ? (
                    <span className="mt-0.5 font-mono text-[11px] font-bold text-amber-300 drop-shadow">
                      {cardinalAbbr}
                    </span>
                  ) : isMajor ? (
                    <span className="mt-0.5 font-mono text-[10px] text-slate-300/85 tabular-nums">
                      {norm}°
                    </span>
                  ) : null}
                </div>
              );
            })}
            {/* Qibla Marker on Compass Tape */}
            {qibla.enabled && qiblaTapePct >= -4 && qiblaTapePct <= 104 && (
              <div
                style={{ left: `${qiblaTapePct}%` }}
                className="absolute top-0 -translate-x-1/2 flex flex-col items-center z-10"
              >
                <div className="w-0.5 h-3.5 bg-emerald-400" />
                <span className="mt-0.5 font-mono text-[10px] font-bold text-emerald-300 bg-[#07090E]/80 px-1 rounded">
                  KIBLAT
                </span>
              </div>
            )}

            {/* Center index pointer */}
            <div className="absolute left-1/2 top-0 -translate-x-1/2 w-0 h-0 border-l-[5px] border-r-[5px] border-t-[6px] border-l-transparent border-r-transparent border-t-cyan-400" />
          </div>
        </div>
      )}

      {/* Dynamic Pitch Ladder & Artificial Horizon */}
      {config.showPitchLadder && (
        <div
          className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden z-10"
          aria-hidden="true"
        >
          <div
            style={{ transform: `rotate(${-roll}deg)` }}
            className="relative w-72 h-72 flex items-center justify-center will-change-transform"
          >
            {pitchRungs.map((deg) => {
              const offsetY = (altitude - deg) * pxPerDeg;
              const isHorizon = deg === 0;
              const isNegative = deg < 0;

              return (
                <div
                  key={deg}
                  style={{ transform: `translateY(${offsetY}px)` }}
                  className="absolute flex items-center justify-center will-change-transform"
                >
                  {isHorizon ? (
                    <div className="flex items-center gap-12">
                      <div className="w-24 h-[1.5px] bg-cyan-400/85 shadow-[0_0_2px_rgba(0,0,0,0.9)]" />
                      <div className="w-24 h-[1.5px] bg-cyan-400/85 shadow-[0_0_2px_rgba(0,0,0,0.9)]" />
                    </div>
                  ) : (
                    <div className="flex items-center gap-16">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[10px] font-medium text-cyan-200/85 tabular-nums drop-shadow">
                          {deg > 0 ? `+${deg}` : deg}°
                        </span>
                        <div
                          className={`w-8 h-px ${
                            isNegative
                              ? 'border-t border-dashed border-amber-300/75'
                              : 'bg-cyan-300/75'
                          }`}
                        />
                      </div>
                      <div className="flex items-center gap-1.5">
                        <div
                          className={`w-8 h-px ${
                            isNegative
                              ? 'border-t border-dashed border-amber-300/75'
                              : 'bg-cyan-300/75'
                          }`}
                        />
                        <span className="font-mono text-[10px] font-medium text-cyan-200/85 tabular-nums drop-shadow">
                          {deg > 0 ? `+${deg}` : deg}°
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* AR Qibla Horizon Beacon & Turn Guidance */}
      {qibla.enabled && (
        <>
          <div className="pointer-events-none absolute inset-x-0 top-26 sm:top-28 flex justify-center z-20">
            <div
              className={`px-3 py-1 rounded-lg border text-xs font-medium backdrop-blur-sm ${
                qiblaAligned
                  ? 'border-emerald-500/70 bg-emerald-950/85 text-emerald-200'
                  : 'border-slate-700/90 bg-[#07090E]/80 text-slate-200'
              }`}
            >
              {qiblaAligned ? (
                <span className="font-semibold">Lurus Menghadap Kiblat</span>
              ) : qiblaDeltaAz > 0 ? (
                <span className="font-mono tabular-nums">
                  Putar Kanan {Math.abs(qiblaDeltaAz).toFixed(0)}° →
                </span>
              ) : (
                <span className="font-mono tabular-nums">
                  ← Putar Kiri {Math.abs(qiblaDeltaAz).toFixed(0)}°
                </span>
              )}
            </div>
          </div>

          {Math.abs(qiblaHorizOffsetX) <= viewportSize.width * 0.6 && (
            <div
              className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden z-10"
              aria-hidden="true"
            >
              <div
                style={{
                  transform: `rotate(${-roll}deg) translate(${qiblaHorizOffsetX}px, ${qiblaHorizonOffsetY}px)`,
                }}
                className="flex flex-col items-center will-change-transform"
              >
                <div
                  className={`w-px h-24 -mt-24 border-l border-dashed ${
                    qiblaAligned ? 'border-emerald-400' : 'border-emerald-400/70'
                  }`}
                />
                <div
                  className={`w-7 h-7 rounded-md border-2 flex items-center justify-center bg-[#07090E]/90 ${
                    qiblaAligned ? 'border-emerald-400' : 'border-emerald-500/80'
                  }`}
                >
                  <div className="w-3.5 h-3.5 bg-slate-950 border border-amber-400 rounded-[2px]" />
                </div>
                <span className="mt-1 font-mono text-[10px] font-bold text-emerald-300 drop-shadow">
                  KA&apos;BAH · {qibla.azimuth.toFixed(1)}°
                </span>
              </div>
            </div>
          )}
        </>
      )}

      {/* Center Optical Crosshair Reticle */}
      <div
        className="pointer-events-none absolute inset-0 flex items-center justify-center z-10"
        aria-hidden="true"
      >
        <svg width="112" height="112" viewBox="0 0 112 112" className="drop-shadow-[0_1px_2px_rgba(0,0,0,0.85)]">
          <circle
            cx="56"
            cy="56"
            r="30"
            fill="none"
            stroke={qiblaAligned ? '#10B981' : '#06B6D4'}
            strokeWidth="1.25"
            strokeOpacity="0.88"
          />
          <line x1="8" y1="56" x2="36" y2="56" stroke={qiblaAligned ? '#10B981' : '#06B6D4'} strokeWidth="1.5" />
          <line x1="76" y1="56" x2="104" y2="56" stroke={qiblaAligned ? '#10B981' : '#06B6D4'} strokeWidth="1.5" />
          <line x1="56" y1="8" x2="56" y2="36" stroke={qiblaAligned ? '#10B981' : '#06B6D4'} strokeWidth="1.5" />
          <line x1="56" y1="76" x2="56" y2="104" stroke={qiblaAligned ? '#10B981' : '#06B6D4'} strokeWidth="1.5" />
          <circle cx="56" cy="56" r="2.75" fill={qiblaAligned ? '#10B981' : '#F59E0B'} />
        </svg>
      </div>

      {/* Camera / Sensor Permission Prompt Card (only shown when camera mode requested & not active yet) */}
      {aimMode === 'camera' && cameraStatus !== 'active' && (
        <div className="absolute inset-x-4 top-1/2 -translate-y-1/2 mx-auto max-w-sm z-20 rounded-2xl border border-slate-700/80 bg-[#0B0E17]/92 p-5 text-center backdrop-blur-md">
          <Camera className="w-7 h-7 text-cyan-400 mx-auto mb-2.5" aria-hidden="true" />
          <h2 className="text-sm font-semibold text-white">
            {cameraStatus === 'requesting'
              ? 'Mengakses Kamera...'
              : cameraStatus === 'denied' || cameraStatus === 'unavailable'
              ? 'Kamera Tidak Tersedia'
              : 'Aktifkan Kamera & Sensor'}
          </h2>
          <p className="mt-1.5 text-xs text-slate-300 leading-relaxed">
            {cameraError ||
              'Arahkan bidik tengah layar ke objek untuk membaca sudut altitude dan azimuth secara langsung.'}
          </p>
          <div className="mt-4 flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={onStartCamera}
              disabled={cameraStatus === 'requesting'}
              className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-500 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-60 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{cameraStatus === 'denied' ? 'Coba Lagi Kamera' : 'Buka Kamera'}</span>
            </button>
            <button
              type="button"
              onClick={onSwitchToSimulation}
              className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2.5 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors cursor-pointer"
            >
              <Compass className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
              <span>Mode Simulasi</span>
            </button>
          </div>
        </div>
      )}

      {/* iOS / Motion Sensor Explicit Permission Banner when camera is active */}
      {sensorPermission === 'prompt' && aimMode === 'camera' && cameraStatus === 'active' && (
        <div className="absolute top-28 inset-x-4 mx-auto max-w-xs z-20 flex items-center justify-between gap-3 rounded-xl border border-amber-500/40 bg-[#0B0E17]/90 px-3.5 py-2.5 backdrop-blur-md">
          <span className="text-xs text-amber-200">Izinkan sensor giroskop & kompas</span>
          <button
            type="button"
            onClick={onRequestSensor}
            className="min-h-[36px] rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-amber-400 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Izinkan
          </button>
        </div>
      )}

      {/* Optional Optical Zoom Slider on right edge when hardware zoom supported */}
      {aimMode === 'camera' && cameraStatus === 'active' && zoom.supported && (
        <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-2 rounded-xl border border-slate-800 bg-[#0B0E17]/80 px-2 py-3 backdrop-blur-sm">
          <span className="font-mono text-[10px] font-semibold text-cyan-300 tabular-nums">
            {zoom.current.toFixed(1)}×
          </span>
          <input
            type="range"
            min={zoom.min}
            max={zoom.max}
            step={zoom.step}
            value={zoom.current}
            onChange={(e) => onApplyZoom(parseFloat(e.target.value))}
            aria-label="Zoom kamera"
            className="h-28 w-2 accent-cyan-400 cursor-pointer [writing-mode:vertical-lr] [direction:rtl]"
          />
        </div>
      )}

      {/* Compact Live Numeric Readout Strip */}
      <div className="pointer-events-none absolute inset-x-3 bottom-[76px] sm:bottom-[86px] z-10 flex justify-center">
        <div className="w-full max-w-sm sm:max-w-md rounded-xl border border-slate-800/85 bg-[#07090E]/78 px-3 py-1.5 backdrop-blur-md">
          <div className="grid grid-cols-2 divide-x divide-slate-800/80">
            {/* Altitude Column */}
            <div className="pr-2.5 min-w-0">
              <div className="flex items-center justify-between gap-1 text-[10px] leading-tight">
                <span className="font-medium tracking-wider uppercase text-slate-400">
                  Altitude
                </span>
                {isFrozen ? (
                  <span className="inline-flex items-center gap-0.5 font-medium text-amber-400 whitespace-nowrap">
                    <Lock className="w-2.5 h-2.5" aria-hidden="true" />
                    Terkunci
                  </span>
                ) : (
                  <span className="font-mono text-cyan-400 whitespace-nowrap">
                    {altitude > 2 ? 'Atas' : altitude < -2 ? 'Bawah' : 'Horizon'}
                  </span>
                )}
              </div>
              <div className="mt-0.5 flex items-baseline justify-between gap-1.5">
                <span className="font-mono text-base sm:text-lg font-bold tracking-tight text-white tabular-nums whitespace-nowrap">
                  {altSign}
                  {altitude.toFixed(1)}°
                </span>
                {config.showDms && (
                  <span className="font-mono text-[10px] text-slate-400 tabular-nums truncate">
                    {formatDms(altitude, true)}
                  </span>
                )}
              </div>
            </div>

            {/* Azimuth Column */}
            <div className="pl-2.5 min-w-0">
              <div className="flex items-center justify-between gap-1 text-[10px] leading-tight">
                <span className="font-medium tracking-wider uppercase text-slate-400">
                  Azimuth
                </span>
                <span className="font-mono text-amber-400 truncate">
                  {cardinal.abbr} · {cardinal.name}
                </span>
              </div>
              <div className="mt-0.5 flex items-baseline justify-between gap-1.5">
                <span className="font-mono text-base sm:text-lg font-bold tracking-tight text-white tabular-nums whitespace-nowrap">
                  {azimuth.toFixed(1)}°
                </span>
                <span className="font-mono text-[10px] text-slate-400 tabular-nums whitespace-nowrap truncate">
                  {config.showDms
                    ? formatDms(azimuth, false)
                    : `Roll ${normalizeDeg180(roll).toFixed(0)}°`}
                </span>
              </div>
            </div>
          </div>

          {qibla.enabled && (
            <div className="mt-1.5 pt-1.5 border-t border-slate-800/75 flex items-center justify-between gap-2 text-[11px]">
              <div className="flex items-center gap-1.5 font-mono tabular-nums min-w-0 truncate">
                <span className="text-emerald-400 font-semibold whitespace-nowrap">
                  Kiblat {qibla.azimuth.toFixed(1)}° {qiblaCardinal.abbr}
                </span>
                <span className="text-slate-600" aria-hidden="true">
                  ·
                </span>
                <span className="text-slate-300 whitespace-nowrap">
                  {Math.round(qibla.distanceKm).toLocaleString('id-ID')} km
                </span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-[10px] text-slate-400 truncate max-w-[90px]">
                  {qibla.sourceLabel}
                </span>
                {!qibla.isGps && (
                  <button
                    type="button"
                    onClick={onRequestLocation}
                    className="pointer-events-auto text-[10px] font-medium text-cyan-400 hover:text-cyan-300 underline underline-offset-2 cursor-pointer whitespace-nowrap"
                  >
                    Pakai GPS
                  </button>
                )}
              </div>
            </div>
          )}

          {aimMode === 'simulation' && (
            <div className="mt-1 pt-1 border-t border-slate-800/75 flex items-center justify-between text-[10px] text-slate-400">
              <span>Geser layar untuk membidik pada kubah simulasi</span>
              <span className="font-mono text-cyan-400/90 whitespace-nowrap">Drag</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
