import React, { useEffect, useState } from 'react';
import { Check, Compass, LocateFixed, MapPin, RefreshCw, X } from 'lucide-react';
import { GeoLocationState, LocationPreference } from '../types/instrument';
import {
  computeQiblaBearingAndDistance,
  getCardinalDirection,
  INDONESIAN_CITY_PRESETS,
} from '../utils/orientationMath';
import { DeclinationUpdateOutcome, WmmResult, WmmStoredBundle } from '../utils/wmm2025';

interface SettingsModalProps {
  geo: GeoLocationState;
  locationPref: LocationPreference;
  trueNorthEnabled: boolean;
  wmmResult: WmmResult;
  wmmBundle: WmmStoredBundle;
  onToggleTrueNorth: (next: boolean) => void;
  onRefreshWmm: () => Promise<DeclinationUpdateOutcome>;
  onUpdateLocationPref: (next: LocationPreference) => void;
  onRequestLocation: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  geo,
  locationPref,
  trueNorthEnabled,
  wmmResult,
  wmmBundle,
  onToggleTrueNorth,
  onRefreshWmm,
  onUpdateLocationPref,
  onRequestLocation,
  onClose,
}) => {
  const [latInput, setLatInput] = useState(String(locationPref.manualLatitude));
  const [lonInput, setLonInput] = useState(String(locationPref.manualLongitude));
  const [labelInput, setLabelInput] = useState(locationPref.manualLabel);
  const [formError, setFormError] = useState<string | null>(null);
  const [savedFeedback, setSavedFeedback] = useState(false);

  const [updatingWmm, setUpdatingWmm] = useState(false);
  const [wmmOutcome, setWmmOutcome] = useState<DeclinationUpdateOutcome | null>(null);

  useEffect(() => {
    setLatInput(String(locationPref.manualLatitude));
    setLonInput(String(locationPref.manualLongitude));
    setLabelInput(locationPref.manualLabel);
  }, [locationPref.manualLatitude, locationPref.manualLongitude, locationPref.manualLabel]);

  const handleSelectMode = (mode: 'gps' | 'manual') => {
    onUpdateLocationPref({ ...locationPref, mode });
    if (mode === 'gps' && geo.status === 'idle') {
      onRequestLocation();
    }
  };

  const handlePresetPick = (cityId: string) => {
    const preset = INDONESIAN_CITY_PRESETS.find((c) => c.id === cityId);
    if (!preset) return;
    setLatInput(String(preset.latitude));
    setLonInput(String(preset.longitude));
    setLabelInput(preset.name);
    setFormError(null);
    onUpdateLocationPref({
      mode: 'manual',
      manualLatitude: preset.latitude,
      manualLongitude: preset.longitude,
      manualLabel: preset.name,
    });
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 1800);
  };

  const handleSaveManual = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedLat = parseFloat(latInput.replace(',', '.'));
    const parsedLon = parseFloat(lonInput.replace(',', '.'));

    if (!Number.isFinite(parsedLat) || parsedLat < -90 || parsedLat > 90) {
      setFormError('Lintang (Latitude) harus berupa angka antara -90 dan 90.');
      return;
    }
    if (!Number.isFinite(parsedLon) || parsedLon < -180 || parsedLon > 180) {
      setFormError('Bujur (Longitude) harus berupa angka antara -180 dan 180.');
      return;
    }

    setFormError(null);
    onUpdateLocationPref({
      mode: 'manual',
      manualLatitude: parsedLat,
      manualLongitude: parsedLon,
      manualLabel: labelInput.trim() || 'Lokasi Manual',
    });
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 1800);
  };

  const handleUpdateDeclination = async () => {
    if (updatingWmm) return;
    setUpdatingWmm(true);
    try {
      const outcome = await onRefreshWmm();
      setWmmOutcome(outcome);
    } finally {
      setUpdatingWmm(false);
    }
  };

  const activeCoords =
    locationPref.mode === 'gps' &&
    geo.status === 'active' &&
    geo.latitude !== null &&
    geo.longitude !== null
      ? { lat: geo.latitude, lon: geo.longitude, label: 'GPS Perangkat' }
      : {
          lat: locationPref.manualLatitude,
          lon: locationPref.manualLongitude,
          label: locationPref.manualLabel || 'Lokasi Manual',
        };

  const qiblaPreview = computeQiblaBearingAndDistance(activeCoords.lat, activeCoords.lon);
  const qiblaDir = getCardinalDirection(qiblaPreview.azimuth, 'id');

  const decl = wmmResult.declinationDeg;
  const declFormatted = `${decl >= 0 ? '+' : ''}${decl.toFixed(2)}° ${decl >= 0 ? 'Timur' : 'Barat'}`;
  const updatedDateStr =
    wmmBundle.updatedAt > 0
      ? new Date(wmmBundle.updatedAt).toLocaleDateString('id-ID', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
        })
      : 'Bawaan WMM-2025';

  return (
    <div
      className="absolute inset-0 z-[60] flex items-center justify-center bg-black/85 p-3 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-md max-h-[92%] flex flex-col rounded-2xl border border-slate-800 bg-[#0B0E17] text-slate-100 overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-4 shrink-0">
          <h2 id="settings-modal-title" className="text-base font-semibold text-white">
            Pengaturan
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] -mr-1.5 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            aria-label="Tutup pengaturan"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain touch-pan-y px-4 py-3.5 pb-5 space-y-4">
          {/* Pengaturan Lokasi */}
          <section className="space-y-2.5 text-left">
            <h3 className="text-sm font-semibold text-white">Pengaturan Lokasi</h3>

            <div
              className="grid grid-cols-2 gap-1 rounded-xl border border-slate-800 bg-[#07090E] p-1"
              role="group"
              aria-label="Sumber lokasi pengamat"
            >
              <button
                type="button"
                onClick={() => handleSelectMode('gps')}
                className={`min-h-[38px] inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  locationPref.mode === 'gps'
                    ? 'bg-cyan-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <LocateFixed className="w-3.5 h-3.5" aria-hidden="true" />
                <span>GPS Otomatis</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectMode('manual')}
                className={`min-h-[38px] inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  locationPref.mode === 'manual'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Input Manual</span>
              </button>
            </div>

            {locationPref.mode === 'gps' ? (
              <div className="rounded-xl border border-slate-800 bg-[#07090E] p-3 space-y-2 text-left">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs font-medium text-slate-300">GPS Perangkat</span>
                  <button
                    type="button"
                    onClick={onRequestLocation}
                    className="min-h-[34px] inline-flex items-center gap-1.5 rounded-lg bg-cyan-500 px-3 py-1 text-xs font-semibold text-slate-950 hover:bg-cyan-400 cursor-pointer"
                  >
                    <LocateFixed className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{geo.status === 'loading' ? 'Mencari...' : 'Perbarui GPS'}</span>
                  </button>
                </div>

                {geo.status === 'active' && geo.latitude !== null && geo.longitude !== null ? (
                  <div className="font-mono text-xs text-slate-200 tabular-nums space-y-0.5">
                    <div>
                      Lintang: <span className="text-cyan-400">{geo.latitude.toFixed(6)}°</span> ·
                      Bujur: <span className="text-cyan-400">{geo.longitude.toFixed(6)}°</span>
                    </div>
                    {geo.accuracyMeters !== null && (
                      <div className="text-[11px] text-slate-400">
                        Akurasi ±{Math.round(geo.accuracyMeters)} m
                        {geo.altitudeMeters !== null &&
                          ` · Elevasi ${Math.round(geo.altitudeMeters)} m dpl`}
                      </div>
                    )}
                  </div>
                ) : geo.errorMessage ? (
                  <p className="text-xs text-rose-400">{geo.errorMessage}</p>
                ) : (
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Ketuk Perbarui GPS untuk membaca lokasi saat ini (cadangan:{' '}
                    {locationPref.manualLabel}).
                  </p>
                )}
              </div>
            ) : (
              <form
                onSubmit={handleSaveManual}
                className="rounded-xl border border-slate-800 bg-[#07090E] p-3 space-y-2.5 text-left"
              >
                <div>
                  <label htmlFor="settings-city-preset" className="block text-xs text-slate-400 mb-1">
                    Pilih Kota Acuan
                  </label>
                  <select
                    id="settings-city-preset"
                    value=""
                    onChange={(e) => {
                      if (e.target.value) handlePresetPick(e.target.value);
                    }}
                    className="w-full min-h-[38px] rounded-lg border border-slate-700 bg-[#0B0E17] px-3 py-1.5 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="">Isi cepat koordinat kota...</option>
                    {INDONESIAN_CITY_PRESETS.map((city) => (
                      <option key={city.id} value={city.id}>
                        {city.name} ({city.latitude.toFixed(4)}°, {city.longitude.toFixed(4)}°)
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label htmlFor="manual-lat" className="block text-xs text-slate-300 mb-1">
                      Lintang (Latitude)
                    </label>
                    <input
                      id="manual-lat"
                      type="text"
                      inputMode="decimal"
                      value={latInput}
                      onChange={(e) => setLatInput(e.target.value)}
                      placeholder="-7.1186"
                      className="w-full min-h-[38px] rounded-lg border border-slate-700 bg-[#0B0E17] px-3 py-1.5 font-mono text-xs text-white tabular-nums focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label htmlFor="manual-lon" className="block text-xs text-slate-300 mb-1">
                      Bujur (Longitude)
                    </label>
                    <input
                      id="manual-lon"
                      type="text"
                      inputMode="decimal"
                      value={lonInput}
                      onChange={(e) => setLonInput(e.target.value)}
                      placeholder="113.6628"
                      className="w-full min-h-[38px] rounded-lg border border-slate-700 bg-[#0B0E17] px-3 py-1.5 font-mono text-xs text-white tabular-nums focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="manual-label" className="block text-xs text-slate-300 mb-1">
                    Nama Lokasi
                  </label>
                  <input
                    id="manual-label"
                    type="text"
                    value={labelInput}
                    onChange={(e) => setLabelInput(e.target.value)}
                    placeholder="Contoh: Prenduan, Sumenep"
                    className="w-full min-h-[38px] rounded-lg border border-slate-700 bg-[#0B0E17] px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                {formError && <p className="text-xs text-rose-400">{formError}</p>}

                <button
                  type="submit"
                  className="w-full min-h-[40px] inline-flex items-center justify-center gap-2 rounded-lg bg-amber-500 px-4 py-1.5 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors cursor-pointer"
                >
                  <Check className="w-4 h-4" aria-hidden="true" />
                  <span>{savedFeedback ? 'Lokasi Tersimpan' : 'Terapkan Lokasi Manual'}</span>
                </button>
              </form>
            )}

            <div className="rounded-xl border border-slate-800/90 bg-[#07090E] px-3 py-2 flex items-center justify-between gap-3 text-xs">
              <span className="text-slate-400 truncate">Aktif: {activeCoords.label}</span>
              <span className="font-mono text-emerald-400 tabular-nums shrink-0">
                Kiblat {qiblaPreview.azimuth.toFixed(1)}° {qiblaDir.abbr}
              </span>
            </div>
          </section>

          {/* Deklinasi Magnet (tepat di atas Tentang Aplikasi) */}
          <section className="space-y-2 border-t border-slate-800 pt-3.5 text-left">
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-sm font-semibold text-white">Deklinasi Magnet</h3>
              <button
                type="button"
                role="switch"
                aria-checked={trueNorthEnabled}
                onClick={() => onToggleTrueNorth(!trueNorthEnabled)}
                className={`min-h-[30px] shrink-0 rounded-lg border px-2.5 py-0.5 text-xs font-semibold transition-colors cursor-pointer ${
                  trueNorthEnabled
                    ? 'border-emerald-500/60 bg-emerald-500/15 text-emerald-300'
                    : 'border-slate-700 bg-slate-900 text-slate-400'
                }`}
              >
                {trueNorthEnabled ? 'Aktif' : 'Nonaktif'}
              </button>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#07090E] p-3 space-y-2">
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="inline-flex items-center gap-1.5 text-slate-400">
                  <Compass className="w-3.5 h-3.5 text-emerald-400" aria-hidden="true" />
                  <span>{activeCoords.label}</span>
                </span>
                <span className="font-mono font-semibold text-emerald-400 tabular-nums">
                  {declFormatted}
                </span>
              </div>

              <div className="flex items-center justify-between gap-2 text-[11px] text-slate-400">
                <span>Data Offline ({updatedDateStr})</span>
                <button
                  type="button"
                  onClick={() => void handleUpdateDeclination()}
                  disabled={updatingWmm}
                  className="min-h-[34px] inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1 text-xs font-semibold text-cyan-300 hover:bg-slate-800 disabled:opacity-60 cursor-pointer"
                >
                  <RefreshCw
                    className={`w-3.5 h-3.5 ${updatingWmm ? 'animate-spin' : ''}`}
                    aria-hidden="true"
                  />
                  <span>{updatingWmm ? 'Memperbarui...' : 'Perbarui Data'}</span>
                </button>
              </div>

              {wmmOutcome && (
                <p
                  className={`text-[11px] leading-relaxed ${
                    wmmOutcome.success ? 'text-emerald-300' : 'text-amber-300'
                  }`}
                >
                  {wmmOutcome.message}
                </p>
              )}
            </div>
          </section>

          {/* Tentang Aplikasi */}
          <section className="space-y-2 border-t border-slate-800 pt-3.5 text-left">
            <h3 className="text-sm font-semibold text-white">Tentang Aplikasi</h3>

            <div className="rounded-xl border border-slate-800 bg-[#07090E] p-3.5 space-y-2.5 text-left">
              <div className="flex items-center gap-3 pb-2.5 border-b border-slate-800/80">
                <img
                  src="/assets/aistudio/AddText_11-16-08.30.35_6d5add7e.png"
                  alt="Logo Bidik"
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 object-contain shrink-0"
                />
                <div className="text-left">
                  <div className="text-sm font-bold text-white">Bidik</div>
                  <div className="text-xs text-slate-400">
                    Kamera Pengukur Altitude, Azimuth &amp; Arah Kiblat
                  </div>
                </div>
              </div>

              <div className="space-y-1 text-xs text-slate-200 text-left">
                <div>Nama: Ahmad Azizi</div>
                <div>Alamat: Al-Muqri Prenduan</div>
                <div>Versi: 1.0</div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
