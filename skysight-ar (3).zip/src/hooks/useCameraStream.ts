import { useCallback, useEffect, useRef, useState } from 'react';

export type CameraStatus = 'idle' | 'requesting' | 'active' | 'denied' | 'unavailable';

export interface CameraDeviceOption {
  deviceId: string;
  label: string;
}

export interface ZoomCapabilities {
  supported: boolean;
  min: number;
  max: number;
  step: number;
  current: number;
}

export function useCameraStream() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [status, setStatus] = useState<CameraStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [devices, setDevices] = useState<CameraDeviceOption[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [zoom, setZoom] = useState<ZoomCapabilities>({
    supported: false,
    min: 1,
    max: 1,
    step: 0.1,
    current: 1,
  });

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setStatus('idle');
  }, []);

  const refreshDevices = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    try {
      const list = await navigator.mediaDevices.enumerateDevices();
      const videoInputs = list
        .filter((d) => d.kind === 'videoinput')
        .map((d, idx) => ({
          deviceId: d.deviceId,
          label: d.label || `Kamera ${idx + 1}`,
        }));
      setDevices(videoInputs);
    } catch {
      // Ignore device enumeration errors
    }
  }, []);

  const startCamera = useCallback(
    async (overrideDeviceId?: string | null, overrideFacing?: 'environment' | 'user') => {
      if (!navigator.mediaDevices?.getUserMedia) {
        setStatus('unavailable');
        setErrorMessage('Peramban tidak mendukung akses kamera MediaDevices.');
        return false;
      }

      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }

      setStatus('requesting');
      setErrorMessage(null);

      const targetDeviceId = overrideDeviceId !== undefined ? overrideDeviceId : selectedDeviceId;
      const targetFacing = overrideFacing ?? facingMode;

      const videoConstraints: MediaTrackConstraints = targetDeviceId
        ? {
            deviceId: { exact: targetDeviceId },
            width: { ideal: 1920 },
            height: { ideal: 1080 },
          }
        : {
            facingMode: { ideal: targetFacing },
            width: { ideal: 1920 },
            height: { ideal: 1080 },
          };

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: videoConstraints,
          audio: false,
        });

        streamRef.current = stream;

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }

        const track = stream.getVideoTracks()[0];
        if (track && typeof track.getCapabilities === 'function') {
          const caps = track.getCapabilities() as MediaTrackCapabilities & {
            zoom?: { min: number; max: number; step?: number };
          };
          const settings = track.getSettings() as MediaTrackSettings & { zoom?: number };
          if (caps.zoom) {
            setZoom({
              supported: true,
              min: caps.zoom.min ?? 1,
              max: Math.min(caps.zoom.max ?? 4, 8),
              step: caps.zoom.step ?? 0.1,
              current: settings.zoom ?? caps.zoom.min ?? 1,
            });
          } else {
            setZoom({ supported: false, min: 1, max: 1, step: 0.1, current: 1 });
          }
        }

        setStatus('active');
        await refreshDevices();
        return true;
      } catch (err) {
        const error = err as DOMException;
        if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
          setStatus('denied');
          setErrorMessage('Izin kamera ditolak. Aktifkan izin kamera pada pengaturan browser Android Anda.');
        } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
          setStatus('unavailable');
          setErrorMessage('Kamera tidak ditemukan pada perangkat ini. Gunakan Mode Simulasi.');
        } else {
          setStatus('unavailable');
          setErrorMessage(`Gagal membuka kamera: ${error.message || 'Perangkat tidak tersedia'}`);
        }
        return false;
      }
    },
    [facingMode, refreshDevices, selectedDeviceId]
  );

  const applyZoom = useCallback(async (newZoom: number) => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try {
      await track.applyConstraints({
        advanced: [{ zoom: newZoom } as MediaTrackConstraintSet],
      });
      setZoom((prev) => ({ ...prev, current: newZoom }));
    } catch {
      // Ignore unsupported zoom constraint errors
    }
  }, []);

  const toggleFacingMode = useCallback(() => {
    const next = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(next);
    setSelectedDeviceId(null);
    if (status === 'active') {
      void startCamera(null, next);
    }
  }, [facingMode, startCamera, status]);

  const selectDevice = useCallback(
    (deviceId: string) => {
      setSelectedDeviceId(deviceId);
      if (status === 'active') {
        void startCamera(deviceId);
      }
    },
    [startCamera, status]
  );

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  return {
    videoRef,
    status,
    errorMessage,
    devices,
    selectedDeviceId,
    facingMode,
    zoom,
    startCamera,
    stopCamera,
    applyZoom,
    toggleFacingMode,
    selectDevice,
  };
}
