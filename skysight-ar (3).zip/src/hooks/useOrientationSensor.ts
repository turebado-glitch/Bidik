import { useCallback, useEffect, useRef, useState } from 'react';
import { OrientationReading } from '../types/instrument';
import {
  computeCameraAltAz,
  normalizeDeg360,
  smoothAngleDeg,
  smoothLinear,
} from '../utils/orientationMath';

export type SensorPermissionState = 'prompt' | 'granted' | 'denied' | 'unsupported';

interface IOSDeviceOrientationEvent extends DeviceOrientationEvent {
  webkitCompassHeading?: number;
}

interface DeviceOrientationEventConstructorWithPermission {
  requestPermission?: () => Promise<'granted' | 'denied'>;
}

export function useOrientationSensor(smoothing: number, enabled: boolean) {
  const [permissionState, setPermissionState] = useState<SensorPermissionState>(() => {
    if (typeof window === 'undefined' || !('DeviceOrientationEvent' in window)) {
      return 'unsupported';
    }
    const ctor = window.DeviceOrientationEvent as unknown as DeviceOrientationEventConstructorWithPermission;
    return typeof ctor.requestPermission === 'function' ? 'prompt' : 'granted';
  });

  const [hasLiveSensor, setHasLiveSensor] = useState(false);
  const [reading, setReading] = useState<OrientationReading>({
    azimuth: 0,
    altitude: 0,
    roll: 0,
    rawAlpha: null,
    rawBeta: null,
    rawGamma: null,
    isAbsolute: false,
    timestamp: Date.now(),
  });

  const smoothedRef = useRef<{ azimuth: number; altitude: number; roll: number } | null>(null);
  const smoothingRef = useRef(smoothing);
  smoothingRef.current = smoothing;

  const hasAbsoluteListenerRef = useRef(false);

  const requestSensorPermission = useCallback(async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('DeviceOrientationEvent' in window)) {
      setPermissionState('unsupported');
      return false;
    }
    const ctor = window.DeviceOrientationEvent as unknown as DeviceOrientationEventConstructorWithPermission;
    if (typeof ctor.requestPermission === 'function') {
      try {
        const result = await ctor.requestPermission();
        setPermissionState(result);
        return result === 'granted';
      } catch {
        setPermissionState('denied');
        return false;
      }
    }
    setPermissionState('granted');
    return true;
  }, []);

  useEffect(() => {
    if (!enabled || permissionState !== 'granted') return;

    const getScreenAngle = (): number => {
      if (window.screen?.orientation?.angle !== undefined) {
        return window.screen.orientation.angle;
      }
      const winOrientation = (window as unknown as { orientation?: number }).orientation;
      return typeof winOrientation === 'number' ? winOrientation : 0;
    };

    const handleOrientation = (event: DeviceOrientationEvent, fromAbsoluteEvent: boolean) => {
      if (event.alpha === null || event.beta === null || event.gamma === null) {
        return;
      }

      // If we already receive deviceorientationabsolute events, ignore non-absolute fallback events
      if (fromAbsoluteEvent) {
        hasAbsoluteListenerRef.current = true;
      } else if (hasAbsoluteListenerRef.current && !event.absolute) {
        return;
      }

      const iosEvent = event as IOSDeviceOrientationEvent;
      let effectiveAlpha = event.alpha;
      const isAbsolute = fromAbsoluteEvent || event.absolute === true || typeof iosEvent.webkitCompassHeading === 'number';

      if (!event.absolute && typeof iosEvent.webkitCompassHeading === 'number') {
        effectiveAlpha = normalizeDeg360(360 - iosEvent.webkitCompassHeading);
      }

      const screenAngle = getScreenAngle();
      const computed = computeCameraAltAz(effectiveAlpha, event.beta, event.gamma, screenAngle);

      const factor = smoothingRef.current;
      if (!smoothedRef.current) {
        smoothedRef.current = {
          azimuth: computed.azimuth,
          altitude: computed.altitude,
          roll: computed.roll,
        };
      } else {
        smoothedRef.current = {
          azimuth: smoothAngleDeg(smoothedRef.current.azimuth, computed.azimuth, factor),
          altitude: smoothLinear(smoothedRef.current.altitude, computed.altitude, factor),
          roll: smoothLinear(smoothedRef.current.roll, computed.roll, factor),
        };
      }

      setHasLiveSensor(true);
      setReading({
        azimuth: smoothedRef.current.azimuth,
        altitude: smoothedRef.current.altitude,
        roll: smoothedRef.current.roll,
        rawAlpha: event.alpha,
        rawBeta: event.beta,
        rawGamma: event.gamma,
        isAbsolute,
        timestamp: Date.now(),
      });
    };

    const onAbsolute = (e: Event) => handleOrientation(e as DeviceOrientationEvent, true);
    const onRelative = (e: Event) => handleOrientation(e as DeviceOrientationEvent, false);

    window.addEventListener('deviceorientationabsolute', onAbsolute, true);
    window.addEventListener('deviceorientation', onRelative, true);

    return () => {
      window.removeEventListener('deviceorientationabsolute', onAbsolute, true);
      window.removeEventListener('deviceorientation', onRelative, true);
      hasAbsoluteListenerRef.current = false;
    };
  }, [enabled, permissionState]);

  return {
    permissionState,
    hasLiveSensor,
    reading,
    requestSensorPermission,
  };
}
