import { useCallback, useState } from 'react';
import { GeoLocationState } from '../types/instrument';

export function useGeoLocation() {
  const [geo, setGeo] = useState<GeoLocationState>({
    status: 'idle',
    latitude: null,
    longitude: null,
    altitudeMeters: null,
    accuracyMeters: null,
    errorMessage: null,
  });

  const requestLocation = useCallback(() => {
    if (!('geolocation' in navigator)) {
      setGeo((prev) => ({
        ...prev,
        status: 'error',
        errorMessage: 'Geolokasi tidak didukung peramban ini.',
      }));
      return;
    }

    setGeo((prev) => ({ ...prev, status: 'loading', errorMessage: null }));

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeo({
          status: 'active',
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          altitudeMeters: pos.coords.altitude,
          accuracyMeters: pos.coords.accuracy,
          errorMessage: null,
        });
      },
      (err) => {
        setGeo((prev) => ({
          ...prev,
          status: 'error',
          errorMessage:
            err.code === 1
              ? 'Izin lokasi GPS ditolak.'
              : 'Sinyal GPS tidak tersedia saat ini.',
        }));
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 30000,
      }
    );
  }, []);

  return {
    geo,
    requestLocation,
  };
}
