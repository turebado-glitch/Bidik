import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ahmadazizi.bidik',
  appName: 'Bidik',
  webDir: 'dist',
  backgroundColor: '#07090E',
  android: {
    allowMixedContent: false,
    backgroundColor: '#07090E',
  },
};

export default config;
