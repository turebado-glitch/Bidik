import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const androidDir = path.join(root, 'android');
const appDir = path.join(androidDir, 'app');
const mainDir = path.join(appDir, 'src', 'main');
const manifestPath = path.join(mainDir, 'AndroidManifest.xml');
const buildGradlePath = path.join(appDir, 'build.gradle');
const resDir = path.join(mainDir, 'res');
const logoSource = path.join(root, 'public', 'assets', 'aistudio', 'AddText_11-15-07.49.25_55867733.png');

if (!fs.existsSync(manifestPath) || !fs.existsSync(buildGradlePath)) {
  console.error('Android project not found. Run "npx cap add android" first.');
  process.exit(1);
}

// 1. Inject required hardware & runtime permissions into AndroidManifest.xml
let manifest = fs.readFileSync(manifestPath, 'utf8');
const requiredEntries = [
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
  '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.compass" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.accelerometer" android:required="false" />',
  '<uses-feature android:name="android.hardware.sensor.gyroscope" android:required="false" />',
];

const missingEntries = requiredEntries.filter((entry) => !manifest.includes(entry));
if (missingEntries.length > 0) {
  manifest = manifest.replace(
    '</manifest>',
    `    ${missingEntries.join('\n    ')}\n</manifest>`
  );
  fs.writeFileSync(manifestPath, manifest, 'utf8');
  console.log(`Added ${missingEntries.length} permission/feature entries to AndroidManifest.xml`);
}

// 2. Configure release signingConfigs & dynamic versionCode in app/build.gradle
let gradle = fs.readFileSync(buildGradlePath, 'utf8');
const versionCode = Number(process.env.ANDROID_VERSION_CODE || '1') || 1;
gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
gradle = gradle.replace(/versionName\s+"[^"]*"/, 'versionName "1.0"');

if (!gradle.includes('signingConfigs')) {
  const signingBlock = `    signingConfigs {
        release {
            def ksPath = System.getenv("ANDROID_KEYSTORE_PATH")
            if (ksPath != null && file(ksPath).exists()) {
                storeFile file(ksPath)
                storePassword System.getenv("ANDROID_KEYSTORE_PASSWORD")
                keyAlias System.getenv("ANDROID_KEY_ALIAS")
                keyPassword System.getenv("ANDROID_KEY_PASSWORD")
            }
        }
    }
    buildTypes {`;

  gradle = gradle.replace(/buildTypes\s*\{/, signingBlock);
  gradle = gradle.replace(
    /release\s*\{([\s\S]*?)minifyEnabled\s+(true|false)/,
    `release {$1minifyEnabled $2\n            signingConfig signingConfigs.release`
  );
  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
  console.log(`Configured release signingConfig and versionCode=${versionCode} in app/build.gradle`);
}

// 3. Replace default Capacitor launcher icons & 120dp native splash logo with Bidik's attached logo
let hasConvert = false;
try {
  execFileSync('convert', ['-version'], { stdio: 'ignore' });
  hasConvert = true;
} catch {
  hasConvert = false;
}

if (fs.existsSync(logoSource)) {
  const mipmapSizes = [
    { folder: 'mipmap-mdpi', launcher: 48, foreground: 108 },
    { folder: 'mipmap-hdpi', launcher: 72, foreground: 162 },
    { folder: 'mipmap-xhdpi', launcher: 96, foreground: 216 },
    { folder: 'mipmap-xxhdpi', launcher: 144, foreground: 324 },
    { folder: 'mipmap-xxxhdpi', launcher: 192, foreground: 432 },
  ];

  for (const spec of mipmapSizes) {
    const dir = path.join(resDir, spec.folder);
    fs.mkdirSync(dir, { recursive: true });
    const launcherPath = path.join(dir, 'ic_launcher.png');
    const roundPath = path.join(dir, 'ic_launcher_round.png');
    const fgPath = path.join(dir, 'ic_launcher_foreground.png');

    if (hasConvert) {
      execFileSync('convert', [
        logoSource,
        '-resize',
        `${spec.launcher}x${spec.launcher}`,
        launcherPath,
      ]);
      fs.copyFileSync(launcherPath, roundPath);

      const innerFg = Math.round(spec.foreground * 0.68);
      execFileSync('convert', [
        logoSource,
        '-resize',
        `${innerFg}x${innerFg}`,
        '-background',
        'none',
        '-gravity',
        'center',
        '-extent',
        `${spec.foreground}x${spec.foreground}`,
        fgPath,
      ]);
    } else {
      const fallback192 = path.join(root, 'public', 'pwa-192x192.png');
      const src = fs.existsSync(fallback192) ? fallback192 : logoSource;
      fs.copyFileSync(src, launcherPath);
      fs.copyFileSync(src, roundPath);
      fs.copyFileSync(src, fgPath);
    }
  }

  // Generate 120dp native Bidik launch splash drawable per DPI bucket
  const splashDensities = [
    { folder: 'drawable-mdpi', px: 120 },
    { folder: 'drawable-hdpi', px: 180 },
    { folder: 'drawable-xhdpi', px: 240 },
    { folder: 'drawable-xxhdpi', px: 360 },
    { folder: 'drawable-xxxhdpi', px: 480 },
  ];

  for (const spec of splashDensities) {
    const dDir = path.join(resDir, spec.folder);
    fs.mkdirSync(dDir, { recursive: true });
    const dest = path.join(dDir, 'bidik_splash_logo.png');
    if (hasConvert) {
      execFileSync('convert', [logoSource, '-resize', `${spec.px}x${spec.px}`, dest]);
    } else {
      const fallback192 = path.join(root, 'public', 'pwa-192x192.png');
      fs.copyFileSync(fs.existsSync(fallback192) ? fallback192 : logoSource, dest);
    }
  }

  const drawableDir = path.join(resDir, 'drawable');
  fs.mkdirSync(drawableDir, { recursive: true });

  fs.writeFileSync(
    path.join(drawableDir, 'splash_bidik.xml'),
    `<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@color/bidik_splash_bg" />
    <item>
        <bitmap
            android:gravity="center"
            android:src="@drawable/bidik_splash_logo" />
    </item>
</layer-list>
`,
    'utf8'
  );
  console.log('Updated Android mipmap icons and 120dp Bidik launch splash drawables');
}

// 4. Enforce dark fullscreen theme & transparent/dark system bars in styles.xml & colors
const valuesDir = path.join(resDir, 'values');
fs.mkdirSync(valuesDir, { recursive: true });

fs.writeFileSync(
  path.join(valuesDir, 'ic_launcher_background.xml'),
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#07090E</color>
    <color name="bidik_splash_bg">#07090E</color>
</resources>
`,
  'utf8'
);

const stylesPath = path.join(valuesDir, 'styles.xml');
fs.writeFileSync(
  stylesPath,
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.NoActionBar">
        <item name="colorPrimary">#07090E</item>
        <item name="colorPrimaryDark">#07090E</item>
        <item name="colorAccent">#06B6D4</item>
        <item name="android:windowBackground">#07090E</item>
    </style>

    <style name="AppTheme.NoActionBar" parent="Theme.AppCompat.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
        <item name="android:windowBackground">#07090E</item>
        <item name="android:windowFullscreen">true</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:windowLightNavigationBar">false</item>
        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>
    </style>

    <style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">
        <item name="android:background">@drawable/splash_bidik</item>
        <item name="windowSplashScreenBackground">#07090E</item>
        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher_foreground</item>
        <item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>
    </style>
</resources>
`,
  'utf8'
);
console.log('Configured dark fullscreen styles.xml with Bidik launch splash');

// 5. Patch MainActivity.java to enable immersive edge-to-edge fullscreen
const mainActivityPath = path.join(mainDir, 'java', 'com', 'ahmadazizi', 'bidik', 'MainActivity.java');
if (fs.existsSync(mainActivityPath)) {
  fs.writeFileSync(
    mainActivityPath,
    `package com.ahmadazizi.bidik;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyFullscreenMode();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyFullscreenMode();
        }
    }

    private void applyFullscreenMode() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (controller != null) {
            controller.setAppearanceLightStatusBars(false);
            controller.setAppearanceLightNavigationBars(false);
            controller.hide(WindowInsetsCompat.Type.systemBars());
            controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            );
        }
    }
}
`,
    'utf8'
  );
  console.log('Updated MainActivity.java for immersive edge-to-edge fullscreen');
}
