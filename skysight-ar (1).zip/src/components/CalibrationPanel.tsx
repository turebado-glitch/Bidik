import React from 'react';
import { Crosshair, Image as ImageIcon, MapPin, RotateCcw, SwitchCamera } from 'lucide-react';
import { AimMode, CalibrationConfig, GeoLocationState, OrientationReading } from '../types/instrument';
import { CameraDeviceOption } from '../hooks/useCameraStream';
import { estimateMagneticDeclinationDeg, INDONESIAN_CITY_PRESETS } from '../utils/orientationMath';

interface CalibrationPanelProps {
  aimMode: AimMode;
  config: CalibrationConfig;
  reading: OrientationReading;
  geo: GeoLocationState;
  devices: CameraDeviceOption[];
  selectedDeviceId: string | null;
  hasLiveSensor: boolean;
  selectedCityId: string;
  onSelectCity: (cityId: string) => void;
  onUpdateConfig: (patch: Partial<CalibrationConfig>) => void;
  onZeroAltitude: () => void;
  onResetOffsets: () => void;
  onRequestLocation: () => void;
  onToggleFacing: () => void;
  onSelectDevice: (id: string) => void;
  onUploadBackdrop: (file: File) => void;
  onClearBackdrop: () => void;
  hasCustomBackdrop: boolean;
}

export const CalibrationPanel: React.FC<CalibrationPanelProps> = ({
  aimMode,
  config,
  reading,
  geo,
  devices,
  selectedDeviceId,
  hasLiveSensor,
  selectedCityId,
  onSelectCity,
  onUpdateConfig,
  onZeroAltitude,
  onResetOffsets,
  onRequestLocation,
  onToggleFacing,
  onSelectDevice,
  onUploadBackdrop,
  onClearBackdrop,
  hasCustomBackdrop,
}) => {
  const handleAutoDeclination = () => {
    if (geo.latitude === null || geo.longitude === null) return;
    const dec = estimateMagneticDeclinationDeg(geo.latitude, geo.longitude);
    onUpdateConfig({ azimuthOffset: dec });
  };

  return (
    <div className="space-y-5">
      {/* Quick Zero & Reset */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">Kalibrasi Sudut</h3>
          <button
            type="button"
            onClick={onResetOffsets}
            className="min-h-[36px] inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Reset</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={onZeroAltitude}
            className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-slate-800 cursor-pointer"
          >
            <Crosshair className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
            <span>Nol-kan Horizon</span>
          </button>

          <button
            type="button"
            onClick={onToggleFacing}
            disabled={aimMode !== 'camera'}
            className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-slate-800 disabled:opacity-40 cursor-pointer"
          >
            <SwitchCamera className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
            <span>Ganti Lensa</span>
          </button>
        </div>

        {aimMode === 'camera' && devices.length > 1 && (
          <div>
            <label htmlFor="camera-select" className="block text-xs text-slate-400 mb-1">
              Pilih Modul Kamera
            </label>
            <select
              id="camera-select"
              value={selectedDeviceId || ''}
              onChange={(e) => onSelectDevice(e.target.value)}
              className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#07090E] px-3 py-2 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
            >
              <option value="">Otomatis (Kamera Belakang)</option>
              {devices.map((d) => (
                <option key={d.deviceId} value={d.deviceId}>
                  {d.label}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Numeric Calibration Sliders */}
      <div className="space-y-4 border-t border-slate-800 pt-4">
        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-300 font-medium">Offset Azimuth / Deklinasi</span>
            <span className="font-mono text-amber-400 tabular-nums">
              {config.azimuthOffset >= 0 ? '+' : ''}
              {config.azimuthOffset.toFixed(1)}°
            </span>
          </div>
          <input
            type="range"
            min={-30}
            max={30}
            step={0.5}
            value={config.azimuthOffset}
            onChange={(e) => onUpdateConfig({ azimuthOffset: parseFloat(e.target.value) })}
            className="w-full accent-amber-400 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-300 font-medium">Offset Altitude (Kemiringan)</span>
            <span className="font-mono text-cyan-400 tabular-nums">
              {config.altitudeOffset >= 0 ? '+' : ''}
              {config.altitudeOffset.toFixed(1)}°
            </span>
          </div>
          <input
            type="range"
            min={-15}
            max={15}
            step={0.2}
            value={config.altitudeOffset}
            onChange={(e) => onUpdateConfig({ altitudeOffset: parseFloat(e.target.value) })}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-300 font-medium">Peredam Getaran (Smoothing)</span>
            <span className="font-mono text-slate-300 tabular-nums">
              {Math.round(config.smoothing * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={0.9}
            step={0.05}
            value={config.smoothing}
            onChange={(e) => onUpdateConfig({ smoothing: parseFloat(e.target.value) })}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-300 font-medium">Sudut Pandang Vertikal (FOV)</span>
            <span className="font-mono text-slate-300 tabular-nums">
              {config.verticalFov.toFixed(0)}°
            </span>
          </div>
          <input
            type="range"
            min={35}
            max={85}
            step={1}
            value={config.verticalFov}
            onChange={(e) => onUpdateConfig({ verticalFov: parseFloat(e.target.value) })}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>
      </div>

      {/* HUD Display Toggles */}
      <div className="space-y-2 border-t border-slate-800 pt-4">
        <div className="text-xs font-medium text-slate-400 mb-2">Tampilan HUD</div>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => onUpdateConfig({ showPitchLadder: !config.showPitchLadder })}
            className={`min-h-[40px] rounded-xl border px-3 py-2 text-xs font-medium transition-colors cursor-pointer ${
              config.showPitchLadder
                ? 'border-cyan-500/60 bg-cyan-500/10 text-cyan-300'
                : 'border-slate-800 bg-[#07090E] text-slate-400'
            }`}
          >
            Garis Horizon
          </button>
          <button
            type="button"
            onClick={() => onUpdateConfig({ showCompassTape: !config.showCompassTape })}
            className={`min-h-[40px] rounded-xl border px-3 py-2 text-xs font-medium transition-colors cursor-pointer ${
              config.showCompassTape
                ? 'border-cyan-500/60 bg-cyan-500/10 text-cyan-300'
                : 'border-slate-800 bg-[#07090E] text-slate-400'
            }`}
          >
            Pita Kompas
          </button>
          <button
            type="button"
            onClick={() => onUpdateConfig({ showDms: !config.showDms })}
            className={`min-h-[40px] rounded-xl border px-3 py-2 text-xs font-medium transition-colors cursor-pointer ${
              config.showDms
                ? 'border-cyan-500/60 bg-cyan-500/10 text-cyan-300'
                : 'border-slate-800 bg-[#07090E] text-slate-400'
            }`}
          >
            Format DMS (° ′ ″)
          </button>
          <button
            type="button"
            onClick={() =>
              onUpdateConfig({ compassLang: config.compassLang === 'id' ? 'en' : 'id' })
            }
            className="min-h-[40px] rounded-xl border border-slate-800 bg-[#07090E] px-3 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 cursor-pointer"
          >
            Arah: {config.compassLang === 'id' ? 'U / T / S / B' : 'N / E / S / W'}
          </button>
        </div>
      </div>

      {/* GPS Coordinates & Declination */}
      <div className="space-y-2.5 border-t border-slate-800 pt-4">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-medium text-slate-300">Lokasi GPS & Deklinasi</span>
          <button
            type="button"
            onClick={onRequestLocation}
            className="min-h-[36px] inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs font-medium text-cyan-300 hover:bg-slate-800 cursor-pointer"
          >
            <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{geo.status === 'loading' ? 'Mencari...' : 'Ambil GPS'}</span>
          </button>
        </div>

        {geo.status === 'active' && geo.latitude !== null && geo.longitude !== null ? (
          <div className="rounded-xl border border-slate-800 bg-[#07090E] p-3 space-y-2">
            <div className="font-mono text-xs text-slate-200 tabular-nums">
              {geo.latitude.toFixed(5)}, {geo.longitude.toFixed(5)}
              {geo.altitudeMeters !== null && ` · ${Math.round(geo.altitudeMeters)} m dpl`}
            </div>
            <button
              type="button"
              onClick={handleAutoDeclination}
              className="text-xs font-medium text-amber-400 hover:text-amber-300 underline underline-offset-4 cursor-pointer"
            >
              Terapkan estimasi deklinasi Utara Sejati
            </button>
          </div>
        ) : geo.errorMessage ? (
          <p className="text-xs text-rose-400">{geo.errorMessage}</p>
        ) : (
          <p className="text-xs text-slate-500">
            Aktifkan GPS untuk menghitung arah Kiblat tepat dari posisi Anda, atau pilih kota acuan di bawah.
          </p>
        )}

        <div>
          <label htmlFor="qibla-city-select" className="block text-xs text-slate-400 mb-1">
            Kota Acuan Kiblat (Cadangan tanpa GPS)
          </label>
          <select
            id="qibla-city-select"
            value={selectedCityId}
            onChange={(e) => onSelectCity(e.target.value)}
            className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#07090E] px-3 py-2 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
          >
            {INDONESIAN_CITY_PRESETS.map((city) => (
              <option key={city.id} value={city.id}>
                {city.name} ({city.latitude.toFixed(2)}°, {city.longitude.toFixed(2)}°)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Simulation Backdrop Upload */}
      {aimMode === 'simulation' && (
        <div className="space-y-2 border-t border-slate-800 pt-4">
          <div className="text-xs font-medium text-slate-300">Foto Referensi Simulasi</div>
          <div className="flex items-center gap-2">
            <label className="flex-1 min-h-[42px] inline-flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-slate-800 cursor-pointer">
              <ImageIcon className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
              <span>Unggah Foto Langit/Benda</span>
              <input
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onUploadBackdrop(f);
                }}
              />
            </label>
            {hasCustomBackdrop && (
              <button
                type="button"
                onClick={onClearBackdrop}
                className="min-h-[42px] rounded-xl border border-slate-700 px-3 py-2 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Hapus
              </button>
            )}
          </div>
        </div>
      )}

      {/* Status Sensor Kompas */}
      <div className="border-t border-slate-800 pt-4">
        <div className="rounded-xl border border-slate-800 bg-[#07090E] px-3 py-2.5 flex items-center justify-between text-xs">
          <span className="text-slate-400">Sensor Kompas &amp; Giroskop</span>
          <span className={`font-medium ${hasLiveSensor ? 'text-emerald-400' : 'text-amber-400'}`}>
            {hasLiveSensor
              ? reading.isAbsolute
                ? 'Aktif (Utara Magnetik)'
                : 'Aktif'
              : 'Menunggu Sensor'}
          </span>
        </div>
      </div>
    </div>
  );
};
