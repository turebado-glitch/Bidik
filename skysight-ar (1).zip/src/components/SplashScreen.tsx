import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onFinish?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [phase, setPhase] = useState<'enter' | 'exit' | 'done'>('enter');

  useEffect(() => {
    const exitTimer = window.setTimeout(() => {
      setPhase('exit');
    }, 1200);

    const doneTimer = window.setTimeout(() => {
      setPhase('done');
      onFinish?.();
    }, 1600);

    return () => {
      window.clearTimeout(exitTimer);
      window.clearTimeout(doneTimer);
    };
  }, [onFinish]);

  if (phase === 'done') return null;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#07090E] transition-all duration-400 ease-out ${
        phase === 'exit'
          ? 'opacity-0 scale-[1.03] pointer-events-none'
          : 'opacity-100 scale-100'
      }`}
    >
      {/* Logo Bidik 120dp sesuai gambar asli tanpa garis tambahan */}
      <div className="splash-logo-enter flex items-center justify-center">
        <img
          src="/assets/aistudio/AddText_11-15-07.49.25_55867733.png"
          alt="Logo Bidik"
          referrerPolicy="no-referrer"
          className="w-[120px] h-[120px] object-contain"
        />
      </div>

      {/* Teks BIDIK dengan font modern */}
      <div className="mt-5 text-center splash-text-enter">
        <h1 className="font-sans text-2xl font-bold tracking-[0.26em] text-white pl-[0.26em]">
          BIDIK
        </h1>
      </div>
    </div>
  );
};
