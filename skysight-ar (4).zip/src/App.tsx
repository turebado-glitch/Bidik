import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Camera,
  Crosshair,
  Download,
  History,
  Lock,
  Navigation,
  Settings,
  SlidersHorizontal,
  SwitchCamera,
  Unlock,
  X,
} from 'lucide-react';
import { CalibrationPanel } from './components/CalibrationPanel';
import { CaptureModal } from './components/CaptureModal';
import { OpticalHudCanvas } from './components/OpticalHudCanvas';
import { SettingsModal } from './components/SettingsModal';
import { SightingsLogPanel } from './components/SightingsLogPanel';
import { SplashScreen } from './components/SplashScreen';
import { useCameraStream } from './hooks/useCameraStream';
import { useGeoLocation } from './hooks/useGeoLocation';
import { useOrientationSensor } from './hooks/useOrientationSensor';
import {
  AimMode,
  CalibrationConfig,
  LocationPreference,
  QiblaInfo,
  SightingRecord,
} from './types/instrument';
import { savePhotoToDevice } from './utils/fileSave';
import {
  computeQiblaBearingAndDistance,
  INDONESIAN_CITY_PRESETS,
  normalizeDeg360,
} from './utils/orientationMath';
import { formatSnapshotDateTime, renderAnnotatedSnapshot } from './utils/snapshotRenderer';
import {
  computeWmmMagneticField,
  getDecimalYear,
  loadStoredWmmBundle,
  updateOfflineDeclinationData,
  WmmStoredBundle,
} from './utils/wmm2025';

const STORAGE_CONFIG_KEY = 'altaz_lens_config_v1';
const STORAGE_RECORDS_KEY = 'altaz_lens_records_v1';
const STORAGE_LOCATION_KEY = 'bidik_location_pref_v1';

const DEFAULT_LOCATION: LocationPreference = {
  mode: 'gps',
  manualLatitude: -7.1186,
  manualLongitude: 113.6628,
  manualLabel: 'Prenduan, Sumenep',
};

const DEFAULT_CONFIG: CalibrationConfig = {
  trueNorthEnabled: true,
  azimuthOffset: 0,
  altitudeOffset: 0,
  smoothing: 0.55,
  verticalFov: 60,
  compassLang: 'id',
  showPitchLadder: true,
  showCompassTape: true,
  showDms: true,
};

type ConsoleTab = 'logs' | 'calibration';

export default function App() {
  const [aimMode, setAimMode] = useState<AimMode>('camera');
  const [config, setConfig] = useState<CalibrationConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_CONFIG_KEY);
      return saved ? { ...DEFAULT_CONFIG, ...JSON.parse(saved) } : DEFAULT_CONFIG;
    } catch {
      return DEFAULT_CONFIG;
    }
  });

  const [records, setRecords] = useState<SightingRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_RECORDS_KEY);
      return saved ? (JSON.parse(saved) as SightingRecord[]) : [];
    } catch {
      return [];
    }
  });

  // Simulation pan angles (also used when no gyro sensor is present)
  const [simAngles, setSimAngles] = useState({
    azimuth: 78,
    altitude: 34,
    roll: 0,
  });

  const [isFrozen, setIsFrozen] = useState(false);
  const [frozenAngles, setFrozenAngles] = useState<{
    azimuth: number;
    trueAzimuth: number;
    magneticAzimuth: number;
    altitude: number;
    roll: number;
  } | null>(null);

  const [qiblaEnabled, setQiblaEnabled] = useState(false);
  const [selectedCityId, setSelectedCityId] = useState('sumenep');
  const [locationPref, setLocationPref] = useState<LocationPreference>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_LOCATION_KEY);
      return saved ? { ...DEFAULT_LOCATION, ...JSON.parse(saved) } : DEFAULT_LOCATION;
    } catch {
      return DEFAULT_LOCATION;
    }
  });
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [activeTab, setActiveTab] = useState<ConsoleTab>('logs');
  const [mobileSheetOpen, setMobileSheetOpen] = useState(false);
  const [pendingCapture, setPendingCapture] = useState<{
    azimuth: number;
    altitude: number;
    roll: number;
    timestamp: number;
    snapshotDataUrl?: string;
  } | null>(null);
  const [previewRecord, setPreviewRecord] = useState<SightingRecord | null>(null);
  const [previewDownloadMsg, setPreviewDownloadMsg] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);
  const [wmmBundle, setWmmBundle] = useState<WmmStoredBundle>(() => loadStoredWmmBundle());

  const [customBackdrop, setCustomBackdrop] = useState<HTMLImageElement | null>(null);
  const simCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const camera = useCameraStream();
  const sensor = useOrientationSensor(config.smoothing, aimMode === 'camera');
  const { geo, requestLocation } = useGeoLocation();

  // Persist calibration config & location preference
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(config));
    } catch {
      // Ignore storage quota errors
    }
  }, [config]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_LOCATION_KEY, JSON.stringify(locationPref));
    } catch {
      // Ignore storage quota errors
    }
  }, [locationPref]);

  // Persist sighting records (trim oldest thumbnails if localStorage quota exceeded)
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_RECORDS_KEY, JSON.stringify(records));
    } catch {
      try {
        const trimmed = records.map((r, idx) =>
          idx < 8 ? r : { ...r, snapshotDataUrl: undefined }
        );
        localStorage.setItem(STORAGE_RECORDS_KEY, JSON.stringify(trimmed));
      } catch {
        // Ignore storage failure
      }
    }
  }, [records]);

  // Attempt automatic camera start on mount when on touch/mobile or user-friendly default;
  // on desktop without camera, user gets immediate Simulation option or 1-tap camera button.
  useEffect(() => {
    void camera.startCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const qiblaCoords =
    locationPref.mode === 'gps' &&
    geo.status === 'active' &&
    geo.latitude !== null &&
    geo.longitude !== null
      ? { lat: geo.latitude, lon: geo.longitude, label: 'GPS Aktif', isGps: true }
      : {
          lat: locationPref.manualLatitude,
          lon: locationPref.manualLongitude,
          label: locationPref.manualLabel || 'Lokasi Manual',
          isGps: false,
        };

  const altKm = geo.altitudeMeters ? Math.max(0, geo.altitudeMeters / 1000) : 0;
  const wmmResult = useMemo(
    () =>
      computeWmmMagneticField(
        qiblaCoords.lat,
        qiblaCoords.lon,
        altKm,
        getDecimalYear(),
        wmmBundle
      ),
    [altKm, qiblaCoords.lat, qiblaCoords.lon, wmmBundle]
  );

  // Compute active calibrated angles (applying offline WMM-2025 True North correction when enabled)
  const useLiveSensor = aimMode === 'camera' && sensor.hasLiveSensor;
  const rawAzimuth = useLiveSensor ? sensor.reading.azimuth : simAngles.azimuth;
  const rawAltitude = useLiveSensor ? sensor.reading.altitude : simAngles.altitude;
  const rawRoll = useLiveSensor ? sensor.reading.roll : simAngles.roll;

  const magneticAzimuth = normalizeDeg360(rawAzimuth + config.azimuthOffset);
  const trueAzimuth = normalizeDeg360(
    rawAzimuth + wmmResult.declinationDeg + config.azimuthOffset
  );
  const calibratedAzimuth = config.trueNorthEnabled ? trueAzimuth : magneticAzimuth;
  const calibratedAltitude = Math.max(
    -90,
    Math.min(90, rawAltitude + config.altitudeOffset)
  );
  const calibratedRoll = rawRoll;

  const displayAzimuth =
    isFrozen && frozenAngles ? frozenAngles.azimuth : calibratedAzimuth;
  const displayTrueAzimuth =
    isFrozen && frozenAngles ? frozenAngles.trueAzimuth : trueAzimuth;
  const displayMagneticAzimuth =
    isFrozen && frozenAngles ? frozenAngles.magneticAzimuth : magneticAzimuth;
  const displayAltitude =
    isFrozen && frozenAngles ? frozenAngles.altitude : calibratedAltitude;
  const displayRoll = isFrozen && frozenAngles ? frozenAngles.roll : calibratedRoll;

  const qiblaCalc = computeQiblaBearingAndDistance(qiblaCoords.lat, qiblaCoords.lon);
  const qiblaInfo: QiblaInfo = {
    enabled: qiblaEnabled,
    azimuth: qiblaCalc.azimuth,
    distanceKm: qiblaCalc.distanceKm,
    sourceLabel: qiblaCoords.label,
    isGps: qiblaCoords.isGps,
  };

  const handleRefreshWmm = useCallback(async () => {
    const outcome = await updateOfflineDeclinationData(
      qiblaCoords.lat,
      qiblaCoords.lon,
      altKm
    );
    setWmmBundle(outcome.bundle);
    return outcome;
  }, [altKm, qiblaCoords.lat, qiblaCoords.lon]);

  const handleSelectCityPreset = useCallback((cityId: string) => {
    setSelectedCityId(cityId);
    const city = INDONESIAN_CITY_PRESETS.find((c) => c.id === cityId);
    if (city) {
      setLocationPref({
        mode: 'manual',
        manualLatitude: city.latitude,
        manualLongitude: city.longitude,
        manualLabel: city.name,
      });
    }
  }, []);

  const handleToggleQibla = useCallback(() => {
    setQiblaEnabled((prev) => {
      const next = !prev;
      if (next && locationPref.mode === 'gps' && geo.status === 'idle') {
        requestLocation();
      }
      return next;
    });
  }, [geo.status, locationPref.mode, requestLocation]);

  const handleUpdateConfig = useCallback((patch: Partial<CalibrationConfig>) => {
    setConfig((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleZeroAltitude = useCallback(() => {
    // Sets altitudeOffset so current physical pitch reads 0.0°
    const offset = Math.max(-15, Math.min(15, -rawAltitude));
    setConfig((prev) => ({ ...prev, altitudeOffset: Number(offset.toFixed(1)) }));
  }, [rawAltitude]);

  const handleResetOffsets = useCallback(() => {
    setConfig(DEFAULT_CONFIG);
  }, []);

  const handleToggleFreeze = useCallback(() => {
    if (!isFrozen) {
      setFrozenAngles({
        azimuth: calibratedAzimuth,
        trueAzimuth,
        magneticAzimuth,
        altitude: calibratedAltitude,
        roll: calibratedRoll,
      });
      setIsFrozen(true);
    } else {
      setIsFrozen(false);
      setFrozenAngles(null);
    }
  }, [
    calibratedAltitude,
    calibratedAzimuth,
    calibratedRoll,
    isFrozen,
    magneticAzimuth,
    trueAzimuth,
  ]);

  const handleSwitchMode = useCallback(
    (nextMode: AimMode) => {
      setAimMode(nextMode);
      setIsFrozen(false);
      setFrozenAngles(null);
      if (nextMode === 'camera') {
        void camera.startCamera();
        if (sensor.permissionState === 'prompt') {
          void sensor.requestSensorPermission();
        }
      } else {
        camera.stopCamera();
      }
    },
    [camera, sensor]
  );

  const handleAdjustSimulation = useCallback((deltaAz: number, deltaAlt: number) => {
    setSimAngles((prev) => ({
      ...prev,
      azimuth: normalizeDeg360(prev.azimuth + deltaAz),
      altitude: Math.max(-89.9, Math.min(89.9, prev.altitude + deltaAlt)),
    }));
  }, []);

  const activeLat =
    locationPref.mode === 'gps' ? geo.latitude : locationPref.manualLatitude;
  const activeLon =
    locationPref.mode === 'gps' ? geo.longitude : locationPref.manualLongitude;

  const handleCaptureClick = useCallback(() => {
    const captureTimestamp = Date.now();
    const snapshotDataUrl = renderAnnotatedSnapshot({
      videoElement: aimMode === 'camera' && camera.status === 'active' ? camera.videoRef.current : null,
      simCanvasElement: simCanvasRef.current,
      azimuth: displayAzimuth,
      trueAzimuth: displayTrueAzimuth,
      magneticAzimuth: displayMagneticAzimuth,
      altitude: displayAltitude,
      roll: displayRoll,
      latitude: activeLat,
      longitude: activeLon,
      lang: config.compassLang,
      timestamp: captureTimestamp,
      trueNorth: config.trueNorthEnabled,
      declinationDeg: wmmResult.declinationDeg,
    });

    setPendingCapture({
      azimuth: displayAzimuth,
      altitude: displayAltitude,
      roll: displayRoll,
      timestamp: captureTimestamp,
      snapshotDataUrl,
    });
  }, [
    activeLat,
    activeLon,
    aimMode,
    camera.status,
    camera.videoRef,
    config.compassLang,
    config.trueNorthEnabled,
    displayAltitude,
    displayAzimuth,
    displayMagneticAzimuth,
    displayRoll,
    displayTrueAzimuth,
    wmmResult.declinationDeg,
  ]);

  const handleSaveCapture = useCallback(
    (label: string, note: string) => {
      if (!pendingCapture) return;
      const newRecord: SightingRecord = {
        id: `${pendingCapture.timestamp}-${Math.random().toString(36).slice(2, 7)}`,
        label,
        note,
        azimuth: pendingCapture.azimuth,
        altitude: pendingCapture.altitude,
        roll: pendingCapture.roll,
        latitude: activeLat,
        longitude: activeLon,
        timestamp: pendingCapture.timestamp,
        source: useLiveSensor ? 'sensor' : 'simulation',
        snapshotDataUrl: pendingCapture.snapshotDataUrl,
      };
      setRecords((prev) => [newRecord, ...prev]);
      setPendingCapture(null);
      setActiveTab('logs');
    },
    [activeLat, activeLon, pendingCapture, useLiveSensor]
  );

  const handleUploadBackdrop = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') return;
      const img = new Image();
      img.onload = () => setCustomBackdrop(img);
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  }, []);

  const handleClearBackdrop = useCallback(() => {
    setCustomBackdrop(null);
  }, []);

  const openMobileSheet = (tab: ConsoleTab) => {
    setActiveTab(tab);
    setMobileSheetOpen(true);
  };

  const isNativeAndroid =
    typeof window !== 'undefined' &&
    Boolean(
      (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.()
    );

  return (
    <div className="relative h-dvh w-full bg-[#07090E] text-slate-100 flex flex-col lg:grid lg:grid-cols-[1fr_390px] overflow-hidden">
      {!isNativeAndroid && <SplashScreen />}

      {/* Main Optical Viewfinder Stage */}
      <main className="relative flex-1 h-full overflow-hidden">
        {/* Top Compact Instrument Ribbon */}
        <header className="absolute inset-x-0 top-0 z-30 pt-safe">
          <div className="h-12 px-3.5 sm:px-5 flex items-center justify-between gap-3 bg-gradient-to-b from-[#07090E]/90 via-[#07090E]/55 to-transparent">
            <div className="flex items-center gap-2 min-w-0">
              <img
                src="/assets/aistudio/AddText_11-17-05.40.10_2591df35.png"
                alt="Logo Bidik"
                referrerPolicy="no-referrer"
                className="w-7 h-7 object-contain shrink-0"
              />
              <span className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0">
                Bidik
              </span>
              <span className="hidden sm:inline text-slate-500" aria-hidden="true">
                ·
              </span>
              <span className="hidden sm:inline text-xs text-slate-300 truncate">
                {aimMode === 'camera'
                  ? useLiveSensor
                    ? 'Kamera & Kompas Aktif'
                    : 'Kamera Aktif'
                  : 'Mode Simulasi'}
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {aimMode === 'simulation' ? (
                <button
                  type="button"
                  onClick={() => handleSwitchMode('camera')}
                  className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg bg-cyan-500 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Camera className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Kamera</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={camera.toggleFacingMode}
                  className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg border border-slate-700/80 bg-[#0B0E17]/80 text-slate-200 hover:bg-slate-800 transition-colors shrink-0 cursor-pointer"
                  aria-label="Ganti kamera depan atau belakang"
                  title="Ganti Lensa"
                >
                  <SwitchCamera className="w-4 h-4 text-slate-200" aria-hidden="true" />
                </button>
              )}

              <button
                type="button"
                onClick={() => setSettingsOpen(true)}
                className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-700/80 bg-[#0B0E17]/80 px-2.5 text-xs font-medium text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                aria-label="Buka pengaturan aplikasi"
                title="Pengaturan"
              >
                <Settings className="w-4 h-4 text-slate-200" aria-hidden="true" />
                <span className="hidden md:inline">Pengaturan</span>
              </button>
            </div>
          </div>
        </header>

        {/* Optical Viewfinder & HUD Overlay */}
        <OpticalHudCanvas
          aimMode={aimMode}
          videoRef={camera.videoRef}
          simCanvasRef={simCanvasRef}
          cameraStatus={camera.status}
          cameraError={camera.errorMessage}
          sensorPermission={sensor.permissionState}
          hasLiveSensor={sensor.hasLiveSensor}
          azimuth={displayAzimuth}
          trueAzimuth={displayTrueAzimuth}
          magneticAzimuth={displayMagneticAzimuth}
          declinationDeg={wmmResult.declinationDeg}
          altitude={displayAltitude}
          roll={displayRoll}
          isFrozen={isFrozen}
          config={config}
          zoom={camera.zoom}
          customBackdrop={customBackdrop}
          qibla={qiblaInfo}
          onStartCamera={() => void camera.startCamera()}
          onRequestSensor={() => void sensor.requestSensorPermission()}
          onRequestLocation={() => {
            setLocationPref((prev) => ({ ...prev, mode: 'gps' }));
            requestLocation();
          }}
          onSwitchToSimulation={() => handleSwitchMode('simulation')}
          onAdjustSimulation={handleAdjustSimulation}
          onApplyZoom={(z) => void camera.applyZoom(z)}
        />

        {/* Bottom Navigation Bar — Symmetrical 5-column fit on mobile, 3-button dock on desktop */}
        <nav
          aria-label="Navigasi utama"
          className="absolute inset-x-0 bottom-0 z-30"
        >
          {/* Mobile 5-column Bottom Bar (never overflows horizontally) */}
          <div className="lg:hidden grid grid-cols-5 items-center w-full px-1.5 pt-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] bg-[#07090E]/92 backdrop-blur-md border-t border-slate-800/80">
            {/* 1. Tahan / Lepas */}
            <button
              type="button"
              onClick={handleToggleFreeze}
              className={`min-w-0 min-h-[48px] flex flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-1 transition-colors cursor-pointer ${
                isFrozen
                  ? 'text-amber-400'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {isFrozen ? (
                <Unlock className="w-5 h-5 shrink-0" aria-hidden="true" />
              ) : (
                <Lock className="w-5 h-5 shrink-0" aria-hidden="true" />
              )}
              <span className="text-[10px] font-medium leading-none whitespace-nowrap">
                {isFrozen ? 'Lepas' : 'Tahan'}
              </span>
            </button>

            {/* 2. Kiblat */}
            <button
              type="button"
              onClick={handleToggleQibla}
              aria-pressed={qiblaEnabled}
              className={`min-w-0 min-h-[48px] flex flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-1 transition-colors cursor-pointer ${
                qiblaEnabled
                  ? 'text-emerald-400'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Navigation className="w-5 h-5 shrink-0" aria-hidden="true" />
              <span className="text-[10px] font-medium leading-none whitespace-nowrap">
                Kiblat
              </span>
            </button>

            {/* 3. Primary Shutter: Bidik */}
            <div className="min-w-0 flex items-center justify-center px-0.5">
              <button
                type="button"
                onClick={handleCaptureClick}
                className="w-full max-w-[68px] h-11 flex flex-col items-center justify-center gap-0.5 rounded-2xl bg-cyan-500 text-slate-950 hover:bg-cyan-400 active:scale-[0.97] transition-all cursor-pointer"
                aria-label="Bidik dan simpan pengukuran"
              >
                <Crosshair className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span className="text-[10px] font-bold leading-none whitespace-nowrap">
                  Bidik
                </span>
              </button>
            </div>

            {/* 4. Riwayat */}
            <button
              type="button"
              onClick={() => openMobileSheet('logs')}
              className="min-w-0 min-h-[48px] flex flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-1 text-slate-300 hover:text-white transition-colors cursor-pointer"
              aria-label="Buka riwayat bidikan"
            >
              <span className="relative inline-flex items-center justify-center">
                <History className="w-5 h-5 shrink-0" aria-hidden="true" />
                {records.length > 0 && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-[16px] px-1 rounded-full bg-cyan-500 font-mono text-[9px] font-bold text-slate-950 flex items-center justify-center tabular-nums">
                    {records.length}
                  </span>
                )}
              </span>
              <span className="text-[10px] font-medium leading-none whitespace-nowrap">
                Riwayat
              </span>
            </button>

            {/* 5. Kalibrasi */}
            <button
              type="button"
              onClick={() => openMobileSheet('calibration')}
              className="min-w-0 min-h-[48px] flex flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-1 text-slate-300 hover:text-white transition-colors cursor-pointer"
              aria-label="Buka kalibrasi sudut dan tampilan"
            >
              <SlidersHorizontal className="w-5 h-5 shrink-0" aria-hidden="true" />
              <span className="text-[10px] font-medium leading-none whitespace-nowrap">
                Kalibrasi
              </span>
            </button>
          </div>

          {/* Desktop Action Dock */}
          <div className="hidden lg:flex h-20 px-4 items-center justify-center gap-4 bg-gradient-to-t from-[#07090E] via-[#07090E]/85 to-transparent">
            <button
              type="button"
              onClick={handleToggleFreeze}
              className={`min-h-[46px] inline-flex items-center justify-center gap-1.5 rounded-xl border px-4 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                isFrozen
                  ? 'border-amber-500 bg-amber-500/20 text-amber-300'
                  : 'border-slate-700/90 bg-[#0B0E17]/90 text-slate-200 hover:bg-slate-800'
              }`}
            >
              {isFrozen ? (
                <Unlock className="w-4 h-4" aria-hidden="true" />
              ) : (
                <Lock className="w-4 h-4" aria-hidden="true" />
              )}
              <span>{isFrozen ? 'Lepas' : 'Tahan'}</span>
            </button>

            <button
              type="button"
              onClick={handleToggleQibla}
              aria-pressed={qiblaEnabled}
              className={`min-h-[46px] inline-flex items-center justify-center gap-1.5 rounded-xl border px-4 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                qiblaEnabled
                  ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300'
                  : 'border-slate-700/90 bg-[#0B0E17]/90 text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Navigation className="w-4 h-4" aria-hidden="true" />
              <span>Kiblat</span>
            </button>

            <button
              type="button"
              onClick={handleCaptureClick}
              className="min-h-[48px] inline-flex items-center justify-center gap-2 rounded-2xl bg-cyan-500 px-6 py-3 text-sm font-bold text-slate-950 hover:bg-cyan-400 active:scale-[0.98] transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Crosshair className="w-4 h-4" aria-hidden="true" />
              <span>Bidik &amp; Simpan</span>
            </button>
          </div>
        </nav>
      </main>

      {/* Desktop Precision Side Console */}
      <aside className="hidden lg:flex flex-col h-full border-l border-slate-800 bg-[#0B0E17]">
        <div className="p-3 border-b border-slate-800">
          <div className="grid grid-cols-2 gap-1 rounded-xl bg-[#07090E] p-1 border border-slate-800/80">
            <button
              type="button"
              onClick={() => setActiveTab('logs')}
              className={`min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'logs'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <History className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Riwayat ({records.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('calibration')}
              className={`min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'calibration'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Kalibrasi</span>
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {activeTab === 'logs' && (
            <SightingsLogPanel
              records={records}
              lang={config.compassLang}
              onDelete={(id) => setRecords((prev) => prev.filter((r) => r.id !== id))}
              onClearAll={() => setRecords([])}
              onSelectPreview={(rec) => {
                setPreviewDownloadMsg(null);
                setPreviewRecord(rec);
              }}
            />
          )}
          {activeTab === 'calibration' && (
            <CalibrationPanel
              aimMode={aimMode}
              config={config}
              reading={sensor.reading}
              geo={geo}
              devices={camera.devices}
              selectedDeviceId={camera.selectedDeviceId}
              hasLiveSensor={sensor.hasLiveSensor}
              selectedCityId={selectedCityId}
              activeLocationLabel={qiblaCoords.label}
              wmmResult={wmmResult}
              onSelectCity={handleSelectCityPreset}
              onUpdateConfig={handleUpdateConfig}
              onZeroAltitude={handleZeroAltitude}
              onResetOffsets={handleResetOffsets}
              onRequestLocation={requestLocation}
              onToggleFacing={camera.toggleFacingMode}
              onSelectDevice={camera.selectDevice}
              onUploadBackdrop={handleUploadBackdrop}
              onClearBackdrop={handleClearBackdrop}
              hasCustomBackdrop={!!customBackdrop}
            />
          )}
        </div>
      </aside>

      {/* Mobile Bottom Sheet Drawer */}
      {mobileSheetOpen && (
        <div
          className="absolute inset-0 z-[60] lg:hidden flex items-end bg-black/85"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-h-[85%] flex flex-col rounded-t-3xl border-t border-slate-800 bg-[#0B0E17]">
            <div className="pt-2.5 pb-2 px-4 flex items-center justify-between border-b border-slate-800 shrink-0">
              <div className="grid grid-cols-2 gap-1 rounded-xl bg-[#07090E] p-1 border border-slate-800 flex-1 mr-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('logs')}
                  className={`min-h-[38px] rounded-lg px-2 text-xs font-medium whitespace-nowrap cursor-pointer ${
                    activeTab === 'logs' ? 'bg-slate-800 text-white' : 'text-slate-400'
                  }`}
                >
                  Riwayat ({records.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('calibration')}
                  className={`min-h-[38px] rounded-lg px-2 text-xs font-medium whitespace-nowrap cursor-pointer ${
                    activeTab === 'calibration' ? 'bg-slate-800 text-white' : 'text-slate-400'
                  }`}
                >
                  Kalibrasi
                </button>
              </div>
              <button
                type="button"
                onClick={() => setMobileSheetOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                aria-label="Tutup panel"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain p-4 pb-6">
              {activeTab === 'logs' && (
                <SightingsLogPanel
                  records={records}
                  lang={config.compassLang}
                  onDelete={(id) => setRecords((prev) => prev.filter((r) => r.id !== id))}
                  onClearAll={() => setRecords([])}
                  onSelectPreview={(rec) => {
                    setPreviewDownloadMsg(null);
                    setPreviewRecord(rec);
                  }}
                />
              )}
              {activeTab === 'calibration' && (
                <CalibrationPanel
                  aimMode={aimMode}
                  config={config}
                  reading={sensor.reading}
                  geo={geo}
                  devices={camera.devices}
                  selectedDeviceId={camera.selectedDeviceId}
                  hasLiveSensor={sensor.hasLiveSensor}
                  selectedCityId={selectedCityId}
                  activeLocationLabel={qiblaCoords.label}
                  wmmResult={wmmResult}
                  onSelectCity={handleSelectCityPreset}
                  onUpdateConfig={handleUpdateConfig}
                  onZeroAltitude={handleZeroAltitude}
                  onResetOffsets={handleResetOffsets}
                  onRequestLocation={requestLocation}
                  onToggleFacing={camera.toggleFacingMode}
                  onSelectDevice={camera.selectDevice}
                  onUploadBackdrop={handleUploadBackdrop}
                  onClearBackdrop={handleClearBackdrop}
                  hasCustomBackdrop={!!customBackdrop}
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Capture / Save Modal */}
      {pendingCapture && (
        <CaptureModal
          azimuth={pendingCapture.azimuth}
          altitude={pendingCapture.altitude}
          roll={pendingCapture.roll}
          timestamp={pendingCapture.timestamp}
          snapshotDataUrl={pendingCapture.snapshotDataUrl}
          lang={config.compassLang}
          onSave={handleSaveCapture}
          onCancel={() => setPendingCapture(null)}
        />
      )}

      {/* Saved Photo Preview Lightbox */}
      {previewRecord?.snapshotDataUrl && (
        <div
          className="absolute inset-0 z-[60] flex items-center justify-center bg-black/85 p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => setPreviewRecord(null)}
        >
          <div
            className="w-full max-w-2xl rounded-2xl border border-slate-800 bg-[#0B0E17] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-slate-800">
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-white truncate">
                  {previewRecord.label}
                </h4>
                <p className="font-mono text-xs text-slate-400 tabular-nums">
                  Alt {previewRecord.altitude >= 0 ? '+' : ''}
                  {previewRecord.altitude.toFixed(1)}° · Az {previewRecord.azimuth.toFixed(1)}° ·{' '}
                  {(() => {
                    const dt = formatSnapshotDateTime(previewRecord.timestamp);
                    return `${dt.dateStr} Jam ${dt.timeStr}`;
                  })()}
                </p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={async () => {
                    if (!previewRecord.snapshotDataUrl) return;
                    const dt = formatSnapshotDateTime(previewRecord.timestamp);
                    const slug =
                      previewRecord.label
                        .toLowerCase()
                        .replace(/[^a-z0-9]+/g, '-')
                        .replace(/^-|-$/g, '') || 'bidik';
                    const res = await savePhotoToDevice(
                      previewRecord.snapshotDataUrl,
                      `${slug}-${previewRecord.azimuth.toFixed(0)}deg-${dt.timeStr.replace(/:/g, '')}.jpg`
                    );
                    setPreviewDownloadMsg(res);
                  }}
                  className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg bg-cyan-500 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Unduh</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewRecord(null)}
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white cursor-pointer"
                  aria-label="Tutup pratinjau"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            {previewDownloadMsg && (
              <div
                className={`px-4 py-2 text-xs font-medium border-b ${
                  previewDownloadMsg.ok
                    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                    : 'border-rose-500/30 bg-rose-500/10 text-rose-300'
                }`}
              >
                {previewDownloadMsg.message}
              </div>
            )}
            <img
              src={previewRecord.snapshotDataUrl}
              alt={previewRecord.label}
              className="w-full max-h-[75dvh] object-contain bg-black"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      )}

      {settingsOpen && (
        <SettingsModal
          geo={geo}
          locationPref={locationPref}
          trueNorthEnabled={config.trueNorthEnabled}
          wmmResult={wmmResult}
          wmmBundle={wmmBundle}
          onToggleTrueNorth={(next) => handleUpdateConfig({ trueNorthEnabled: next })}
          onRefreshWmm={handleRefreshWmm}
          onUpdateLocationPref={setLocationPref}
          onRequestLocation={requestLocation}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </div>
  );
}
