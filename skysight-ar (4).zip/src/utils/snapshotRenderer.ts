import { CompassLanguage } from '../types/instrument';
import { getCardinalDirection } from './orientationMath';

export interface SnapshotInput {
  videoElement: HTMLVideoElement | null;
  simCanvasElement: HTMLCanvasElement | null;
  azimuth: number;
  trueAzimuth?: number;
  magneticAzimuth?: number;
  altitude: number;
  roll: number;
  latitude: number | null;
  longitude: number | null;
  lang: CompassLanguage;
  label?: string;
  timestamp?: number;
  trueNorth?: boolean;
  declinationDeg?: number;
}

export function formatSnapshotDateTime(timestamp: number): {
  dateStr: string;
  timeStr: string;
} {
  const d = new Date(timestamp);
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
    'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des',
  ];
  const day = String(d.getDate()).padStart(2, '0');
  const month = months[d.getMonth()] ?? 'Jan';
  const year = d.getFullYear();

  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');

  return {
    dateStr: `${day} ${month} ${year}`,
    timeStr: `${hh}:${mm}:${ss}`,
  };
}

/**
 * Composites the live video frame (or simulation canvas) with an optical reticle
 * and precision telemetry + date/time stamp into a downloadable JPEG data URL.
 */
export function renderAnnotatedSnapshot(input: SnapshotInput): string | undefined {
  const {
    videoElement,
    simCanvasElement,
    azimuth,
    trueAzimuth,
    magneticAzimuth,
    altitude,
    roll,
    latitude,
    longitude,
    lang,
    label,
    timestamp = Date.now(),
    trueNorth = true,
    declinationDeg,
  } = input;

  const hasVideo =
    videoElement &&
    videoElement.readyState >= 2 &&
    videoElement.videoWidth > 0 &&
    videoElement.videoHeight > 0;

  const targetW = 1280;
  const targetH = 720;

  const canvas = document.createElement('canvas');
  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext('2d');
  if (!ctx) return undefined;

  ctx.fillStyle = '#07090E';
  ctx.fillRect(0, 0, targetW, targetH);

  if (hasVideo && videoElement) {
    const vRatio = videoElement.videoWidth / videoElement.videoHeight;
    const cRatio = targetW / targetH;
    let dw = targetW;
    let dh = targetH;
    let dx = 0;
    let dy = 0;
    if (vRatio > cRatio) {
      dw = targetH * vRatio;
      dx = (targetW - dw) / 2;
    } else {
      dh = targetW / vRatio;
      dy = (targetH - dh) / 2;
    }
    ctx.drawImage(videoElement, dx, dy, dw, dh);
  } else if (simCanvasElement && simCanvasElement.width > 0) {
    ctx.drawImage(simCanvasElement, 0, 0, targetW, targetH);
  }

  // Draw calibrated center reticle
  const cx = targetW / 2;
  const cy = targetH / 2;

  ctx.save();
  ctx.strokeStyle = 'rgba(6, 182, 212, 0.9)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, 42, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(cx - 72, cy);
  ctx.lineTo(cx - 18, cy);
  ctx.moveTo(cx + 18, cy);
  ctx.lineTo(cx + 72, cy);
  ctx.moveTo(cx, cy - 72);
  ctx.lineTo(cx, cy - 18);
  ctx.moveTo(cx, cy + 18);
  ctx.lineTo(cx, cy + 72);
  ctx.stroke();

  ctx.fillStyle = '#F59E0B';
  ctx.beginPath();
  ctx.arc(cx, cy, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  const { dateStr, timeStr } = formatSnapshotDateTime(timestamp);

  // Top-right Date stamp badge (tanggal saja; jam ada di kanan bawah)
  ctx.save();
  const stampText = dateStr;
  ctx.font = '600 16px "JetBrains Mono", monospace';
  const textWidth = ctx.measureText(stampText).width;
  const badgeW = textWidth + 32;
  const badgeH = 38;
  const badgeX = targetW - 28 - badgeW;
  const badgeY = 24;

  ctx.fillStyle = 'rgba(7, 9, 14, 0.84)';
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 10);
  ctx.fill();
  ctx.stroke();

  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#F8FAFC';
  ctx.fillText(stampText, targetW - 44, badgeY + badgeH / 2);
  ctx.restore();

  // Bottom telemetry bar scrim
  const barH = 104;
  const grad = ctx.createLinearGradient(0, targetH - barH - 28, 0, targetH);
  grad.addColorStop(0, 'rgba(7, 9, 14, 0)');
  grad.addColorStop(0.35, 'rgba(7, 9, 14, 0.86)');
  grad.addColorStop(1, 'rgba(7, 9, 14, 0.96)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, targetH - barH - 28, targetW, barH + 28);

  const cardinal = getCardinalDirection(azimuth, lang);
  const altSign = altitude >= 0 ? '+' : '';

  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#94A3B8';
  ctx.font = '600 13px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('ALTITUDE (ELEVASI)', 36, targetH - 64);
  ctx.fillText(
    trueNorth ? 'AZIMUTH (UTARA SEJATI)' : 'AZIMUTH (UTARA MAGNETIK)',
    310,
    targetH - 64
  );

  ctx.fillStyle = '#F8FAFC';
  ctx.font = '700 34px "JetBrains Mono", monospace';
  ctx.fillText(`${altSign}${altitude.toFixed(1)}°`, 36, targetH - 26);
  ctx.fillText(`${azimuth.toFixed(1)}° ${cardinal.abbr}`, 310, targetH - 26);

  if (typeof trueAzimuth === 'number' && typeof magneticAzimuth === 'number') {
    ctx.fillStyle = '#CBD5E1';
    ctx.font = '500 12px "JetBrains Mono", monospace';
    ctx.fillText(
      `Sejati ${trueAzimuth.toFixed(1)}° · Magnet ${magneticAzimuth.toFixed(1)}°`,
      310,
      targetH - 8
    );
  }

  // Right metadata stamp (judul di atas, jam + metadata di kanan bawah)
  ctx.textAlign = 'right';
  ctx.fillStyle = '#E2E8F0';
  ctx.font = '600 16px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(label?.trim() || 'Pengukuran Bidik', targetW - 36, targetH - 56);

  ctx.fillStyle = '#CBD5E1';
  ctx.font = '500 13px "JetBrains Mono", monospace';
  const declStr =
    typeof declinationDeg === 'number'
      ? ` · Dekl ${declinationDeg >= 0 ? '+' : ''}${declinationDeg.toFixed(2)}°`
      : '';
  const gpsStr =
    latitude !== null && longitude !== null
      ? ` · ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`
      : '';
  ctx.fillText(
    `Jam ${timeStr} · Roll ${roll.toFixed(1)}°${declStr}${gpsStr}`,
    targetW - 36,
    targetH - 24
  );

  return canvas.toDataURL('image/jpeg', 0.88);
}
